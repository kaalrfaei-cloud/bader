const logger = require('../utils/logger');

// Known Penetration Testing & Scanner User-Agent Signatures
const SCANNER_USER_AGENTS = [
  'nmap',
  'nikto',
  'sqlmap',
  'gobuster',
  'dirbuster',
  'wpscan',
  'acunetix',
  'nessus',
  'masscan',
  'zgrab',
  'censys',
  'shodan',
  'qualys',
  'openvas',
  'burpcollaborator',
  'burp',
  'hydra',
  'metasploit',
  'havij',
  'wfuzz',
  'ffuf',
  'commix',
  'whatweb'
];

// Dangerous probe paths commonly scanned by automated penetration tools
const SENSITIVE_PROBE_PATHS = [
  /^\/\./i, // Block ALL hidden files and directories (/.env, /.git, /.htaccess, etc.)
  /(bash|zsh|mysql|psql|nano|sh)_history/i,
  /(htpasswd|htaccess|web\.config)/i,
  /(DS_Store|dockerignore|Dockerfile)/i,
  /\/(idea|vscode|hg|svn|git)(\/|$)/i,
  /backup/i,
  /\.(bak|old|sql|dump|tar|gz|rar|zip|7z|tgz|swp)$/i,
  /(config\.(json|yaml|yml|env|ini)|application\.properties)/i,
  /well-known/i,
  /CHANGELOG/i,
  /^\/wp-/i,
  /^\/xmlrpc/i,
  /^\/phpmyadmin/i,
  /^\/pma/i,
  /^\/adminer/i,
  /^\/actuator/i,
  /^\/swagger/i,
  /^\/api-docs/i,
  /^\/console/i,
  /^\/shell/i,
  /^\/cmd/i,
  /^\/cgi-bin/i,
  /^\/etc\/passwd/i,
  /^\/proc\//i,
  /\.php$/i,
  /\.asp$/i,
  /\.aspx$/i,
  /\.jsp$/i,
  /\.cgi$/i
];

// PowerShell, RCE, and Command Injection Malicious Signatures
const RCE_PAYLOAD_PATTERNS = [
  /powershell(\.exe)?\s/i,
  /\bpwsh\b/i,
  /-enc(odedcommand)?\s+[a-z0-9+/=]{10,}/i,
  /\binvoke-(expression|webrequest|restmethod)\b/i,
  /\b(iex|iwr)\s+/i,
  /\bdownloadstring\s*\(/i,
  /\bsystem\.net\.webclient\b/i,
  /\bstart-process\s/i,
  /\bcmd(\.exe)?\s+(\/c|\/k)/i,
  /\/bin\/(ba)?sh/i,
  /\b(bash|sh)\s+-c\b/i,
  /\b(nc|ncat|netcat)\s+.*-e\b/i,
  /\.\.[/\\]/,       // Path traversal ../ or ..\
  /\.\.%2f/i,        // Encoded path traversal
  /\.\.%5c/i,
  /%00/              // Null byte injection
];

// Disallowed HTTP Methods (Prevent HTTP verb tampering / Cross-Site Tracing)
const DISALLOWED_METHODS = new Set(['TRACE', 'TRACK', 'CONNECT', 'DEBUG']);

function inspectString(str) {
  if (typeof str !== 'string' || !str) return null;
  for (const pattern of RCE_PAYLOAD_PATTERNS) {
    if (pattern.test(str)) {
      return pattern.toString();
    }
  }
  return null;
}

function inspectPayload(data) {
  if (!data) return null;
  if (typeof data === 'string') return inspectString(data);
  if (Array.isArray(data)) {
    for (const item of data) {
      const match = inspectPayload(item);
      if (match) return match;
    }
  } else if (typeof data === 'object') {
    for (const key of Object.keys(data)) {
      const keyMatch = inspectString(key);
      if (keyMatch) return keyMatch;
      const valMatch = inspectPayload(data[key]);
      if (valMatch) return valMatch;
    }
  }
  return null;
}

function antiHackingFirewall(req, res, next) {
  const ip = req.ip || req.connection?.remoteAddress || 'unknown';

  // 1. Remove identifying server headers
  res.removeHeader('X-Powered-By');
  res.removeHeader('Server');
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');

  // 2. Reject Dangerous HTTP Methods
  if (DISALLOWED_METHODS.has(req.method.toUpperCase())) {
    logger.warn(`[Firewall] حظر محاولة استخدام بروتوكول غير مصرح: ${req.method} من IP: ${ip}`);
    return res.status(405).json({ error: 'Method Not Allowed' });
  }

  // 3. User-Agent Scanner / Pentest Tool Detection (Nmap, Nikto, Sqlmap, etc.)
  const userAgent = (req.get('user-agent') || '').toLowerCase();
  for (const tool of SCANNER_USER_AGENTS) {
    if (userAgent.includes(tool)) {
      logger.warn(`[Firewall] رصد ومصادرة أداة فحص اختراق (${tool}) من IP: ${ip}`);
      return res.status(403).json({ error: 'Access Denied: Security Scanner Blocked' });
    }
  }

  // 4. Reconnaissance & Sensitive Path Probing Detection
  const reqPath = req.path || '';
  for (const probePattern of SENSITIVE_PROBE_PATHS) {
    if (probePattern.test(reqPath)) {
      logger.warn(`[Firewall] إحباط محاولة استطلاع لمسار أمني محظور: ${reqPath} من IP: ${ip}`);
      return res.status(403).json({ error: 'Access Denied' });
    }
  }

  // 5. PowerShell & Command Injection Payload Scanning (URL, Query, and Body)
  const urlDecoded = decodeURIComponent(req.originalUrl || req.url || '');
  const urlThreat = inspectString(urlDecoded);
  if (urlThreat) {
    logger.warn(`[Firewall] إحباط محاولة حقن أوامر/باور شيل في الرابط (${urlThreat}) من IP: ${ip}`);
    return res.status(400).json({ error: 'Malicious Request Payload Detected' });
  }

  if (req.query) {
    const queryThreat = inspectPayload(req.query);
    if (queryThreat) {
      logger.warn(`[Firewall] إحباط محاولة حقن أوامر في Query Params (${queryThreat}) من IP: ${ip}`);
      return res.status(400).json({ error: 'Malicious Query Parameters Detected' });
    }
  }

  if (req.body) {
    const bodyThreat = inspectPayload(req.body);
    if (bodyThreat) {
      logger.warn(`[Firewall] إحباط محاولة حقن أوامر في Request Body (${bodyThreat}) من IP: ${ip}`);
      return res.status(400).json({ error: 'Malicious Request Body Detected' });
    }
  }

  next();
}

module.exports = antiHackingFirewall;
