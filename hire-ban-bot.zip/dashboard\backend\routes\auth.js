const express = require('express');
const crypto = require('crypto');
const logger = require('../../../src/utils/logger');
const PermissionsGuard = require('../../../src/security/permissions');
const SettingsRepository = require('../../../src/database/repositories/settingsRepository');
const SystemConfigRepository = require('../../../src/database/repositories/systemConfigRepository');
const TotpService = require('../../../src/security/totp');
const { authLimiter } = require('../../../src/middleware/rateLimitMiddleware');

function createAuthRoutes(discordClient) {
  const router = express.Router();

  const { resolveClientSecret } = require('../../../src/utils/securityCipher');
  const CLIENT_ID = process.env.DISCORD_CLIENT_ID || '1553971453253255248';
  const CLIENT_SECRET = resolveClientSecret();
  function getRedirectUri(req) {
    const host = req.headers['x-forwarded-host'] || req.get('host');
    const isLocal = host.includes('localhost') || host.includes('127.0.0.1');
    const proto = isLocal ? 'http' : 'https';
    return `${proto}://${host}/auth/callback`;
  }

  const sessionSecret = process.env.SESSION_SECRET || 'hire-ban-bot-super-secret-key-2026';

  function generateOAuthState() {
    const timestamp = Date.now();
    const nonce = crypto.randomBytes(16).toString('hex');
    const payload = `${timestamp}.${nonce}`;
    const hmac = crypto.createHmac('sha256', sessionSecret).update(payload).digest('hex');
    return `${payload}.${hmac}`;
  }

  function verifyOAuthState(stateStr) {
    if (!stateStr || typeof stateStr !== 'string') return false;
    const parts = stateStr.split('.');
    if (parts.length !== 3) return false;
    const [timestamp, nonce, hmac] = parts;
    const timeNum = Number(timestamp);
    if (isNaN(timeNum)) return false;

    // Check expiry (15 minutes)
    if (Date.now() - timeNum > 15 * 60 * 1000 || Date.now() - timeNum < -60 * 1000) {
      logger.warn('OAuth State expired or timestamp invalid');
      return false;
    }

    const payload = `${timestamp}.${nonce}`;
    const expectedHmac = crypto.createHmac('sha256', sessionSecret).update(payload).digest('hex');

    const hmacBuf = Buffer.from(hmac, 'utf8');
    const expectedBuf = Buffer.from(expectedHmac, 'utf8');
    if (hmacBuf.length !== expectedBuf.length) return false;

    return crypto.timingSafeEqual(hmacBuf, expectedBuf);
  }

  // 1. Initiate OAuth2 Login
  router.get('/login', authLimiter, (req, res) => {
    const clientIp = req.ip || req.connection?.remoteAddress || '';
    const host = req.headers['x-forwarded-host'] || req.get('host') || '';
    const isLocalhost = (clientIp === '127.0.0.1' || clientIp === '::1' || clientIp === '::ffff:127.0.0.1') &&
                        (host.includes('localhost') || host.includes('127.0.0.1'));

    // Direct login is allowed from localhost OR when DEV_MOCK_AUTH is enabled
    if (req.query.direct === 'true') {
      const isMockAllowed = process.env.DEV_MOCK_AUTH === 'true';
      if (!isLocalhost && !isMockAllowed) {
        logger.warn(`محاولة دخول مباشر محظورة ومرفوضة أمنياً من: ${req.ip} على المضيف ${host}`);
        return res.status(403).send('غير مصرح: يرجى استخدام تسجيل الدخول الرسمي أو رمز المرور الإداري.');
      }
      logger.info(`تم تفعيل الدخول المباشر للوحة التحكم (المضيف: ${host}).`);
      const ownerUser = discordClient.application?.owner?.user || discordClient.application?.owner;
      req.session.user = {
        id: ownerUser?.id || 'admin_owner',
        username: ownerUser?.username || 'مدير النظام (Admin)',
        avatar: ownerUser?.avatar || null
      };
      return req.session.save(() => res.redirect('/'));
    }

    if (!CLIENT_ID || !CLIENT_SECRET || CLIENT_SECRET === 'your_discord_client_secret_here') {
      // Auto login if DEV_MOCK_AUTH or localhost
      if (isLocalhost || process.env.DEV_MOCK_AUTH === 'true' || !CLIENT_SECRET) {
        req.session.user = { id: 'admin_owner', username: 'مدير النظام (Admin)', avatar: null };
        return req.session.save(() => res.redirect('/'));
      }
      return res.redirect('/?error=' + encodeURIComponent('يرجى استخدام رمز المرور (admin2026) للدخول الفوري.'));
    }

    const redirectUri = getRedirectUri(req);
    req.session.oauthRedirectUri = redirectUri;

    // Cryptographically signed state (immune to memory resets and cross-site cookie drops)
    const state = generateOAuthState();
    req.session.oauthState = state;

    const authUrl = new URL('https://discord.com/oauth2/authorize');
    authUrl.searchParams.set('client_id', CLIENT_ID);
    authUrl.searchParams.set('redirect_uri', redirectUri);
    authUrl.searchParams.set('response_type', 'code');
    authUrl.searchParams.set('scope', 'identify guilds');
    authUrl.searchParams.set('state', state);

    req.session.save((err) => {
      if (err) logger.error('خطأ أثناء حفظ الجلسة عند تسجيل الدخول:', err.message);
      res.redirect(authUrl.toString());
    });
  });

  // 2. OAuth2 Callback
  router.get('/callback', authLimiter, async (req, res) => {
    const { code, state, error } = req.query;

    if (error) {
      logger.warn(`فشل تسجيل الدخول بواسطة Discord: ${error}`);
      return res.redirect('/?error=' + encodeURIComponent('تم إلغاء تسجيل الدخول بواسطة Discord.'));
    }

    const isStateValid = verifyOAuthState(state) || (req.session?.oauthState && req.session.oauthState === state);
    if (!code || !state || !isStateValid) {
      logger.warn('فشل التحقق من OAuth State (CSRF mismatch or tampered)');
      return res.status(403).send('طلب غير صالح أو تم التلاعب برمز التحقق (State Mismatch). يرجى المحاولة مجدداً.');
    }

    const redirectUri = req.session?.oauthRedirectUri || getRedirectUri(req);
    if (req.session) {
      delete req.session.oauthState;
      delete req.session.oauthRedirectUri;
    }

    try {
      // Exchange code for token
      const tokenResponse = await fetch('https://discord.com/api/v10/oauth2/token', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: new URLSearchParams({
          client_id: CLIENT_ID,
          client_secret: CLIENT_SECRET,
          grant_type: 'authorization_code',
          code,
          redirect_uri: redirectUri
        })
      });

      if (!tokenResponse.ok) {
        const errText = await tokenResponse.text();
        logger.error(`فشل استبدال كود OAuth2: ${errText}`);
        return res.redirect('/?error=' + encodeURIComponent('فشل استبدال رمز الدخول مع Discord.'));
      }

      const tokenData = await tokenResponse.json();
      const accessToken = tokenData.access_token;

      // Fetch user profile
      const userRes = await fetch('https://discord.com/api/v10/users/@me', {
        headers: { Authorization: `Bearer ${accessToken}` }
      });
      const userData = await userRes.json();

      // Fetch user guilds
      const guildsRes = await fetch('https://discord.com/api/v10/users/@me/guilds', {
        headers: { Authorization: `Bearer ${accessToken}` }
      });
      const userGuilds = await guildsRes.json();

      // Compute and cache admin permissions directly from OAuth2 guilds without Discord API bottlenecks
      const adminGuildsMap = {};
      if (Array.isArray(userGuilds)) {
        for (const ug of userGuilds) {
          const isOwner = Boolean(ug.owner);
          let isAdmin = false;
          try {
            const perms = BigInt(ug.permissions || 0);
            isAdmin = (perms & 8n) === 8n;
          } catch {}
          if (isOwner || isAdmin) {
            adminGuildsMap[ug.id] = { isOwner, isAdmin: true };
          }
        }
      }
      req.session.adminGuilds = adminGuildsMap;

      req.session.user = {
        id: userData.id,
        username: userData.username,
        discriminator: userData.discriminator,
        avatar: userData.avatar
      };

      req.session.accessToken = accessToken;
      logger.success(`تم تسجيل دخول المستخدم عبر الداشبورد: ${userData.username} [${userData.id}]`);

      req.session.save((saveErr) => {
        if (saveErr) logger.error('خطأ أثناء حفظ الجلسة في callback:', saveErr.message);
        res.redirect('/');
      });
    } catch (err) {
      logger.error('خطأ غير متوقع في OAuth callback:', err.message);
      res.redirect('/?error=' + encodeURIComponent('حدث خطأ أثناء إتمام عملية تسجيل الدخول.'));
    }
  });

  // 3. User Session Info & Accessible Guilds (Instant 0ms lookup)
  router.get('/me', (req, res) => {
    if (!req.session || !req.session.user) {
      return res.json({ authenticated: false });
    }

    const userId = req.session.user.id;
    const accessibleGuilds = [];
    const adminGuilds = req.session.adminGuilds || {};

    for (const [guildId, guild] of discordClient.guilds.cache) {
      const isOwner = guild.ownerId === userId || Boolean(adminGuilds[guildId]?.isOwner);
      const isAdmin = Boolean(adminGuilds[guildId]?.isAdmin) || isOwner;

      const cachedMember = guild.members.cache.get(userId);
      const isCachedAdmin = cachedMember?.permissions?.has(8n);

      if (isOwner || isAdmin || isCachedAdmin || (userId === 'admin_owner' && process.env.DEV_MOCK_AUTH === 'true')) {
        accessibleGuilds.push({
          id: guild.id,
          name: guild.name,
          icon: guild.iconURL() || null,
          memberCount: guild.memberCount,
          canManageSettings: true
        });
      }
    }

    // Fallback ONLY for local development direct mode (admin_owner)
    if (userId === 'admin_owner' && process.env.DEV_MOCK_AUTH === 'true') {
      for (const [guildId, guild] of discordClient.guilds.cache) {
        if (!accessibleGuilds.some(g => g.id === guild.id)) {
          accessibleGuilds.push({
            id: guild.id,
            name: guild.name,
            icon: guild.iconURL() || null,
            memberCount: guild.memberCount,
            canManageSettings: true
          });
        }
      }
    }

    res.json({
      authenticated: true,
      user: req.session.user,
      csrfToken: req.session.csrfToken,
      guilds: accessibleGuilds
    });
  });

  // 4. Admin Passcode Login (with optional 2FA / Google Authenticator)
  router.post('/passcode', authLimiter, (req, res) => {
    const { passcode, totpToken } = req.body || {};
    const masterKey = process.env.ADMIN_PASSCODE || 'admin2026';

    if (!passcode || typeof passcode !== 'string' || passcode.trim() !== masterKey) {
      logger.warn(`محاولة دخول برمز مرور غير صالح من: ${req.ip}`);
      return res.status(401).json({ error: 'رمز المرور غير صحيح. يرجى التأكد وإعادة المحاولة.' });
    }

    // Check if 2FA is active
    const is2faActive = SystemConfigRepository.is2FAEnabled() || Boolean(process.env.ADMIN_2FA_SECRET);
    if (is2faActive) {
      const secret = SystemConfigRepository.get2FASecret() || process.env.ADMIN_2FA_SECRET;
      if (!totpToken) {
        return res.json({ require2fa: true, message: 'يرجى إدخال رمز المصادقة الثنائية (2FA)' });
      }
      const isValid = TotpService.verifyToken(totpToken, secret);
      if (!isValid) {
        return res.status(401).json({ error: 'رمز التحقق (2FA) غير صحيح أو منتهي الصلاحية.' });
      }
    }

    const ownerUser = discordClient.application?.owner?.user || discordClient.application?.owner;
    req.session.user = {
      id: ownerUser?.id || 'admin_owner',
      username: ownerUser?.username || 'مدير النظام (Admin)',
      avatar: ownerUser?.avatar || null
    };

    req.session.save((err) => {
      if (err) {
        logger.error('خطأ في حفظ جلسة الدخول برمز المرور:', err.message);
        return res.status(500).json({ error: 'تعذر حفظ الجلسة' });
      }
      logger.info(`تم تسجيل دخول المدير بنجاح ${is2faActive ? '(مع 2FA)' : ''} من: ${req.ip}`);
      res.json({ success: true, redirect: '/' });
    });
  });

  // 5. Get 2FA Status
  router.get('/2fa/status', (req, res) => {
    const enabled = SystemConfigRepository.is2FAEnabled() || Boolean(process.env.ADMIN_2FA_SECRET);
    res.json({ enabled });
  });

  // 6. Setup 2FA: Generate Secret & QR Code
  router.get('/2fa/setup', (req, res) => {
    if (!req.session?.user) {
      return res.status(401).json({ error: 'يجب تسجيل الدخول أولاً كمدير لتفعيل المصادقة الثنائية.' });
    }
    const secret = TotpService.generateSecret(16);
    req.session.tempTotpSecret = secret;

    const otpAuthUrl = TotpService.getOtpAuthUrl({
      issuer: 'بوت منع التوظيف',
      accountName: req.session.user.username || 'Admin',
      secret
    });
    const qrUrl = TotpService.getQrCodeUrl(otpAuthUrl);

    res.json({
      success: true,
      secret,
      otpAuthUrl,
      qrUrl
    });
  });

  // 7. Verify and Activate 2FA
  router.post('/2fa/enable', (req, res) => {
    if (!req.session?.user) {
      return res.status(401).json({ error: 'غير مصرح' });
    }
    const { token } = req.body || {};
    const secret = req.session.tempTotpSecret;

    if (!secret) {
      return res.status(400).json({ error: 'انتهت صلاحية جلسة الإعداد. يرجى طلب باركود جديد.' });
    }

    const isValid = TotpService.verifyToken(token, secret);
    if (!isValid) {
      return res.status(400).json({ error: 'الرمز غير صحيح. تأكد من إدخال الرمز المكون من 6 أرقام من تطبيق Authenticator.' });
    }

    SystemConfigRepository.enable2FA(secret);
    delete req.session.tempTotpSecret;
    logger.success(`تم تفعيل المصادقة الثنائية (2FA) بنجاح للمدير.`);
    res.json({ success: true, message: 'تم تفعيل المصادقة الثنائية (2FA) بنجاح وحماية لوحة التحكم!' });
  });

  // 8. Disable 2FA
  router.post('/2fa/disable', (req, res) => {
    if (!req.session?.user) {
      return res.status(401).json({ error: 'غير مصرح' });
    }
    const { passcode } = req.body || {};
    const masterKey = process.env.ADMIN_PASSCODE || 'admin2026';
    if (!passcode || passcode.trim() !== masterKey) {
      return res.status(401).json({ error: 'رمز المرور غير صحيح لتأكيد الإلغاء.' });
    }

    SystemConfigRepository.disable2FA();
    logger.info('تم تعطيل المصادقة الثنائية (2FA).');
    res.json({ success: true, message: 'تم تعطيل المصادقة الثنائية بنجاح.' });
  });

  // 5. Logout
  router.all('/logout', (req, res) => {
    req.session.destroy(() => {
      res.clearCookie('connect.sid');
      if (req.method === 'GET') {
        return res.redirect('/');
      }
      res.json({ success: true });
    });
  });

  return router;
}

module.exports = createAuthRoutes;
