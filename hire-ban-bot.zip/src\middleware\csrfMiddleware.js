const crypto = require('crypto');

/**
 * Lightweight and robust CSRF protection middleware for sessions
 */
function csrfProtection(req, res, next) {
  if (!req.session) {
    return next();
  }

  // Ensure a CSRF secret/token exists for this session
  if (!req.session.csrfToken) {
    req.session.csrfToken = crypto.randomBytes(32).toString('hex');
  }

  // Read-only methods don't require CSRF validation
  if (['GET', 'HEAD', 'OPTIONS'].includes(req.method)) {
    // Send token in response header or cookie for client-side consumption
    res.setHeader('X-CSRF-Token', req.session.csrfToken);
    return next();
  }

  // Auth login endpoints are protected by authLimiter and do not require pre-CSRF
  if (req.originalUrl?.startsWith('/auth/')) {
    return next();
  }

  // State-changing requests (POST, PUT, DELETE, PATCH)
  const clientToken = req.headers['x-csrf-token'] || req.body?._csrf;

  if (!clientToken || clientToken !== req.session.csrfToken) {
    return res.status(403).json({
      error: 'رمز التحقق الأمني (CSRF Token) غير صالح أو منتهي الصلاحية. يرجى تحديث الصفحة والمحاولة مجدداً.'
    });
  }

  next();
}

module.exports = csrfProtection;
