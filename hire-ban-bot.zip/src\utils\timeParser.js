/**
 * Time parsing and formatting utility for Hire Ban Bot
 */

/**
 * Parse human duration input into seconds.
 * Supports:
 * - Direct numbers with unit (e.g. value=7, unit='d' or 'days')
 * - String expressions (e.g. "7d", "24h", "3 days", "ساعتين", "3 ايام", "دائم")
 * Returns: { seconds: number | null, isPermanent: boolean, error?: string }
 */
function parseDuration(input, unit = null) {
  if (input === null || input === undefined) {
    return { seconds: null, isPermanent: false, error: 'المدة مطلوبة' };
  }

  const str = String(input)
    .trim()
    .toLowerCase()
    .replace(/[\u064B-\u065F\u0640]/g, ''); // strip tashkeel & tatweel

  // Reject negative numbers or symbols immediately
  if (str.startsWith('-') || /-\s*\d+/.test(str)) {
    return { seconds: null, isPermanent: false, error: 'المدة لا يمكن أن تكون قيمة سالبة.' };
  }

  // Check permanent keywords
  if (['permanent', 'perm', 'دائم', 'نهائي', 'ابدي', 'أبدي', 'infinity', 'inf'].includes(str)) {
    return { seconds: null, isPermanent: true };
  }

  // Common Arabic single/dual duration expressions
  if (str === 'ساعة' || str === 'ساعه' || str === '1 ساعة' || str === '1 ساعه') return { seconds: 3600, isPermanent: false };
  if (str === 'ساعتين' || str === 'ساعتان' || str === '2 ساعة') return { seconds: 7200, isPermanent: false };
  if (str === 'يوم' || str === '1 يوم') return { seconds: 86400, isPermanent: false };
  if (str === 'يومين' || str === 'يومان' || str === '2 يوم') return { seconds: 172800, isPermanent: false };
  if (str === 'اسبوع' || str === 'أسبوع' || str === '1 اسبوع') return { seconds: 604800, isPermanent: false };
  if (str === 'اسبوعين' || str === 'أسبوعين' || str === '2 اسبوع') return { seconds: 1209600, isPermanent: false };
  if (str === 'شهر' || str === '1 شهر') return { seconds: 2592000, isPermanent: false };
  if (str === 'شهرين' || str === '2 شهر') return { seconds: 5184000, isPermanent: false };

  // If both input and unit are provided (e.g. from Slash Command options)
  if (unit) {
    const num = parseFloat(str);
    if (isNaN(num) || num <= 0) {
      return { seconds: null, isPermanent: false, error: 'قيمة المدة غير صالحة' };
    }
    const u = unit.toLowerCase();
    if (['h', 'hour', 'hours', 'ساعة', 'ساعات', 'ساعه'].includes(u)) {
      return { seconds: Math.round(num * 3600), isPermanent: false };
    }
    if (['d', 'day', 'days', 'يوم', 'ايام', 'أيام'].includes(u)) {
      return { seconds: Math.round(num * 86400), isPermanent: false };
    }
    if (['m', 'min', 'minute', 'minutes', 'دقيقة', 'دقائق', 'دقيقه'].includes(u)) {
      return { seconds: Math.round(num * 60), isPermanent: false };
    }
    if (['w', 'week', 'weeks', 'اسبوع', 'أسبوع', 'اسابيع', 'أسابيع'].includes(u)) {
      return { seconds: Math.round(num * 604800), isPermanent: false };
    }
    if (['perm', 'permanent', 'دائم'].includes(u)) {
      return { seconds: null, isPermanent: true };
    }
  }

  // Try parsing combined string like "2d 4h" or "7d" or "24h"
  const regex = /(\d+)\s*(d|day|days|h|hour|hours|m|min|minutes|w|week|weeks|يوم|ايام|أيام|ساعة|ساعات|ساعه|دقيقة|دقائق|دقيقه|اسبوع|أسبوع|اسابيع|أسابيع|شهر|اشهر)/gi;
  let match;
  let totalSeconds = 0;
  let matchesCount = 0;

  while ((match = regex.exec(str)) !== null) {
    matchesCount++;
    const val = parseInt(match[1], 10);
    const u = match[2].toLowerCase();

    if (['d', 'day', 'days', 'يوم', 'ايام', 'أيام'].includes(u)) {
      totalSeconds += val * 86400;
    } else if (['h', 'hour', 'hours', 'ساعة', 'ساعات', 'ساعه'].includes(u)) {
      totalSeconds += val * 3600;
    } else if (['m', 'min', 'minutes', 'دقيقة', 'دقائق', 'دقيقه'].includes(u)) {
      totalSeconds += val * 60;
    } else if (['w', 'week', 'weeks', 'اسبوع', 'أسبوع', 'اسابيع', 'أسابيع'].includes(u)) {
      totalSeconds += val * 604800;
    } else if (['شهر', 'اشهر'].includes(u)) {
      totalSeconds += val * 2592000;
    }
  }

  let result = null;
  if (matchesCount > 0 && totalSeconds > 0) {
    result = { seconds: totalSeconds, isPermanent: false };
  } else {
    // If user passed a bare number, default to hours
    const bareNum = parseFloat(str);
    if (!isNaN(bareNum) && bareNum > 0 && isFinite(bareNum)) {
      result = { seconds: Math.round(bareNum * 3600), isPermanent: false };
    } else {
      return { seconds: null, isPermanent: false, error: 'تنسيق المدة غير مفهوم. مثال: 7d أو 24h أو 3 ايام أو دائم' };
    }
  }

  // Boundary checks: minimum 60 seconds, maximum 10 years (315,360,000 seconds)
  const MIN_SECONDS = 60;
  const MAX_SECONDS = 315360000;

  if (result.seconds !== null) {
    if (isNaN(result.seconds) || !isFinite(result.seconds) || result.seconds <= 0) {
      return { seconds: null, isPermanent: false, error: 'قيمة المدة غير صالحة.' };
    }
    if (result.seconds < MIN_SECONDS) {
      return { seconds: null, isPermanent: false, error: 'الحد الأدنى للمنع المؤقت هو دقيقة واحدة (60 ثانية).' };
    }
    if (result.seconds > MAX_SECONDS) {
      return { seconds: null, isPermanent: false, error: 'الحد الأقصى للمنع المؤقت هو 10 سنوات (3650 يوماً). للمدد الأطول اختر منع دائم.' };
    }
  }

  return result;
}

/**
 * Format seconds into Arabic readable duration
 */
function formatDuration(seconds) {
  if (seconds === null || seconds === undefined) {
    return 'منع دائم';
  }
  if (seconds <= 0) {
    return 'منتهي الصلاحية';
  }

  const days = Math.floor(seconds / 86400);
  const remainingAfterDays = seconds % 86400;
  const hours = Math.floor(remainingAfterDays / 3600);
  const remainingAfterHours = remainingAfterDays % 3600;
  const minutes = Math.floor(remainingAfterHours / 60);
  const remainingSeconds = remainingAfterHours % 60;

  const parts = [];
  if (days > 0) {
    if (days === 1) parts.push('يوم واحد');
    else if (days === 2) parts.push('يومان');
    else if (days >= 3 && days <= 10) parts.push(`${days} أيام`);
    else parts.push(`${days} يوماً`);
  }

  if (hours > 0) {
    if (hours === 1) parts.push('ساعة واحدة');
    else if (hours === 2) parts.push('ساعتان');
    else if (hours >= 3 && hours <= 10) parts.push(`${hours} ساعات`);
    else parts.push(`${hours} ساعة`);
  }

  if (minutes > 0) {
    if (minutes === 1) parts.push('دقيقة واحدة');
    else if (minutes === 2) parts.push('دقيقتان');
    else if (minutes >= 3 && minutes <= 10) parts.push(`${minutes} دقائق`);
    else parts.push(`${minutes} دقيقة`);
  }

  if (parts.length === 0) {
    return `${remainingSeconds} ثانية`;
  }

  return parts.join(' و ');
}

/**
 * Format timestamp into Discord timestamp format and Arabic string
 */
function formatDiscordTimestamp(isoString) {
  if (!isoString) return 'منع دائم';
  const timestamp = Math.floor(new Date(isoString).getTime() / 1000);
  return `<t:${timestamp}:F> (<t:${timestamp}:R>)`;
}

/**
 * Compute expiration ISO string given seconds from now
 */
function calculateExpiresAt(seconds) {
  if (seconds === null || seconds === undefined) {
    return null; // permanent
  }
  const date = new Date(Date.now() + Math.round(seconds) * 1000);
  return date.toISOString();
}

module.exports = {
  parseDuration,
  formatDuration,
  formatDiscordTimestamp,
  calculateExpiresAt
};
