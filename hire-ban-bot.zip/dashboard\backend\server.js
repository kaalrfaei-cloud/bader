const express = require('express');
const session = require('express-session');
const helmet = require('helmet');
const cors = require('cors');
const compression = require('compression');
const path = require('path');
const logger = require('../../src/utils/logger');
const csrfProtection = require('../../src/middleware/csrfMiddleware');
const { apiLimiter } = require('../../src/middleware/rateLimitMiddleware');
const createAuthRoutes = require('./routes/auth');
const createApiRoutes = require('./routes/api');

function createDashboardServer(discordClient) {
  const app = express();

  // Hide server fingerprint
  app.disable('x-powered-by');

  // Enable trust proxy for reverse proxies / Cloudflare
  app.set('trust proxy', true);

  // Compress all responses with gzip for maximum performance (خفيف وسريع)
  app.use(compression());

  // Security Headers via Helmet (with CSP disabled to ensure smooth modal, script, and dropdown interactivity)
  app.use(helmet({
    contentSecurityPolicy: false,
    crossOriginEmbedderPolicy: false
  }));

  app.use(cors({
    origin: true,
    credentials: true
  }));

  app.use(express.json({ limit: '1mb' }));
  app.use(express.urlencoded({ extended: true, limit: '1mb' }));

  // Session configuration with hardened cookies
  const sessionSecret = process.env.SESSION_SECRET || 'hire-ban-bot-super-secret-key-2026';
  app.use(session({
    secret: sessionSecret,
    resave: false,
    saveUninitialized: false,
    cookie: {
      httpOnly: true,
      secure: 'auto', // Auto-enforces secure over HTTPS / Cloudflare
      sameSite: 'lax',
      maxAge: 7 * 24 * 60 * 60 * 1000 // 7 days
    }
  }));

  // Apply CSRF protection
  app.use(csrfProtection);

  // Serve static assets with caching headers for fast delivery
  const publicDir = path.resolve(__dirname, '../frontend/public');
  app.use(express.static(publicDir, {
    maxAge: '1h',
    etag: true
  }));

  // Mount Auth routes
  app.use('/auth', createAuthRoutes(discordClient));

  // Mount API routes with rate limiter
  app.use('/api', apiLimiter, createApiRoutes(discordClient));

  // Fallback route for SPA dashboard
  app.use((req, res) => {
    res.sendFile(path.join(publicDir, 'index.html'));
  });

  // Global Error Handler
  app.use((err, req, res, next) => {
    logger.error('خطأ غير معالج في خادم الداشبورد:', err.message);
    if (res.headersSent) {
      return next(err);
    }
    res.status(500).json({ error: 'حدث خطأ داخلي في خادم لوحة التحكم.' });
  });

  return app;
}

module.exports = { createDashboardServer };
