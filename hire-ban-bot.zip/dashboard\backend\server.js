const express = require('express');
const session = require('express-session');
const helmet = require('helmet');
const cors = require('cors');
const compression = require('compression');
const path = require('path');
const logger = require('../../src/utils/logger');
const csrfProtection = require('../../src/middleware/csrfMiddleware');
const SQLiteSessionStore = require('../../src/security/sqliteSessionStore');
const { apiLimiter } = require('../../src/middleware/rateLimitMiddleware');
const createAuthRoutes = require('./routes/auth');
const createApiRoutes = require('./routes/api');

function createDashboardServer(discordClient) {
  const app = express();

  // Hide server fingerprint
  app.disable('x-powered-by');

  // Trust proxy for reverse proxies / Cloudflare / Render
  app.set('trust proxy', true);

  // Compress all responses with gzip for maximum performance
  app.use(compression());

  // Security Headers via Helmet
  app.use(helmet({
    contentSecurityPolicy: false,
    crossOriginEmbedderPolicy: false
  }));

  // Restrict CORS: Allow only trusted origins (Dashboard URL, Render subdomains, and local dev)
  app.use(cors({
    origin: (origin, callback) => {
      // Allow requests with no origin (e.g. same-origin navigations, direct requests)
      if (!origin) return callback(null, true);

      const isAllowed =
        origin.includes('localhost') ||
        origin.includes('127.0.0.1') ||
        origin.endsWith('.onrender.com') ||
        (process.env.DASHBOARD_URL && origin.startsWith(process.env.DASHBOARD_URL));

      if (isAllowed) {
        callback(null, true);
      } else {
        callback(null, false);
      }
    },
    credentials: true
  }));

  app.use(express.json({ limit: '1mb' }));
  app.use(express.urlencoded({ extended: true, limit: '1mb' }));

  // Session configuration with database store (SQLite) & hardened cookies
  const isProd = process.env.NODE_ENV === 'production';
  const sessionSecret = process.env.SESSION_SECRET || (isProd ? null : 'hire-ban-bot-dev-secret-key-2026');

  if (isProd && !sessionSecret) {
    logger.error('CRITICAL SECURITY ERROR: SESSION_SECRET must be configured in production!');
    process.exit(1);
  }

  const sessionStore = new SQLiteSessionStore({
    ttl: 12 * 3600 // 12 hours
  });

  app.use(session({
    store: sessionStore,
    secret: sessionSecret || 'hire-ban-bot-dev-fallback-key',
    resave: false,
    saveUninitialized: false,
    name: '__Host-hireban_sid',
    cookie: {
      httpOnly: true,
      secure: isProd ? true : 'auto', // Enforce secure cookies on HTTPS
      sameSite: 'lax',
      maxAge: 12 * 60 * 60 * 1000 // 12 hours
    }
  }));

  // Apply CSRF protection across state-mutating requests
  app.use(csrfProtection);

  // Serve static assets with caching headers strictly from frontend/public directory
  const publicDir = path.resolve(__dirname, '../frontend/public');
  app.use(express.static(publicDir, {
    maxAge: '1h',
    etag: true,
    dotfiles: 'ignore' // NEVER serve hidden files like .env
  }));

  // Mount Auth routes
  app.use('/auth', createAuthRoutes(discordClient));

  // Mount API routes with general rate limiter
  app.use('/api', apiLimiter, createApiRoutes(discordClient));

  // Fallback route for SPA dashboard
  app.use((req, res) => {
    res.sendFile(path.join(publicDir, 'index.html'));
  });

  // Global Secure Error Handler (No sensitive leaks to client)
  app.use((err, req, res, next) => {
    logger.error('خطأ غير معالج في خادم الداشبورد:', err.stack || err.message);
    if (res.headersSent) {
      return next(err);
    }
    const statusCode = err.status || 500;
    const clientMessage = isProd
      ? 'حدث خطأ داخلي في خادم لوحة التحكم.'
      : (err.message || 'حدث خطأ داخلي.');

    res.status(statusCode).json({ error: clientMessage });
  });

  return app;
}

module.exports = { createDashboardServer };
