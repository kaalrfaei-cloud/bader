const { EmbedBuilder } = require('discord.js');
const SettingsRepository = require('../../database/repositories/settingsRepository');
const BanRepository = require('../../database/repositories/banRepository');
const { formatDuration } = require('../../utils/timeParser');
const logger = require('../../utils/logger');

async function handleBanCheck(message, targetUserId, targetUser, isSelf) {
  const activeBan = BanRepository.getActiveBan(message.guild.id, targetUserId);
  const targetTag = targetUser ? (targetUser.tag || targetUser.username) : `المعرف: ${targetUserId}`;

  if (!activeBan) {
    const embed = new EmbedBuilder()
      .setColor('#10b981')
      .setTitle('✅ لا يوجد منع توظيف')
      .setDescription(
        isSelf
          ? `أهلاً بك <@${targetUserId}>، **ليس لديك أي منع توظيف حالياً** في سيرفر **${message.guild.name}** ويمكنك التوظيف بشكل طبيعي.`
          : `العضو <@${targetUserId}> (${targetTag}) **ليس لديه أي منع توظيف حالياً** في هذا السيرفر.`
      )
      .setFooter({ text: 'نظام الاستعلام عن منع التوظيف • روم المواطنين' })
      .setTimestamp();

    return message.reply({ embeds: [embed] }).catch(() => {});
  }

  // Active ban found! Calculate remaining duration
  let remainingText = '';
  let expiresTimestampText = '';

  if (activeBan.expires_at) {
    const expiresMs = new Date(activeBan.expires_at).getTime();
    const remainingMs = expiresMs - Date.now();

    if (remainingMs <= 0) {
      remainingText = 'منتهي الصلاحية (جاري الرفع تلقائياً عبر النظام)';
      expiresTimestampText = 'انتهى';
    } else {
      const remainingSecs = Math.floor(remainingMs / 1000);
      const formatted = formatDuration(remainingSecs);
      const discordTimestamp = Math.floor(expiresMs / 1000);
      remainingText = `⏳ **${formatted}** (<t:${discordTimestamp}:R>)`;
      expiresTimestampText = `<t:${discordTimestamp}:F>`;
    }
  } else {
    remainingText = '♾️ **منع دائم**';
    expiresTimestampText = 'منع دائم (غير محدد التاريخ)';
  }

  const startTimestamp = Math.floor(new Date(activeBan.created_at).getTime() / 1000);

  const embed = new EmbedBuilder()
    .setColor('#ef4444')
    .setTitle('🚫 تفاصيل منع التوظيف')
    .setDescription(
      isSelf
        ? `تنبيه <@${targetUserId}>، يوجد عليك **منع توظيف نشط** حالياً في هذا السيرفر.`
        : `تنبيه: العضو <@${targetUserId}> لديه **منع توظيف نشط** حالياً في هذا السيرفر.`
    )
    .addFields(
      { name: '👤 العضو', value: `<@${targetUserId}> (${targetTag})`, inline: true },
      { name: '📋 الحالة', value: '🔴 **منع توظيف نشط**', inline: true },
      { name: '⏳ الوقت المتبقي', value: remainingText, inline: false },
      { name: '📝 سبب المنع', value: activeBan.reason || 'لا يوجد سبب مسجل', inline: false },
      { name: '📅 تاريخ البداية', value: `<t:${startTimestamp}:F> (<t:${startTimestamp}:R>)`, inline: true },
      { name: '⏰ تاريخ الانتهاء', value: expiresTimestampText, inline: true }
    )
    .setFooter({ text: 'بـوت مـنـع الـتـوظـيـف • روم المواطنين' })
    .setTimestamp();

  return message.reply({ embeds: [embed] }).catch(() => {});
}

module.exports = {
  name: 'messageCreate',
  once: false,
  async execute(message) {
    // 1. Ignore bot messages and non-guild channels
    if (!message || message.author.bot || !message.guild) return;

    // 2. Fetch guild settings to check citizen channel
    let settings;
    try {
      settings = SettingsRepository.getSettings(message.guild.id);
    } catch (e) {
      return;
    }

    const citizenChannelId = settings.citizen_channel_id;

    // 3. Only enforce rules inside the citizen channel
    if (!citizenChannelId || message.channel.id !== citizenChannelId) {
      return;
    }

    const content = message.content ? message.content.trim() : '';

    // Check pattern 1: Exactly "منع" (Check author's own ban)
    const selfCheckRegex = /^منع$/i;
    // Check pattern 2: "منع @user" or "منع <ID>" (Check specified user's ban)
    const targetCheckRegex = /^منع\s+(?:<@!?(\d+)>|(\d{17,20}))$/i;

    if (selfCheckRegex.test(content)) {
      await handleBanCheck(message, message.author.id, message.author, true);
      return;
    }

    const targetMatch = content.match(targetCheckRegex);
    if (targetMatch) {
      const targetUserId = targetMatch[1] || targetMatch[2];
      let targetUser = null;
      try {
        targetUser = await message.client.users.fetch(targetUserId).catch(() => null);
      } catch {}
      await handleBanCheck(message, targetUserId, targetUser, false);
      return;
    }

    // Any other message in this room is strictly deleted
    try {
      await message.delete();
      const warning = await message.channel.send({
        content: `⚠️ <@${message.author.id}> هذا الروم مخصص فقط للاستعلام عن منع التوظيف.\n**الأوامر المتاحة:**\n• \`منع\` (لفحص المنع عن نفسك)\n• \`منع @منشن\` (لفحص مدة المنع لعضو آخر)`
      }).catch(() => null);

      if (warning) {
        setTimeout(() => warning.delete().catch(() => {}), 5000);
      }
    } catch (err) {
      logger.warn(`تعذر حذف الرسالة غير المصرح بها في روم المواطنين: ${err.message}`);
    }
  }
};
