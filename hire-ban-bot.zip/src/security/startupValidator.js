const logger = require('../utils/logger');
const { getDb } = require('../database/db');
const { resolveBotToken } = require('../utils/securityCipher');

class StartupValidator {
  /**
   * Validate critical environment and security configurations before application startup.
   * Halts startup if critical security requirements are missing.
   */
  static validateEnvironment() {
    const errors = [];
    const warnings = [];

    // 1. Encryption Key
    const encKey = process.env.ENCRYPTION_KEY;
    if (!encKey || !encKey.trim()) {
      errors.push('ENCRYPTION_KEY غير موجود في متغيرات البيئة. مطلوب لتشفير الأسرار وحماية النظام.');
    } else if (encKey.trim().length < 16) {
      warnings.push('ENCRYPTION_KEY قصير جداً (أقل من 16 حرفاً). يوصى باستخدام مفتاح تشفير 32 حرفاً أو أكثر.');
    }

    // 2. Admin Passcode
    const adminPasscode = process.env.ADMIN_PASSCODE;
    if (!adminPasscode || !adminPasscode.trim()) {
      errors.push('ADMIN_PASSCODE غير موجود في متغيرات البيئة. يمنع النظام وجود كلمة مرور افتراضية لحماية لوحة التحكم.');
    } else if (adminPasscode.trim() === 'admin2026' || adminPasscode.trim() === 'admin' || adminPasscode.trim() === '123456') {
      errors.push('ADMIN_PASSCODE المستخدم ضعيف جداً أو افتراضي (غير مسموح بكلمة مرور سهلة أو افتراضية).');
    }

    // 3. Discord Bot Token
    let token = '';
    try {
      token = resolveBotToken();
    } catch (e) {
      errors.push(`فشل استرجاع توكن الديسكورد: ${e.message}`);
    }
    if (!token) {
      if (process.env.NODE_ENV === 'production') {
        errors.push('DISCORD_TOKEN غير موجود في متغيرات البيئة.');
      } else {
        warnings.push('DISCORD_TOKEN غير محدد. سيعمل البوت في وضع الاستعداد.');
      }
    }

    // 4. Session Secret
    const sessionSecret = process.env.SESSION_SECRET;
    if (!sessionSecret || sessionSecret === 'hire-ban-bot-security-secret-2026') {
      warnings.push('SESSION_SECRET يستخدم قيمة افتراضية. يوصى بتعيين قيمة سرية قوية في متغيرات البيئة.');
    }

    // 5. Database check
    try {
      const db = getDb();
      db.prepare('SELECT 1').get();
    } catch (dbErr) {
      errors.push(`فشل الاتصال بقاعدة البيانات: ${dbErr.message}`);
    }

    return {
      isValid: errors.length === 0,
      errors,
      warnings
    };
  }

  /**
   * Validate Discord client permissions, roles and channels once client is ready
   */
  static async validateDiscordState(client) {
    const SettingsRepository = require('../database/repositories/settingsRepository');
    const { PermissionsBitField } = require('discord.js');

    logger.info('🔍 جاري فحص حالة واتصال سيرفرات Discord والصلاحيات...');
    if (!client.guilds || !client.guilds.cache || !client.guilds.cache.size) {
      logger.warn('⚠️ البوت غير متواجد في أي سيرفر ديسكورد حالياً أو في انتظار المزامنة.');
      return;
    }

    const REQUIRED_PERMS = [
      PermissionsBitField.Flags.ManageRoles,
      PermissionsBitField.Flags.ViewChannel,
      PermissionsBitField.Flags.SendMessages,
      PermissionsBitField.Flags.EmbedLinks,
      PermissionsBitField.Flags.ViewAuditLog
    ];

    for (const [guildId, guild] of client.guilds.cache) {
      const me = guild.members?.me;
      if (!me) continue;

      // Check bot permissions
      const missingPerms = REQUIRED_PERMS.filter(p => !me.permissions.has(p));
      if (missingPerms.length > 0) {
        logger.warn(`⚠️ البوت يفتقر إلى بعض الصلاحيات الأساسية في سيرفر [${guild.name}] (${guildId})!`);
      }

      // Check Guild Settings
      const settings = SettingsRepository.getSettings(guildId);
      if (settings.ban_role_id) {
        const role = guild.roles?.cache?.get(settings.ban_role_id);
        if (!role) {
          logger.warn(`⚠️ رتبة منع التوظيف المحددة في الإعدادات غير موجودة بالسيرفر [${guild.name}].`);
        } else if (me.roles.highest.position <= role.position) {
          logger.error(`❌ خطأ Hierarchy في سيرفر [${guild.name}]: رتبة منع التوظيف أعلى أو مساوية لرتبة البوت! البوت لن يتمكن من إعطاء أو سحب الرتبة.`);
        }
      }
    }
    logger.success('✅ اكتمل فحص تكوين وتوافق الديسكورد بنجاح.');
  }
}

module.exports = StartupValidator;
