const logger = require('../utils/logger');
const { getDb } = require('../database/db');
const { resolveBotToken } = require('../utils/securityCipher');

const INSECURE_DEFAULT_PASSCODES = new Set([
  'admin2026',
  'admin',
  '123456',
  '12345678',
  'password',
  'root',
  'qwerty',
  'Master_Admin_2026_StrongPass!'
]);

class StartupValidator {
  /**
   * Validate critical environment and security configurations before application startup.
   * Halts startup if critical security requirements are missing in production.
   */
  static validateEnvironment() {
    const errors = [];
    const warnings = [];
    const isProd = process.env.NODE_ENV === 'production';

    // 1. Encryption Key
    const encKey = process.env.ENCRYPTION_KEY;
    if (encKey && encKey.trim().length < 16) {
      warnings.push('ENCRYPTION_KEY قصير جداً (أقل من 16 حرفاً). يوصى باستخدام 32 حرفاً عشوائياً قوياً.');
    }

    // 2. Admin Passcode
    const adminPasscode = process.env.ADMIN_PASSCODE ? process.env.ADMIN_PASSCODE.trim() : '';
    if (!adminPasscode) {
      errors.push('ADMIN_PASSCODE غير موجود في متغيرات البيئة. يمنع النظام وجود كلمة مرور افتراضية لحماية لوحة التحكم.');
    } else if (INSECURE_DEFAULT_PASSCODES.has(adminPasscode) || adminPasscode.length < 10) {
      errors.push('ADMIN_PASSCODE المستخدم ضعيف جداً أو افتراضي غير آمن (يجب أن يتكون من 10 أحرف قوية على الأقل وغير افتراضية).');
    }

    // 3. Discord Bot Token
    let token = '';
    try {
      token = resolveBotToken();
    } catch (e) {
      errors.push(`فشل استرجاع توكن الديسكورد: ${e.message}`);
    }

    if (!token) {
      if (isProd) {
        errors.push('DISCORD_TOKEN غير موجود في متغيرات البيئة أو فشل فك تشفيره.');
      } else {
        warnings.push('DISCORD_TOKEN غير محدد. سيعمل البوت في وضع الاستعداد.');
      }
    }

    // 4. Session Secret
    const sessionSecret = process.env.SESSION_SECRET ? process.env.SESSION_SECRET.trim() : '';
    const isDefaultSessionSecret = !sessionSecret ||
      sessionSecret === 'hire-ban-bot-security-secret-2026' ||
      sessionSecret === 'hire-ban-bot-dev-fallback-key' ||
      sessionSecret.length < 32;

    if (isProd) {
      if (isDefaultSessionSecret) {
        errors.push('SESSION_SECRET غير محدد أو يستخدم قيمة افتراضية ضعيفة في الإنتاج (يجب ألا يقل عن 32 حرفاً عشوائياً قوياً).');
      }
    } else {
      if (isDefaultSessionSecret) {
        warnings.push('SESSION_SECRET يستخدم قيمة افتراضية للتطوير. يجب تعيين قيمة عشوائية قوية عند النشر للإنتاج.');
      }
    }

    // 5. Database check
    try {
      const db = getDb();
      db.prepare('SELECT 1').get();
    } catch (dbErr) {
      errors.push(`فشل الاتصال بقاعدة البيانات: ${dbErr.message}`);
    }

    return {
      isValid: errors.length === 0,
      errors,
      warnings
    };
  }

  /**
   * Validate Discord client permissions, roles and channels once client is ready
   */
  static async validateDiscordState(client) {
    const SettingsRepository = require('../database/repositories/settingsRepository');
    const { PermissionsBitField } = require('discord.js');

    logger.info('🔍 جاري فحص حالة واتصال سيرفرات Discord والصلاحيات...');
    if (!client.guilds || !client.guilds.cache || !client.guilds.cache.size) {
      logger.warn('⚠️ البوت غير متواجد في أي سيرفر ديسكورد حالياً أو في انتظار المزامنة.');
      return;
    }

    const REQUIRED_PERMS = [
      PermissionsBitField.Flags.ManageRoles,
      PermissionsBitField.Flags.ViewChannel,
      PermissionsBitField.Flags.SendMessages,
      PermissionsBitField.Flags.EmbedLinks
    ];

    for (const [guildId, guild] of client.guilds.cache) {
      try {
        const botMember = guild.members.me || await guild.members.fetchMe().catch(() => null);
        if (!botMember) continue;

        const missingPerms = REQUIRED_PERMS.filter(p => !botMember.permissions.has(p));
        if (missingPerms.length > 0) {
          logger.warn(`⚠️ البوت ينقصه صلاحيات أساسية في سيرفر "${guild.name}": ${missingPerms.join(', ')}`);
        }

        const settings = SettingsRepository.getSettings(guildId);
        if (settings.ban_role_id) {
          const banRole = guild.roles.cache.get(settings.ban_role_id);
          if (banRole && botMember.roles.highest.position <= banRole.position) {
            logger.warn(`⚠️ تنبيه هرمية الرتب في سيرفر "${guild.name}": رتبة منع التوظيف (${banRole.name}) أعلى من أو مساوية لأعلى رتبة للبوت! لن يتمكن البوت من إعطاء أو سحب الرتبة حتى يتم رفع رتبته.`);
          }
        }
      } catch (err) {
        logger.warn(`تعذر فحص صلاحيات السيرفر ${guild.name}: ${err.message}`);
      }
    }

    logger.success('✅ اكتمل فحص تكوين وتوافق الديسكورد بنجاح.');
  }
}

module.exports = StartupValidator;
