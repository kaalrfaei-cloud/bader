const crypto = require('crypto');
const logger = require('../utils/logger');

// Lockout store in memory
const attemptTracker = new Map(); // ip -> { count: number, lockedUntil: number, lastAttempt: number }

const MAX_ATTEMPTS = 5;
const LOCKOUT_MS = 15 * 60 * 1000; // 15 minutes lockout

class PasscodeSecurity {
  /**
   * Hashes a passcode using scrypt with random salt
   */
  static hashPasscode(passcode) {
    if (!passcode) throw new Error('Passcode cannot be empty');
    const salt = crypto.randomBytes(16).toString('hex');
    const hash = crypto.scryptSync(passcode, salt, 32).toString('hex');
    return `${salt}:${hash}`;
  }

  /**
   * Timing-safe verification of passcode against hash or plaintext master
   */
  static verifyPasscode(inputPasscode, storedCredential) {
    if (!inputPasscode || !storedCredential) return false;

    // If stored credential is in salt:hash format
    if (storedCredential.includes(':')) {
      const [salt, expectedHash] = storedCredential.split(':');
      if (!salt || !expectedHash) return false;
      const actualHash = crypto.scryptSync(inputPasscode, salt, 32).toString('hex');
      try {
        return crypto.timingSafeEqual(Buffer.from(actualHash, 'utf8'), Buffer.from(expectedHash, 'utf8'));
      } catch {
        return false;
      }
    }

    // Direct comparison using timingSafeEqual
    const inputBuf = Buffer.from(String(inputPasscode), 'utf8');
    const storedBuf = Buffer.from(String(storedCredential), 'utf8');
    if (inputBuf.length !== storedBuf.length) {
      // Dummy compare to avoid timing differences on string length
      crypto.timingSafeEqual(inputBuf, inputBuf);
      return false;
    }
    return crypto.timingSafeEqual(inputBuf, storedBuf);
  }

  /**
   * Check if client IP is currently locked out
   */
  static checkLockout(ip) {
    const record = attemptTracker.get(ip);
    if (!record) return { isLocked: false, remainingSeconds: 0 };

    const now = Date.now();
    if (record.lockedUntil && record.lockedUntil > now) {
      const remainingSeconds = Math.ceil((record.lockedUntil - now) / 1000);
      return { isLocked: true, remainingSeconds };
    }

    // If lockout period has passed, reset
    if (record.lockedUntil && record.lockedUntil <= now) {
      attemptTracker.delete(ip);
      return { isLocked: false, remainingSeconds: 0 };
    }

    return { isLocked: false, remainingSeconds: 0 };
  }

  /**
   * Record a failed attempt, apply progressive delay, and lock if limit exceeded
   */
  static async recordFailedAttempt(ip) {
    const now = Date.now();
    const record = attemptTracker.get(ip) || { count: 0, lockedUntil: 0, lastAttempt: now };
    record.count += 1;
    record.lastAttempt = now;

    if (record.count >= MAX_ATTEMPTS) {
      record.lockedUntil = now + LOCKOUT_MS;
      logger.warn(`تم قفل تسجيل الدخول مؤقتاً للعنوان ${ip} لمدة 15 دقيقة بعد ${record.count} محاولات فاشلة متكررة.`);
    }

    attemptTracker.set(ip, record);

    // Progressive delay (1s for 1st fail, 2s for 2nd fail, 3s for 3rd fail...)
    const delayMs = Math.min(record.count * 1000, 4000);
    await new Promise(resolve => setTimeout(resolve, delayMs));

    return {
      count: record.count,
      isLocked: record.count >= MAX_ATTEMPTS,
      remainingAttempts: Math.max(0, MAX_ATTEMPTS - record.count)
    };
  }

  /**
   * Clear failed attempts on successful login
   */
  static recordSuccessfulAttempt(ip) {
    attemptTracker.delete(ip);
  }
}

module.exports = PasscodeSecurity;
