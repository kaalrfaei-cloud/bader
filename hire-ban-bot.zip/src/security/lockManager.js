/**
 * In-memory concurrency lock manager to prevent race conditions,
 * duplicate clicks, and duplicate ban operations on the same user.
 */
class LockManager {
  constructor() {
    this.locks = new Set();
  }

  /**
   * Acquire a lock for a unique key (e.g. `guildId:userId`).
   * Returns true if lock was acquired, false if already locked.
   */
  acquire(key, timeoutMs = 10000) {
    if (this.locks.has(key)) {
      return false;
    }
    this.locks.add(key);

    // Safety auto-release after timeoutMs
    setTimeout(() => {
      this.release(key);
    }, timeoutMs).unref?.();

    return true;
  }

  /**
   * Release the lock for a key.
   */
  release(key) {
    this.locks.delete(key);
  }

  /**
   * Execute an async action within a lock
   */
  async withLock(key, timeoutMs, fn) {
    if (!this.acquire(key, timeoutMs)) {
      const error = new Error('هناك عملية أخرى قيد التنفيذ على هذا العضو حالياً، يرجى الانتظار.');
      error.code = 'CONCURRENT_OPERATION_LOCKED';
      throw error;
    }

    try {
      return await fn();
    } finally {
      this.release(key);
    }
  }
}

module.exports = new LockManager();
