const BanRepository = require('../database/repositories/banRepository');
const SettingsRepository = require('../database/repositories/settingsRepository');
const PermissionsGuard = require('./permissions');
const logger = require('../utils/logger');

class AntiIdorGuard {
  /**
   * Express middleware to verify that the authenticated user has access
   * to the requested `req.params.guildId` with LIVE Discord permission verification.
   */
  static verifyGuildAccess(discordClient) {
    return async (req, res, next) => {
      const { guildId } = req.params;

      if (!guildId) {
        return res.status(400).json({ error: 'معرف السيرفر مطلوب.' });
      }

      if (!req.session || !req.session.user) {
        return res.status(401).json({ error: 'يجب تسجيل الدخول أولاً للوصول إلى هذا السيرفر.' });
      }

      const userId = req.session.user.id;
      const isProd = process.env.NODE_ENV === 'production';
      const isDevMock = !isProd && process.env.DEV_MOCK_AUTH === 'true';

      try {
        // Fetch guild from discord bot cache or API
        const guild = discordClient.guilds.cache.get(guildId) ||
          (typeof discordClient.guilds.fetch === 'function' ? await discordClient.guilds.fetch(guildId).catch(() => null) : null);

        if (!guild) {
          return res.status(404).json({ error: 'السيرفر غير موجود أو أن البوت لم يعد مضافاً إليه.' });
        }

        // Master admin mode support (passcode login or direct dev mock)
        if (req.session.isAdminMaster || userId === 'admin_owner' || isDevMock) {
          req.verifiedGuild = guild;
          const me = guild.members?.me;
          req.verifiedMember = {
            id: userId,
            user: { id: userId, tag: req.session.user?.username || 'مدير النظام' },
            guild,
            roles: me?.roles || { cache: new Map() },
            permissions: { has: () => true },
            isMasterAdmin: true
          };
          req.guildSettings = SettingsRepository.getSettings(guildId);
          return next();
        }

        // LIVE Member Check in Discord: Fetch latest member to prevent stale permissions
        let liveMember = guild.members.cache.get(userId);
        if (!liveMember && typeof guild.members.fetch === 'function') {
          liveMember = await guild.members.fetch(userId).catch(() => null);
        }

        if (!liveMember) {
          logger.warn(`محاولة وصول مرفوضة: المستخدم ${userId} لم يعد عضواً في السيرفر ${guildId}`);
          return res.status(403).json({ error: 'لم تعد عضواً في هذا السيرفر. تم سحب صلاحية الوصول.' });
        }

        const isOwner = guild.ownerId === userId;
        const isAdmin = liveMember.permissions?.has ? liveMember.permissions.has(8n) : false;
        const settings = SettingsRepository.getSettings(guildId);
        const dashboardRoles = settings.dashboard_roles || [];
        const hasDashboardRole = dashboardRoles.some(rId => liveMember.roles.cache.has(rId));

        if (!isOwner && !isAdmin && !hasDashboardRole) {
          logger.warn(`محاولة وصول مرفوضة: المستخدم ${userId} لا يمتلك رتبة كافية في ديسكورد للسيرفر ${guildId}`);
          return res.status(403).json({ error: 'ليس لديك رتبة مسؤول (Administrator) أو رتبة مصرحة لإدارة هذا السيرفر.' });
        }

        // Attach verified guild, live member, and settings to request
        req.verifiedGuild = guild;
        req.verifiedMember = liveMember;
        req.guildSettings = settings;

        next();
      } catch (err) {
        logger.error(`خطأ أثناء التحقق من الصلاحيات للسيرفر ${guildId}:`, err.message);
        return res.status(500).json({ error: 'حدث خطأ داخلي أثناء التحقق من صلاحيات السيرفر.' });
      }
    };
  }

  /**
   * Verifies that a banId belongs strictly to the verified guild (Anti-IDOR)
   */
  static verifyBanOwnership(req, res, next) {
    const { id, guildId } = req.params;
    const banId = parseInt(id, 10);

    if (isNaN(banId) || banId <= 0) {
      return res.status(400).json({ error: 'معرف المنع غير صالح.' });
    }

    const ban = BanRepository.getBanById(banId, guildId);
    if (!ban) {
      logger.warn(`محاولة IDOR لاختراق سجل منع: المستخدم حاول الوصول للمنع #${banId} غير التابع للسيرفر ${guildId}`);
      return res.status(404).json({ error: 'سجل منع التوظيف غير موجود أو لا ينتمي إلى هذا السيرفر.' });
    }

    req.verifiedBan = ban;
    next();
  }
}

module.exports = AntiIdorGuard;
