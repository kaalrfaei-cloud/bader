const session = require('express-session');
const { getDb } = require('../database/db');
const logger = require('../utils/logger');

class SQLiteSessionStore extends session.Store {
  constructor(options = {}) {
    super();
    this.ttl = options.ttl || 12 * 3600; // 12 hours in seconds
    this.cleanupInterval = options.cleanupInterval || 15 * 60 * 1000; // cleanup every 15m

    // Start periodic expired session cleanup
    this._cleanupTimer = setInterval(() => {
      this.clearExpired();
    }, this.cleanupInterval);
    if (this._cleanupTimer.unref) this._cleanupTimer.unref();
  }

  get(sid, cb) {
    try {
      const db = getDb();
      const row = db.prepare('SELECT sess, expire FROM dashboard_sessions WHERE sid = ?').get(sid);
      if (!row) {
        return cb(null, null);
      }

      const now = Math.floor(Date.now() / 1000);
      if (row.expire < now) {
        this.destroy(sid, () => {});
        return cb(null, null);
      }

      const sess = JSON.parse(row.sess);
      return cb(null, sess);
    } catch (err) {
      logger.error('Session get error:', err.message);
      return cb(err);
    }
  }

  set(sid, sess, cb) {
    try {
      const db = getDb();
      const now = Math.floor(Date.now() / 1000);
      let maxAge = this.ttl;

      if (sess && sess.cookie && sess.cookie.expires) {
        const expiresTime = new Date(sess.cookie.expires).getTime();
        maxAge = Math.floor((expiresTime - Date.now()) / 1000);
      } else if (sess && sess.cookie && sess.cookie.maxAge) {
        maxAge = Math.floor(sess.cookie.maxAge / 1000);
      }

      const expire = now + Math.max(maxAge, 60);
      const sessStr = JSON.stringify(sess);

      const stmt = db.prepare(`
        INSERT INTO dashboard_sessions (sid, sess, expire)
        VALUES (?, ?, ?)
        ON CONFLICT(sid) DO UPDATE SET
          sess = excluded.sess,
          expire = excluded.expire
      `);
      stmt.run(sid, sessStr, expire);

      if (cb) cb(null);
    } catch (err) {
      logger.error('Session set error:', err.message);
      if (cb) cb(err);
    }
  }

  destroy(sid, cb) {
    try {
      const db = getDb();
      db.prepare('DELETE FROM dashboard_sessions WHERE sid = ?').run(sid);
      if (cb) cb(null);
    } catch (err) {
      if (cb) cb(err);
    }
  }

  touch(sid, sess, cb) {
    try {
      const db = getDb();
      const now = Math.floor(Date.now() / 1000);
      let maxAge = this.ttl;

      if (sess && sess.cookie && sess.cookie.expires) {
        const expiresTime = new Date(sess.cookie.expires).getTime();
        maxAge = Math.floor((expiresTime - Date.now()) / 1000);
      } else if (sess && sess.cookie && sess.cookie.maxAge) {
        maxAge = Math.floor(sess.cookie.maxAge / 1000);
      }

      const expire = now + Math.max(maxAge, 60);
      db.prepare('UPDATE dashboard_sessions SET expire = ? WHERE sid = ?').run(expire, sid);
      if (cb) cb(null);
    } catch (err) {
      if (cb) cb(err);
    }
  }

  clearExpired() {
    try {
      const db = getDb();
      const now = Math.floor(Date.now() / 1000);
      db.prepare('DELETE FROM dashboard_sessions WHERE expire < ?').run(now);
    } catch (err) {
      logger.error('Failed to clean up expired sessions:', err.message);
    }
  }
}

module.exports = SQLiteSessionStore;
