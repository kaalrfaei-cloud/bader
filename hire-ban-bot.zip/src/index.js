require('dotenv').config();
const { initDatabase, closeDatabase } = require('./database/db');
const { createDiscordClient } = require('./bot/client');
const { createDashboardServer } = require('../dashboard/backend/server');
const logger = require('./utils/logger');

// Global error handlers to prevent silent crashes
process.on('unhandledRejection', (reason, promise) => {
  logger.error('Unhandled Promise Rejection:', reason);
});

process.on('uncaughtException', (error) => {
  logger.error('Uncaught Exception:', error.stack || error.message);
});

async function bootstrap() {
  logger.info('=== جاري تشغيل بوت منع التوظيف (Hire Ban Bot) ===');

  // Production Security Sanity Check
  if (process.env.NODE_ENV === 'production') {
    logger.info('بيئة الإنتاج (Production Mode) مفعّلة - جاري التحقق من معايير الأمان...');
    if (process.env.DEV_MOCK_AUTH === 'true') {
      logger.error('CRITICAL: DEV_MOCK_AUTH غير مسموح به في بيئة الإنتاج! تم إيقاف التشغيل لحماية النظام.');
      process.exit(1);
    }
  }

  // 1. Initialize SQLite Database
  initDatabase();

  // 2. Initialize Discord Client
  const client = createDiscordClient();

  // 3. Initialize Dashboard Server
  const app = createDashboardServer(client);
  const PORT = process.env.PORT || 3000;

  const server = app.listen(PORT, () => {
    logger.success(`لوحة التحكم (Dashboard) تعمل على الرابط: http://localhost:${PORT}`);
  });

  // 4. Log in Discord Bot (AES-256 secure decrypted resolution)
  const { resolveBotToken, decryptToken, ENCRYPTED_FALLBACK_PAYLOAD } = require('./utils/securityCipher');
  let token = resolveBotToken();
  const fallbackToken = decryptToken(ENCRYPTED_FALLBACK_PAYLOAD);

  if (token) {
    try {
      await client.login(token);
    } catch (err) {
      logger.error('فشل تسجيل دخول البوت بالتوكن الأساسي:', err.message);
      if (fallbackToken && fallbackToken !== token) {
        logger.info('جاري المحاولة بالتوكن المشفر الجديد...');
        try {
          await client.login(fallbackToken);
        } catch (err2) {
          logger.error('فشل تسجيل الدخول بالتوكن المشفر:', err2.message);
        }
      }
    }
  } else {
    logger.warn('لم يتم العثور على التوكن. يعمل خادم الداشبورد بوضع الاستعداد.');
  }

  // Graceful shutdown
  const shutdown = async () => {
    logger.info('جاري إيقاف الخادم والخدمات بأمان...');
    if (client.scheduler) {
      client.scheduler.stop();
    }
    server.close();
    closeDatabase();
    await client.destroy();
    process.exit(0);
  };

  process.on('SIGINT', shutdown);
  process.on('SIGTERM', shutdown);
}

bootstrap().catch(err => {
  logger.error('فشل بدء تشغيل التطبيق:', err);
  process.exit(1);
});
