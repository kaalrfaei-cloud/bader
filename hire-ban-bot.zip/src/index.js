require('dotenv').config();
const { initDatabase, closeDatabase } = require('./database/db');
const { createDiscordClient } = require('./bot/client');
const { createDashboardServer } = require('../dashboard/backend/server');
const StartupValidator = require('./security/startupValidator');
const { resolveBotToken } = require('./utils/securityCipher');
const logger = require('./utils/logger');

// Global error handlers to prevent silent crashes
process.on('unhandledRejection', (reason, promise) => {
  logger.error('[Global] Unhandled Promise Rejection:', reason);
});

process.on('uncaughtException', (error) => {
  logger.error('[Global] Uncaught Exception:', error.stack || error.message);
});

async function bootstrap() {
  logger.info('=== جاري تشغيل بوت منع التوظيف (Hire Ban Bot) ===');

  // 1. Startup Configuration & Environment Security Audit
  logger.info('🔐 جاري التحقق من الإعدادات الأمنية ومفاتيح التشفير...');
  const envValidation = StartupValidator.validateEnvironment();

  for (const warning of envValidation.warnings) {
    logger.warn(`⚠️ [تنبيه أمني]: ${warning}`);
  }

  if (!envValidation.isValid) {
    logger.error('❌ فشل فحص الإعدادات الأساسية! يمنع النظام التشغيل بالأخطاء التالية:');
    for (const error of envValidation.errors) {
      logger.error(`   🛑 ${error}`);
    }
    // Block startup in production or if critical keys missing
    if (process.env.NODE_ENV === 'production' || !process.env.ENCRYPTION_KEY || !process.env.ADMIN_PASSCODE) {
      logger.error('🛑 تم إيقاف تشغيل الخادم لحماية النظام وأسرار السيرفر.');
      process.exit(1);
    }
  } else {
    logger.success('✅ كافة الإعدادات الأمنية ومفاتيح التشفير مطابقة للمعايير القياسية.');
  }

  // 2. Initialize SQLite Database
  initDatabase();

  // 3. Initialize Discord Client
  const client = createDiscordClient();

  // Hook Discord ready event for state & permissions validation
  client.once('ready', async () => {
    await StartupValidator.validateDiscordState(client);
  });

  // 4. Initialize Dashboard Server
  const app = createDashboardServer(client);
  const PORT = process.env.PORT || 3000;

  const server = app.listen(PORT, () => {
    logger.success(`لوحة التحكم (Dashboard) تعمل على الرابط: http://localhost:${PORT}`);
  });

  // 5. 24/7 Keep-Alive Worker (Prevents Render / free hosts from sleeping)
  const KeepAliveService = require('./services/keepAliveService');
  KeepAliveService.start();

  // 6. Log in Discord Bot (Strict environment token only)
  let token = '';
  try {
    token = resolveBotToken();
  } catch (err) {
    logger.error('فشل استرجاع التوكن:', err.message);
  }

  if (token) {
    try {
      await client.login(token);
    } catch (err) {
      logger.error('فشل تسجيل دخول البوت بالتوكن:', err.message);
    }
  } else {
    logger.warn('لم يتم العثور على التوكن. يعمل خادم الداشبورد بوضع الاستعداد.');
  }

  // Graceful shutdown
  const shutdown = async () => {
    logger.info('جاري إيقاف الخادم والخدمات بأمان...');
    if (client.scheduler) {
      client.scheduler.stop();
    }
    server.close();
    closeDatabase();
    await client.destroy();
    process.exit(0);
  };

  process.on('SIGINT', shutdown);
  process.on('SIGTERM', shutdown);
}

bootstrap().catch(err => {
  logger.error('فشل بدء تشغيل التطبيق:', err);
  process.exit(1);
});
