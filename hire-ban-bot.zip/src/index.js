require('dotenv').config();
const { initDatabase, closeDatabase } = require('./database/db');
const { createDiscordClient } = require('./bot/client');
const { createDashboardServer } = require('../dashboard/backend/server');
const StartupValidator = require('./security/startupValidator');
const { resolveBotToken } = require('./utils/securityCipher');
const logger = require('./utils/logger');

// Global error handlers to prevent silent crashes
process.on('unhandledRejection', (reason, promise) => {
  logger.error('[Global] Unhandled Promise Rejection:', reason);
});

process.on('uncaughtException', (error) => {
  logger.error('[Global] Uncaught Exception:', error.stack || error.message);
});

async function bootstrap() {
  logger.info('=== جاري تشغيل بوت منع التوظيف (Hire Ban Bot) ===');

  // 1. Startup Configuration & Environment Security Audit
  logger.info('🔐 جاري التحقق من الإعدادات الأمنية ومفاتيح التشفير...');
  const envValidation = StartupValidator.validateEnvironment();

  for (const warning of envValidation.warnings) {
    logger.warn(`⚠️ [تنبيه أمني]: ${warning}`);
  }

  if (!envValidation.isValid) {
    logger.warn('⚠️ تم رصد ملاحظات أثناء فحص الإعدادات الأساسية:');
    for (const error of envValidation.errors) {
      logger.warn(`   🛑 ${error}`);
    }
    logger.info('ℹ️ يعمل خادم الويب (Dashboard) الآن بوضع الاستعداد لتأكيد نجاح النشر. يرجى ضبط المتغيرات المطلوبة في لوحة الاستضافة.');
  } else {
    logger.success('✅ كافة الإعدادات الأمنية ومفاتيح التشفير مطابقة للمعايير القياسية.');
  }

  // 2. Initialize SQLite Database
  initDatabase();

  // 3. Initialize Discord Client
  const client = createDiscordClient();

  // Hook Discord ready event for state & permissions validation
  client.once('clientReady', async () => {
    client._isReadyFlag = true;
    await StartupValidator.validateDiscordState(client);
  });

  // 4. Initialize Dashboard Server
  const app = createDashboardServer(client);
  const PORT = process.env.PORT || 3000;

  const server = app.listen(PORT, '0.0.0.0', () => {
    logger.success(`لوحة التحكم (Dashboard) تعمل على الرابط: http://0.0.0.0:${PORT}`);
  });

  // 5. 24/7 Keep-Alive Worker (Prevents Render / free hosts from sleeping)
  const KeepAliveService = require('./services/keepAliveService');
  KeepAliveService.start();

  // 6. Log in Discord Bot (Strictly from environment)
  let token = '';
  try {
    token = resolveBotToken();
  } catch (err) {
    logger.error('فشل استرجاع التوكن:', err.message);
  }

  if (token) {
    try {
      await client.login(token);
      logger.success(`✅ تم تسجيل دخول البوت بنجاح: ${client.user.tag}`);
    } catch (err) {
      logger.error(`فشل تسجيل دخول البوت: ${err.message} (${err.code || 'NO_CODE'})`);
      if (err.code === 'DisallowedIntents' || (err.message && err.message.toLowerCase().includes('intent'))) {
        logger.warn('⚠️ تم رفض الصلاحيات الموسعة (Privileged Intents) من ديسكورد! يرجى تفعيل مفاتيح الصلاحيات في Discord Developer Portal.');
        try {
          client.options.intents = [1]; // Fallback to basic Guilds intent
          await client.login(token);
          logger.success(`✅ تم تشغيل البوت بالصلاحيات الأساسية: ${client.user.tag}`);
        } catch (basicErr) {
          logger.error('فشل الاتصال بالصلاحيات الأساسية أيضاً:', basicErr.message);
        }
      }
    }
  } else {
    logger.warn('لم يتم العثور على التوكن في متغيرات البيئة. يعمل خادم الداشبورد بوضع الاستعداد.');
  }

  // Graceful shutdown
  const shutdown = async () => {
    logger.info('جاري إيقاف الخادم والخدمات بأمان...');
    if (client.scheduler) {
      client.scheduler.stop();
    }
    server.close();
    closeDatabase();
    await client.destroy();
    process.exit(0);
  };

  process.on('SIGINT', shutdown);
  process.on('SIGTERM', shutdown);
}

bootstrap().catch(err => {
  logger.error('فشل بدء تشغيل التطبيق:', err);
  process.exit(1);
});
