const dotenv = require('dotenv');

// 1. Load .env if present in the environment
dotenv.config();

// 2. Default runtime credentials (used seamlessly if not overridden in Render / hosting dashboard)
const APP_CONFIG = {
  DISCORD_TOKEN: 'MTU1Mzk3MTQ1MzI1MzI1NTI0OA.GrY3P0.MckZe5xJzkDV9ImzzITxThcYMT41qJKVXBHgYQ',
  DISCORD_CLIENT_ID: '1553971453253255248',
  DISCORD_CLIENT_SECRET: 'fVsWyiMxTvpYrrm71UFIlAhWNYnpXRaq',
  ADMIN_PASSCODE: 'Bader_Secure_Custom_Passcode_9921_Key!',
  SESSION_SECRET: 'hire_ban_bot_secret_session_2026_random_32_chars_ok',
  ENCRYPTION_KEY: 'hire_ban_super_strong_aes256_gcm_vault_key_2026_secure'
};

// 3. Inject defaults into process.env if not provided by host environment
for (const [key, value] of Object.entries(APP_CONFIG)) {
  if (!process.env[key] || !process.env[key].trim()) {
    process.env[key] = value;
  }
}

module.exports = APP_CONFIG;
