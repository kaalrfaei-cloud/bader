const { EmbedBuilder } = require('discord.js');
const { formatDuration, formatDiscordTimestamp } = require('./timeParser');

const THEME = {
  PRIMARY: 0xDC2626, // Red
  SUCCESS: 0x10B981, // Emerald Green
  WARNING: 0xF59E0B, // Amber
  ERROR: 0xEF4444,   // Bright Red
  INFO: 0x3B82F6,    // Blue
  DARK: 0x18181B     // Zinc Dark
};

class Embeds {
  /**
   * Embed for Public Citizen Channel announcement
   */
  static banCitizenEmbed({ user, moderator, reason, durationSeconds, expiresAt }) {
    const durationText = durationSeconds ? formatDuration(durationSeconds) : 'منع دائم';
    const expiresText = expiresAt ? formatDiscordTimestamp(expiresAt) : 'لا ينتهي (دائم)';

    return new EmbedBuilder()
      .setColor(THEME.PRIMARY)
      .setTitle('🚫 منع توظيف جديد')
      .setDescription(`تم تطبيق قرار منع التوظيف بحق العضو المذكور أدناه.`)
      .addFields(
        { name: '👤 العضو', value: `<@${user.id}> (${user.tag || user.username})`, inline: true },
        { name: '⏱️ المدة', value: durationText, inline: true },
        { name: '📅 تاريخ الانتهاء', value: expiresText, inline: false },
        { name: '📝 السبب', value: reason || 'لا يوجد سبب محدد', inline: false }
      )
      .setThumbnail(user.displayAvatarURL ? user.displayAvatarURL({ dynamic: true }) : null)
      .setFooter({ text: 'نظام منع التوظيف • Hire Ban Bot' })
      .setTimestamp();
  }

  /**
   * Embed for Audit Log channel (Detailed admin view)
   */
  static banLogEmbed({ user, moderator, reason, durationSeconds, expiresAt, banId }) {
    const durationText = durationSeconds ? formatDuration(durationSeconds) : 'منع دائم';
    const expiresText = expiresAt ? formatDiscordTimestamp(expiresAt) : 'دائم';

    return new EmbedBuilder()
      .setColor(THEME.PRIMARY)
      .setTitle('📜 [سجل] إصدار منع توظيف')
      .addFields(
        { name: '👤 العضو المستهدف', value: `<@${user.id}> \`[${user.id}]\``, inline: true },
        { name: '👮 الإداري المنفذ', value: `<@${moderator.id}> \`[${moderator.id}]\``, inline: true },
        { name: '🆔 رقم المنع', value: `#${banId || 'N/A'}`, inline: true },
        { name: '⏱️ المدة المحددة', value: durationText, inline: true },
        { name: '📅 ينتهي في', value: expiresText, inline: true },
        { name: '📝 سبب المنع', value: reason || 'لم يحدد سبب', inline: false }
      )
      .setFooter({ text: 'سجل عمليات منع التوظيف' })
      .setTimestamp();
  }

  /**
   * Embed for Ban Revocation
   */
  static revokeLogEmbed({ user, moderator, reason, banId }) {
    return new EmbedBuilder()
      .setColor(THEME.SUCCESS)
      .setTitle('🔓 [سجل] إلغاء منع توظيف')
      .setDescription(`تم رفع منع التوظيف وإزالة الرول الخاص به عن العضو.`)
      .addFields(
        { name: '👤 العضو', value: `<@${user.id}> \`[${user.id}]\``, inline: true },
        { name: '👮 الإداري الذي ألغى المنع', value: `<@${moderator.id}> \`[${moderator.id}]\``, inline: true },
        { name: '🆔 رقم العملية', value: `#${banId || 'N/A'}`, inline: true },
        { name: '📝 سبب الإلغاء', value: reason || 'لا يوجد سبب مذكور', inline: false }
      )
      .setFooter({ text: 'سجل إلغاء المنع' })
      .setTimestamp();
  }

  /**
   * Embed for Auto-Expiration
   */
  static expireLogEmbed({ user, banId, roleRemoved }) {
    return new EmbedBuilder()
      .setColor(THEME.INFO)
      .setTitle('⏰ [سجل] انتهاء مدة منع التوظيف تلقائياً')
      .setDescription(`انتهت صلاحية منع التوظيف وتم تحديث الحالة بنجاح.`)
      .addFields(
        { name: '👤 العضو', value: `<@${user.id}> \`[${user.id}]\``, inline: true },
        { name: '🆔 رقم المنع', value: `#${banId}`, inline: true },
        { name: '🎭 حالة الرول', value: roleRemoved ? '✅ تمت إزالة الرول بنجاح' : '⚠️ العضو غير موجود بالسيرفر (تم تحديث قاعدة البيانات فقط)', inline: false }
      )
      .setFooter({ text: 'المجدول التلقائي • Hire Ban Bot' })
      .setTimestamp();
  }

  /**
   * Embed for Member Rejoin while actively banned
   */
  static rejoinLogEmbed({ user, banId, expiresAt }) {
    const expiresText = expiresAt ? formatDiscordTimestamp(expiresAt) : 'دائم';

    return new EmbedBuilder()
      .setColor(THEME.WARNING)
      .setTitle('🔄 [سجل] إعادة تطبيق منع التوظيف عند العودة')
      .setDescription(`دخل العضو السيرفر ولديه عقوبة منع توظيف نشطة مسبقاً، تمت إعادة الرول إليه تلقائياً.`)
      .addFields(
        { name: '👤 العضو', value: `<@${user.id}> \`[${user.id}]\``, inline: true },
        { name: '🆔 رقم المنع النشط', value: `#${banId}`, inline: true },
        { name: '📅 ينتهي المنع في', value: expiresText, inline: false }
      )
      .setFooter({ text: 'حماية منع التهرب • Hire Ban Bot' })
      .setTimestamp();
  }

  /**
   * Embed for System Error / Warning
   */
  static errorLogEmbed({ action, error, targetUserId = null, details = null }) {
    const embed = new EmbedBuilder()
      .setColor(THEME.ERROR)
      .setTitle('⚠️ [تنبيه خطأ في النظام]')
      .setDescription(`حدث خطأ أثناء محاولة تنفيذ عملية في البوت.`)
      .addFields(
        { name: '⚙️ العملية', value: action || 'غير محددة', inline: true },
        { name: '🚨 رسالة الخطأ', value: `\`\`\`${String(error).substring(0, 900)}\`\`\``, inline: false }
      );

    if (targetUserId) {
      embed.addFields({ name: '👤 العضو المعني', value: `<@${targetUserId}> \`[${targetUserId}]\``, inline: true });
    }

    if (details) {
      embed.addFields({ name: '🔍 تفاصيل إضافية', value: `\`\`\`json\n${JSON.stringify(details, null, 2).substring(0, 500)}\`\`\``, inline: false });
    }

    return embed.setFooter({ text: 'سجل الأخطاء التقنية' }).setTimestamp();
  }

  /**
   * Confirmation embed before executing ban
   */
  static banConfirmEmbed({ user, durationSeconds, expiresAt, reason }) {
    const durationText = durationSeconds ? formatDuration(durationSeconds) : 'منع دائم';
    const expiresText = expiresAt ? formatDiscordTimestamp(expiresAt) : 'دائم';

    return new EmbedBuilder()
      .setColor(THEME.WARNING)
      .setTitle('⚠️ تأكيد إصدار منع التوظيف')
      .setDescription(`هل أنت متأكد من رغبتك في تطبيق منع التوظيف على العضو التالي بالبيانات الموضحة؟`)
      .addFields(
        { name: '👤 العضو', value: `<@${user.id}>`, inline: true },
        { name: '⏱️ المدة', value: durationText, inline: true },
        { name: '📅 تاريخ الانتهاء', value: expiresText, inline: false },
        { name: '📝 السبب', value: reason || 'لا يوجد سبب مذكور', inline: false }
      )
      .setFooter({ text: 'اضغط على تأكيد للتنفيذ أو إلغاء للتراجع' });
  }
}

module.exports = { Embeds, THEME };
