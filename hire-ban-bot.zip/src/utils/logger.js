const fs = require('fs');
const path = require('path');

const logDir = path.resolve(__dirname, '../../logs');
if (!fs.existsSync(logDir)) {
  fs.mkdirSync(logDir, { recursive: true });
}

const logFile = path.join(logDir, `bot-${new Date().toISOString().slice(0, 10)}.log`);

function write(level, message, meta = '') {
  const timestamp = new Date().toISOString();
  let metaStr = '';
  if (meta) {
    if (meta instanceof Error) {
      metaStr = ` ${meta.stack || meta.message}`;
    } else if (typeof meta === 'object') {
      metaStr = ` ${JSON.stringify(meta)}`;
    } else {
      metaStr = ` ${meta}`;
    }
  }
  const logLine = `[${timestamp}] [${level.toUpperCase()}] ${message}${metaStr}\n`;
  
  // Console output with colors
  let color = '\x1b[0m';
  if (level === 'info') color = '\x1b[36m'; // Cyan
  if (level === 'warn') color = '\x1b[33m'; // Yellow
  if (level === 'error') color = '\x1b[31m'; // Red
  if (level === 'success') color = '\x1b[32m'; // Green
  
  process.stdout.write(`${color}[${level.toUpperCase()}]\x1b[0m [${timestamp}] ${message}${metaStr}\n`);

  try {
    fs.appendFileSync(logFile, logLine);
  } catch (err) {
    // Fail-safe
  }
}

module.exports = {
  info: (msg, meta) => write('info', msg, meta),
  warn: (msg, meta) => write('warn', msg, meta),
  error: (msg, meta) => write('error', msg, meta),
  success: (msg, meta) => write('success', msg, meta),
  debug: (msg, meta) => {
    if (process.env.DEBUG === 'true') {
      write('debug', msg, meta);
    }
  }
};
