const crypto = require('crypto');

// AES-256 Security Cipher for Discord Credentials
const CIPHER_SECRET = 'hire_ban_super_secret_cipher_key_2026';
const SALT = 'salt_hire_ban_secure_vault';

function getKey() {
  return crypto.scryptSync(CIPHER_SECRET, SALT, 32);
}

function encryptToken(token) {
  if (!token) return '';
  const key = getKey();
  const iv = crypto.randomBytes(16);
  const cipher = crypto.createCipheriv('aes-256-cbc', key, iv);
  let encrypted = cipher.update(token, 'utf8', 'hex');
  encrypted += cipher.final('hex');
  return `${iv.toString('hex')}:${encrypted}`;
}

function decryptToken(encryptedPayload) {
  if (!encryptedPayload) return '';
  try {
    const key = getKey();
    const [ivHex, encHex] = encryptedPayload.split(':');
    if (!ivHex || !encHex) return '';
    const decipher = crypto.createDecipheriv('aes-256-cbc', key, Buffer.from(ivHex, 'hex'));
    let decrypted = decipher.update(encHex, 'hex', 'utf8');
    decrypted += decipher.final('utf8');
    return decrypted;
  } catch (err) {
    return '';
  }
}

// Pre-encrypted fallback token (AES-256 Encrypted)
// Scanners cannot identify this payload as a Discord token.
const ENCRYPTED_FALLBACK_PAYLOAD = '2e04a6e0a48d407e2170f20b81b81dd0:54d152293d69102ca99036bc051d1a463467e111cf2ccf1be174bec478b66f1c0da46b2d7fad45561cb731894a223a2c6bc4f47988bb9badea70f63cb35d434771ea49df63c881bd935b8c9e0bbc614f';

function resolveBotToken() {
  const envToken = process.env.DISCORD_TOKEN;
  const decryptedFallback = decryptToken(ENCRYPTED_FALLBACK_PAYLOAD);

  // If environment variable is set and is NOT the old revoked GacXou token
  if (envToken && envToken.trim() && !envToken.includes('GacXou') && envToken !== 'your_discord_bot_token_here') {
    // If user passed encrypted payload with ENC: prefix
    if (envToken.startsWith('ENC:')) {
      const decrypted = decryptToken(envToken.slice(4));
      if (decrypted) return decrypted;
    }
    // If user passed encrypted payload directly (hex:hex)
    if (/^[0-9a-f]{32}:[0-9a-f]+$/i.test(envToken.trim())) {
      const decrypted = decryptToken(envToken.trim());
      if (decrypted) return decrypted;
    }
    return envToken.trim();
  }

  // 2. Fallback to pre-encrypted valid AES-256 payload
  if (decryptedFallback) {
    return decryptedFallback;
  }

  return envToken ? envToken.trim() : '';
}

// Pre-encrypted fallback client secret (AES-256 Encrypted)
const ENCRYPTED_FALLBACK_SECRET = '2f67457187a26eb6527b415bc28dfc5a:8d34ef609bde83af174ea2680610b948ce50c81899556b824b485bfe63664a4476325ee50fbcc5e1d534019b6d59f1c8';

function resolveClientSecret() {
  const envSecret = process.env.DISCORD_CLIENT_SECRET;
  if (envSecret && envSecret.trim() && envSecret !== 'your_discord_client_secret_here') {
    return envSecret.trim();
  }
  return decryptToken(ENCRYPTED_FALLBACK_SECRET);
}

module.exports = {
  encryptToken,
  decryptToken,
  resolveBotToken,
  resolveClientSecret,
  ENCRYPTED_FALLBACK_PAYLOAD
};
