const crypto = require('crypto');
const logger = require('./logger');

// Salt for PBKDF2/scrypt derivation from ENCRYPTION_KEY
const KDF_SALT = 'hire_ban_kdf_salt_secure_2026';

/**
 * Derive 256-bit AES key from environment variable ENCRYPTION_KEY
 * @param {string|null} customKey
 * @returns {Buffer|null}
 */
function getKey(customKey = null) {
  const secret = customKey || process.env.ENCRYPTION_KEY;
  if (!secret || typeof secret !== 'string' || !secret.trim()) {
    return null;
  }
  return crypto.scryptSync(secret.trim(), KDF_SALT, 32);
}

/**
 * Encrypt sensitive string using AES-256-GCM (Authenticated Encryption)
 * @param {string} text
 * @param {string|null} customKey
 * @returns {string} iv:tag:ciphertext (hex encoded)
 */
function encryptToken(text, customKey = null) {
  if (!text) return '';
  const key = getKey(customKey);
  if (!key) {
    logger.warn('[SecurityCipher] تعذر التشفير: لم يتم تعيين ENCRYPTION_KEY في متغيرات البيئة.');
    return '';
  }

  const iv = crypto.randomBytes(12); // Standard 96-bit IV for GCM
  const cipher = crypto.createCipheriv('aes-256-gcm', key, iv);

  let encrypted = cipher.update(text, 'utf8', 'hex');
  encrypted += cipher.final('hex');
  const authTag = cipher.getAuthTag().toString('hex');

  return `${iv.toString('hex')}:${authTag}:${encrypted}`;
}

/**
 * Decrypt AES-256-GCM encrypted payload
 * @param {string} encryptedPayload iv:tag:ciphertext
 * @param {string|null} customKey
 * @returns {string}
 */
function decryptToken(encryptedPayload, customKey = null) {
  if (!encryptedPayload || typeof encryptedPayload !== 'string') return '';
  try {
    const key = getKey(customKey);
    if (!key) {
      logger.warn('[SecurityCipher] تعذر فك التشفير: لم يتم تعيين ENCRYPTION_KEY في متغيرات البيئة.');
      return '';
    }

    const payload = encryptedPayload.startsWith('ENC:') ? encryptedPayload.slice(4) : encryptedPayload;
    const parts = payload.split(':');
    if (parts.length !== 3) return '';

    const [ivHex, tagHex, encHex] = parts;
    if (!ivHex || !tagHex || !encHex || ivHex.length !== 24 || tagHex.length !== 32) {
      return '';
    }

    const decipher = crypto.createDecipheriv('aes-256-gcm', key, Buffer.from(ivHex, 'hex'));
    decipher.setAuthTag(Buffer.from(tagHex, 'hex'));

    let decrypted = decipher.update(encHex, 'hex', 'utf8');
    decrypted += decipher.final('utf8');
    return decrypted;
  } catch (err) {
    logger.warn('[SecurityCipher] فشل فك تشفير البيانات أو تم التلاعب بها (Auth Tag Mismatch):', err.message);
    return '';
  }
}

/**
 * Resolve Discord bot token exclusively from environment variables
 * @returns {string}
 */
function resolveBotToken() {
  const envToken = process.env.DISCORD_TOKEN ? process.env.DISCORD_TOKEN.trim() : '';
  if (!envToken || envToken === 'your_discord_bot_token_here') {
    return '';
  }

  // If token is encrypted with AES-256-GCM
  if (envToken.startsWith('ENC:')) {
    return decryptToken(envToken.slice(4));
  }

  // If passed directly as GCM payload (iv:tag:enc)
  if (/^[0-9a-f]{24}:[0-9a-f]{32}:[0-9a-f]+$/i.test(envToken)) {
    return decryptToken(envToken);
  }

  return envToken;
}

/**
 * Resolve Discord client ID exclusively from environment variables
 * @returns {string}
 */
function resolveClientId() {
  const envId = process.env.DISCORD_CLIENT_ID ? process.env.DISCORD_CLIENT_ID.trim() : '';
  if (!envId || envId === 'your_discord_client_id_here') {
    return '';
  }
  return envId;
}

/**
 * Resolve Discord client secret exclusively from environment variables
 * @returns {string}
 */
function resolveClientSecret() {
  const envSecret = process.env.DISCORD_CLIENT_SECRET ? process.env.DISCORD_CLIENT_SECRET.trim() : '';
  if (!envSecret || envSecret === 'your_discord_client_secret_here') {
    return '';
  }

  if (envSecret.startsWith('ENC:')) {
    return decryptToken(envSecret.slice(4));
  }

  return envSecret;
}

/**
 * Resolve Admin Passcode strictly from environment variables without default fallbacks
 * @returns {string}
 */
function resolveAdminPasscode() {
  return process.env.ADMIN_PASSCODE ? process.env.ADMIN_PASSCODE.trim() : '';
}

module.exports = {
  getKey,
  encryptToken,
  decryptToken,
  resolveBotToken,
  resolveClientId,
  resolveClientSecret,
  resolveAdminPasscode
};
