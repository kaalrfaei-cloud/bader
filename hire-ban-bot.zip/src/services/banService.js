const BanRepository = require('../database/repositories/banRepository');
const SettingsRepository = require('../database/repositories/settingsRepository');
const AuditLogRepository = require('../database/repositories/auditLogRepository');
const HierarchyGuard = require('../security/hierarchy');
const PermissionsGuard = require('../security/permissions');
const LockManager = require('../security/lockManager');
const NotificationService = require('./notificationService');
const { calculateExpiresAt, formatDuration } = require('../utils/timeParser');
const logger = require('../utils/logger');

class BanService {
  /**
   * Issue a hire ban
   */
  static async issueBan({ guild, targetUserId, moderator, durationSeconds, reason }) {
    const lockKey = `${guild.id}:${targetUserId}`;

    return await LockManager.withLock(lockKey, 10000, async () => {
      // 1. Fetch settings
      const settings = SettingsRepository.getSettings(guild.id);

      // Check if permanent bans are allowed
      if (durationSeconds === null && !settings.allow_permanent_bans) {
        throw new Error('المنع الدائم معطل حالياً في إعدادات هذا السيرفر.');
      }

      // 2. Fetch target member if in guild
      let targetMember = null;
      let targetUser = null;
      try {
        targetMember = guild.members.cache.get(targetUserId) || await guild.members.fetch(targetUserId).catch(() => null);
        if (targetMember) {
          targetUser = targetMember.user;
        } else {
          // If member is not in guild, fetch user object from client
          targetUser = await guild.client.users.fetch(targetUserId).catch(() => null);
        }
      } catch (err) {
        logger.warn(`تعذر جلب بيانات العضو ${targetUserId}: ${err.message}`);
      }

      const userTag = targetUser ? (targetUser.tag || targetUser.username) : `مستخدم [${targetUserId}]`;
      const modTag = moderator ? (moderator.tag || moderator.user?.tag || moderator.user?.username || moderator.username || 'إداري') : 'النظام';
      const modId = moderator ? (moderator.id || moderator.user?.id) : 'SYSTEM';

      // 3. Hierarchy & Permission Validation
      const hierarchyCheck = HierarchyGuard.validate(guild, settings.ban_role_id, targetMember);
      if (!hierarchyCheck.valid) {
        const err = new Error(hierarchyCheck.error);
        err.code = 'HIERARCHY_VIOLATION';
        throw err;
      }

      // 4. Check if active ban already exists in DB
      const existing = BanRepository.getActiveBan(guild.id, targetUserId);
      if (existing) {
        const err = new Error('العضو لديه منع نشط مسبقاً في السيرفر.');
        err.code = 'ACTIVE_BAN_EXISTS';
        throw err;
      }

      // 5. Calculate expiration timestamp
      const now = new Date().toISOString();
      const expiresAt = calculateExpiresAt(durationSeconds);

      // 6. Atomically save ban to database
      const banRecord = BanRepository.createBan({
        guild_id: guild.id,
        user_id: targetUserId,
        user_tag: userTag,
        reason: reason || 'لا يوجد سبب محدد',
        moderator_id: modId,
        moderator_tag: modTag,
        duration_seconds: durationSeconds,
        created_at: now,
        expires_at: expiresAt
      });

      // 7. Assign the Ban Role to member if currently present in guild
      if (targetMember && hierarchyCheck.role) {
        try {
          await targetMember.roles.add(hierarchyCheck.role, `منع توظيف بواسطة ${modTag} - السبب: ${reason || 'غير محدد'}`);
          logger.info(`تم إعطاء رول منع التوظيف للعضو ${userTag} في السيرفر ${guild.name}`);
        } catch (err) {
          logger.error(`فشل إعطاء الرول للعضو ${targetUserId}: ${err.message}`);
          await NotificationService.notifySystemError(guild, {
            action: 'إعطاء رول منع التوظيف',
            error: err.message,
            targetUserId
          });
        }
      }

      // 8. Create Audit Log entry
      AuditLogRepository.createLog({
        guildId: guild.id,
        action: 'BAN_ISSUED',
        targetUserId,
        targetUserTag: userTag,
        moderatorId: modId,
        moderatorTag: modTag,
        details: {
          banId: banRecord.id,
          reason,
          durationSeconds,
          expiresAt
        }
      });

      // 9. Send Discord Notifications (Citizen channel & Log channel)
      await NotificationService.notifyBanIssued(guild, {
        user: targetUser || { id: targetUserId, tag: userTag, displayAvatarURL: () => null },
        moderator: { id: modId, tag: modTag },
        reason,
        durationSeconds,
        expiresAt,
        banId: banRecord.id
      });

      return banRecord;
    });
  }

  /**
   * Revoke an active hire ban
   */
  static async revokeBan({ guild, targetUserId, moderator, reason }) {
    const lockKey = `${guild.id}:${targetUserId}`;

    return await LockManager.withLock(lockKey, 10000, async () => {
      // 1. Get active ban
      const activeBan = BanRepository.getActiveBan(guild.id, targetUserId);
      if (!activeBan) {
        const err = new Error('لا يوجد منع توظيف نشط لهذا العضو لإلغائه.');
        err.code = 'NO_ACTIVE_BAN';
        throw err;
      }

      const settings = SettingsRepository.getSettings(guild.id);
      const modTag = moderator ? (moderator.tag || moderator.user?.tag || moderator.user?.username || moderator.username || 'إداري') : 'النظام';
      const modId = moderator ? (moderator.id || moderator.user?.id) : 'SYSTEM';

      // 2. Hierarchy check for removing role
      let targetMember = null;
      let targetUser = null;
      try {
        targetMember = guild.members.cache.get(targetUserId) || await guild.members.fetch(targetUserId).catch(() => null);
        if (targetMember) {
          targetUser = targetMember.user;
        } else {
          targetUser = await guild.client.users.fetch(targetUserId).catch(() => null);
        }
      } catch (err) {
        logger.warn(`تعذر جلب بيانات العضو ${targetUserId}: ${err.message}`);
      }

      const userTag = targetUser ? (targetUser.tag || targetUser.username) : activeBan.user_tag;

      // 3. Mark ban as revoked in DB
      BanRepository.revokeBan(activeBan.id, guild.id, modId, modTag, reason);

      // 4. Remove Ban Role from member if in guild and role exists
      if (settings.ban_role_id) {
        const role = guild.roles.cache.get(settings.ban_role_id);
        if (role && targetMember && targetMember.roles.cache.has(role.id)) {
          try {
            await targetMember.roles.remove(role, `إلغاء منع التوظيف بواسطة ${modTag} - السبب: ${reason || 'غير محدد'}`);
            logger.info(`تمت إزالة رول منع التوظيف عن ${userTag}`);
          } catch (err) {
            logger.error(`فشل إزالة الرول عن العضو ${targetUserId}: ${err.message}`);
            await NotificationService.notifySystemError(guild, {
              action: 'إزالة رول منع التوظيف (إلغاء يدوي)',
              error: err.message,
              targetUserId
            });
          }
        }
      }

      // 5. Create Audit Log
      AuditLogRepository.createLog({
        guildId: guild.id,
        action: 'BAN_REVOKED',
        targetUserId,
        targetUserTag: userTag,
        moderatorId: modId,
        moderatorTag: modTag,
        details: {
          banId: activeBan.id,
          reason
        }
      });

      // 6. Notify log channel
      await NotificationService.notifyBanRevoked(guild, {
        user: targetUser || { id: targetUserId, tag: userTag },
        moderator: { id: modId, tag: modTag },
        reason,
        banId: activeBan.id
      });

      return { success: true, banId: activeBan.id };
    });
  }

  /**
   * Update ban duration (extend or shorten)
   */
  static async updateBanDuration({ guild, banId, moderator, newDurationSeconds, reason }) {
    const ban = BanRepository.getBanById(banId, guild.id);
    if (!ban || ban.status !== 'ACTIVE') {
      throw new Error('سجل المنع غير موجود أو غير نشط.');
    }

    const newExpiresAt = calculateExpiresAt(newDurationSeconds);
    const modTag = moderator ? (moderator.tag || moderator.user?.tag || moderator.user?.username || 'إداري') : 'النظام';
    const modId = moderator ? (moderator.id || moderator.user?.id) : 'SYSTEM';

    BanRepository.updateBanDuration(banId, guild.id, newDurationSeconds, newExpiresAt);

    AuditLogRepository.createLog({
      guildId: guild.id,
      action: newDurationSeconds > (ban.duration_seconds || 0) ? 'BAN_EXTENDED' : 'BAN_SHORTENED',
      targetUserId: ban.user_id,
      targetUserTag: ban.user_tag,
      moderatorId: modId,
      moderatorTag: modTag,
      details: {
        banId,
        previousExpiresAt: ban.expires_at,
        newExpiresAt,
        newDurationSeconds,
        reason
      }
    });

    return { success: true, newExpiresAt, newDurationSeconds };
  }

  /**
   * Handle member rejoin event:
   * If member has an active ban whose expires_at is in the future (or permanent),
   * re-assign the Ban Role and log it.
   */
  static async handleRejoiningMember(member) {
    const guild = member.guild;
    const userId = member.id;

    try {
      const activeBan = BanRepository.getActiveBan(guild.id, userId);
      if (!activeBan) return;

      // Check if ban expired while member was outside
      if (activeBan.expires_at) {
        const expiresTime = new Date(activeBan.expires_at).getTime();
        const now = Date.now();
        if (expiresTime <= now) {
          // Expired while outside, mark expired in DB and DO NOT give role
          BanRepository.markExpired(activeBan.id);
          AuditLogRepository.createLog({
            guildId: guild.id,
            action: 'BAN_EXPIRED',
            targetUserId: userId,
            targetUserTag: member.user.tag || member.user.username,
            moderatorId: 'SYSTEM',
            moderatorTag: 'المجدول التلقائي',
            details: {
              banId: activeBan.id,
              note: 'انتهت مدة المنع أثناء وجود العضو خارج السيرفر'
            }
          });
          return;
        }
      }

      // The ban is still active! Re-assign the role
      const settings = SettingsRepository.getSettings(guild.id);
      if (!settings.ban_role_id) return;

      const role = guild.roles.cache.get(settings.ban_role_id);
      if (!role) return;

      const hierarchyCheck = HierarchyGuard.validate(guild, settings.ban_role_id, member);
      if (hierarchyCheck.valid) {
        await member.roles.add(role, 'إعادة تطبيق منع التوظيف النشط تلقائياً عند عودة العضو للسيرفر');
        logger.info(`تمت إعادة رول منع التوظيف للعضو ${member.user.tag} عند عودته للسيرفر.`);

        // Audit Log
        AuditLogRepository.createLog({
          guildId: guild.id,
          action: 'MEMBER_REJOIN',
          targetUserId: userId,
          targetUserTag: member.user.tag || member.user.username,
          moderatorId: 'SYSTEM',
          moderatorTag: 'نظام الحماية',
          details: {
            banId: activeBan.id,
            expiresAt: activeBan.expires_at
          }
        });

        // Discord Notification
        await NotificationService.notifyMemberRejoin(guild, {
          user: member.user,
          banId: activeBan.id,
          expiresAt: activeBan.expires_at
        });
      } else {
        logger.warn(`تعذر إعادة الرول للعضو العائد ${member.user.tag}: ${hierarchyCheck.error}`);
      }
    } catch (err) {
      logger.error(`خطأ أثناء معالجة عودة العضو ${member.id}: ${err.message}`);
    }
  }
}

module.exports = BanService;
