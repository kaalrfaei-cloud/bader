const logger = require('../utils/logger');

class KeepAliveService {
  /**
   * Starts periodic self-ping to prevent Render/cloud hosts from sleeping (Spin Down)
   * Render free tier spins down after 15 minutes of inactivity.
   * Pinging every 9 minutes resets the timer and keeps the bot 24/7 online.
   */
  static start(customUrl = null, intervalMs = 9 * 60 * 1000) {
    const targetUrl =
      customUrl ||
      process.env.RENDER_EXTERNAL_URL ||
      process.env.DASHBOARD_URL;

    if (!targetUrl || targetUrl.includes('localhost') || targetUrl.includes('127.0.0.1')) {
      logger.info('خدمة الاستمرارية (Keep-Alive): في وضع الاستعداد (تعمل تلقائياً عند ضبط DASHBOARD_URL على استضافة سحابية).');
      return null;
    }

    logger.info(`تفعيل خدمة الاستمرارية الذاتية (Keep-Alive) لتشغيل البوت 24/7 على: ${targetUrl}`);

    const timer = setInterval(async () => {
      try {
        const res = await fetch(targetUrl, {
          headers: { 'User-Agent': 'HireBanBot-KeepAlive/1.0' }
        });
        if (res.ok) {
          logger.info(`[Keep-Alive 24/7] تم إرسال نبضة التنشيط للاستضافة بنجاح (${res.status}).`);
        }
      } catch (err) {
        logger.warn(`[Keep-Alive] تعذر إرسال نبضة التنشيط: ${err.message}`);
      }
    }, intervalMs);

    if (timer.unref) timer.unref();

    // Initial ping after 30 seconds to warm up
    setTimeout(async () => {
      try {
        await fetch(targetUrl, { headers: { 'User-Agent': 'HireBanBot-KeepAlive/1.0' } });
      } catch {}
    }, 30000);

    return timer;
  }
}

module.exports = KeepAliveService;
