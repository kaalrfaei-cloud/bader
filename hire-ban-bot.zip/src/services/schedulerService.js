const BanRepository = require('../database/repositories/banRepository');
const SettingsRepository = require('../database/repositories/settingsRepository');
const AuditLogRepository = require('../database/repositories/auditLogRepository');
const NotificationService = require('./notificationService');
const logger = require('../utils/logger');

class SchedulerService {
  constructor(client, intervalMs = 15000) {
    this.client = client;
    this.intervalMs = intervalMs;
    this.timer = null;
    this.isRunning = false;
    this.isProcessing = false;
  }

  /**
   * Start the periodic expiration worker
   */
  start() {
    if (this.isRunning) return;
    this.isRunning = true;
    logger.info(`تم تشغيل خدمة فحص انتهاء المدد التلقائية (كل ${this.intervalMs / 1000} ثانية).`);

    // Run first check immediately
    this.checkExpiredBans().catch(e => logger.error('خطأ في دورة فحص المنتهي الأولي:', e.message));

    this.timer = setInterval(() => {
      this.checkExpiredBans().catch(e => logger.error('خطأ في دورة فحص المنتهي:', e.message));
    }, this.intervalMs);
  }

  /**
   * Stop the scheduler
   */
  stop() {
    if (this.timer) {
      clearInterval(this.timer);
      this.timer = null;
    }
    this.isRunning = false;
    logger.info('تم إيقاف خدمة فحص انتهاء المدد.');
  }

  /**
   * Worker cycle to process all expired active bans
   */
  async checkExpiredBans() {
    if (this.isProcessing) return; // Prevent concurrent cycle overlaps
    this.isProcessing = true;

    try {
      const nowIso = new Date().toISOString();
      const expiredBans = BanRepository.getExpiredActiveBans(nowIso);

      if (!expiredBans || expiredBans.length === 0) {
        return;
      }

      logger.info(`تم العثور على ${expiredBans.length} حالة منع منتهية الصلاحية، جاري معالجتها...`);

      for (const ban of expiredBans) {
        await this.processSingleExpiredBan(ban);
      }
    } catch (err) {
      logger.error('خطأ عام أثناء فحص انتهاء منع التوظيف:', err.message);
    } finally {
      this.isProcessing = false;
    }
  }

  /**
   * Process a single expired ban safely
   */
  async processSingleExpiredBan(ban) {
    try {
      // 1. Atomically mark as EXPIRED in DB first to prevent duplicate loops
      const updated = BanRepository.markExpired(ban.id);
      if (!updated) {
        // Already updated by another operation
        return;
      }

      const guild = this.client.guilds.cache.get(ban.guild_id) || await this.client.guilds.fetch(ban.guild_id).catch(() => null);
      let roleRemoved = false;
      let targetUser = { id: ban.user_id, tag: ban.user_tag };

      if (guild) {
        const settings = SettingsRepository.getSettings(guild.id);
        const role = settings.ban_role_id ? guild.roles.cache.get(settings.ban_role_id) : null;

        // Try fetching member to remove role
        const member = guild.members.cache.get(ban.user_id) || await guild.members.fetch(ban.user_id).catch(() => null);
        if (member) {
          targetUser = member.user;
          if (role && member.roles.cache.has(role.id)) {
            try {
              await member.roles.remove(role, 'انتهاء مدة منع التوظيف تلقائياً');
              roleRemoved = true;
              logger.info(`تمت إزالة رول منع التوظيف لانتهاء المدة عن ${member.user.tag} في ${guild.name}`);
            } catch (roleErr) {
              logger.error(`فشل إزالة الرول عن العضو المنتهي ${ban.user_id}: ${roleErr.message}`);
            }
          }
        } else {
          logger.info(`العضو ${ban.user_tag} غير موجود بالسيرفر حالياً عند انتهاء منعه #${ban.id}.`);
        }

        // Send Discord notification to log channel
        await NotificationService.notifyBanExpired(guild, {
          user: targetUser,
          banId: ban.id,
          roleRemoved
        });
      }

      // Write Audit Log
      AuditLogRepository.createLog({
        guildId: ban.guild_id,
        action: 'BAN_EXPIRED',
        targetUserId: ban.user_id,
        targetUserTag: ban.user_tag,
        moderatorId: 'SYSTEM',
        moderatorTag: 'المجدول التلقائي',
        details: {
          banId: ban.id,
          roleRemoved,
          expiredAt: ban.expires_at
        }
      });
    } catch (err) {
      logger.error(`خطأ أثناء معالجة انتهاء المنع #${ban.id}:`, err.message);
    }
  }
}

module.exports = SchedulerService;
