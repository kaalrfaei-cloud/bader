const BanRepository = require('../database/repositories/banRepository');
const SettingsRepository = require('../database/repositories/settingsRepository');
const AuditLogRepository = require('../database/repositories/auditLogRepository');
const NotificationService = require('./notificationService');
const { retryWithBackoff } = require('../utils/retryHelper');
const logger = require('../utils/logger');

class SchedulerService {
  constructor(client, intervalMs = 15000) {
    this.client = client;
    this.intervalMs = intervalMs;
    this.timer = null;
    this.isRunning = false;
    this.isProcessing = false;
  }

  /**
   * Start the periodic expiration worker and role watchdog
   */
  start() {
    if (this.isRunning) return;
    this.isRunning = true;
    logger.info(`تم تشغيل خدمة فحص انتهاء المدد ومراقبة الرتب التلقائية (كل ${this.intervalMs / 1000} ثانية).`);

    // Run first checks immediately
    this.runCycle().catch(e => logger.error('خطأ في دورة الفحص الأولية:', e.message));

    this.timer = setInterval(() => {
      this.runCycle().catch(e => logger.error('خطأ في دورة الفحص الدورية:', e.message));
    }, this.intervalMs);
  }

  /**
   * Run full cycle: Expiration check + Active Bans Role Watchdog
   */
  async runCycle() {
    await this.checkExpiredBans().catch(e => logger.error('خطأ في دورة فحص المنتهي:', e.message));
    await this.checkRoleWatchdog().catch(e => logger.error('خطأ في دورة مراقبة الرتب:', e.message));
  }

  /**
   * Stop the scheduler
   */
  stop() {
    if (this.timer) {
      clearInterval(this.timer);
      this.timer = null;
    }
    this.isRunning = false;
    logger.info('تم إيقاف خدمة فحص انتهاء المدد ومراقبة الرتب.');
  }

  /**
   * Worker cycle to process all expired active and expiring bans
   */
  async checkExpiredBans() {
    if (this.isProcessing) return; // Prevent concurrent cycle overlaps
    this.isProcessing = true;

    try {
      const nowIso = new Date().toISOString();
      const expiredBans = BanRepository.getExpiredActiveBans(nowIso);

      if (!expiredBans || expiredBans.length === 0) {
        return;
      }

      logger.info(`تم العثور على ${expiredBans.length} حالة منع منتهية الصلاحية/قيد المعالجة، جاري إنهائها...`);

      for (const ban of expiredBans) {
        await this.processSingleExpiredBan(ban);
      }
    } catch (err) {
      logger.error('خطأ عام أثناء فحص انتهاء منع التوظيف:', err.message);
    } finally {
      this.isProcessing = false;
    }
  }

  /**
   * Process a single expired ban with State Machine (ACTIVE -> EXPIRING -> Remove Role -> EXPIRED)
   */
  async processSingleExpiredBan(ban) {
    try {
      // 1. Step 1: Transition to EXPIRING in DB
      if (ban.status === 'ACTIVE') {
        BanRepository.startExpire(ban.id);
      }

      const guild = this.client.guilds.cache.get(ban.guild_id) || (this.client.guilds.fetch ? await this.client.guilds.fetch(ban.guild_id).catch(() => null) : null);
      let roleRemoved = false;
      let targetUser = { id: ban.user_id, tag: ban.user_tag };

      if (guild) {
        const settings = SettingsRepository.getSettings(guild.id);
        const role = settings.ban_role_id ? (guild.roles.cache.get(settings.ban_role_id) || (guild.roles.fetch ? await guild.roles.fetch(settings.ban_role_id).catch(() => null) : null)) : null;

        // Try fetching member to remove role
        const member = guild.members.cache.get(ban.user_id) || (guild.members.fetch ? await guild.members.fetch(ban.user_id).catch(() => null) : null);
        if (member) {
          targetUser = member.user;
          if (role && member.roles.cache.has(role.id)) {
            try {
              // 2. Step 2: Remove role with Retry
              await retryWithBackoff(async () => {
                await member.roles.remove(role, 'انتهاء مدة منع التوظيف تلقائياً');
              }, {
                maxRetries: 3,
                initialDelayMs: 300,
                operationName: `Remove role on ban expiration for ${ban.user_tag}`
              });
              roleRemoved = true;
              logger.info(`تمت إزالة رول منع التوظيف لانتهاء المدة عن ${member.user?.tag || ban.user_tag} في ${guild.name}`);
            } catch (roleErr) {
              logger.error(`[Scheduler] فشل إزالة الرول عن العضو المنتهي ${ban.user_id}: ${roleErr.message}`);
              // Leave status as EXPIRING so next cycle retries until Discord state is fixed!
              AuditLogRepository.createLog({
                guildId: ban.guild_id,
                action: 'EXPIRE_RETRY_PENDING',
                targetUserId: ban.user_id,
                targetUserTag: ban.user_tag,
                moderatorId: 'SYSTEM',
                moderatorTag: 'المجدول التلقائي',
                details: {
                  banId: ban.id,
                  error: roleErr.message,
                  note: 'سيتم إعادة المحاولة في الدورة القادمة'
                }
              });
              return; // Do not mark as EXPIRED yet
            }
          }
        } else {
          logger.info(`العضو ${ban.user_tag} غير موجود بالسيرفر حالياً عند انتهاء منعه #${ban.id}.`);
        }

        // Send Discord notification to log channel
        await NotificationService.notifyBanExpired(guild, {
          user: targetUser,
          banId: ban.id,
          roleRemoved
        });
      }

      // 3. Step 3: Transition to EXPIRED
      BanRepository.markExpired(ban.id);

      // Write Audit Log
      AuditLogRepository.createLog({
        guildId: ban.guild_id,
        action: 'BAN_EXPIRED',
        targetUserId: ban.user_id,
        targetUserTag: ban.user_tag,
        moderatorId: 'SYSTEM',
        moderatorTag: 'المجدول التلقائي',
        details: {
          banId: ban.id,
          roleRemoved,
          expiredAt: ban.expires_at,
          result: 'SUCCESS'
        }
      });
    } catch (err) {
      logger.error(`خطأ أثناء معالجة انتهاء المنع #${ban.id}:`, err.message);
    }
  }

  /**
   * Watchdog guardian: Scans all active bans across all guilds.
   * If any banned member is currently inside the guild but is missing the ban role,
   * it re-assigns the role automatically to prevent any role strip bypass!
   */
  async checkRoleWatchdog() {
    try {
      if (!this.client.guilds || !this.client.guilds.cache) return;

      for (const [guildId, guild] of this.client.guilds.cache) {
        const settings = SettingsRepository.getSettings(guildId);
        const banRoleId = settings.ban_role_id;
        if (!banRoleId) continue;

        const role = guild.roles.cache.get(banRoleId) || (guild.roles.fetch ? await guild.roles.fetch(banRoleId).catch(() => null) : null);
        if (!role) continue;

        const { bans } = BanRepository.listBans({ guildId, status: 'ACTIVE', limit: 200 });
        if (!bans || bans.length === 0) continue;

        const now = Date.now();
        for (const ban of bans) {
          // If expired, skip (handled by checkExpiredBans)
          if (ban.expires_at && new Date(ban.expires_at).getTime() <= now) continue;

          let member = guild.members.cache.get(ban.user_id);
          if (!member && guild.members.fetch) {
            member = await guild.members.fetch(ban.user_id).catch(() => null);
          }
          if (!member) continue; // Member not in guild

          const hasRole = member.roles?.cache ? member.roles.cache.has(banRoleId) : false;
          if (!hasRole) {
            logger.warn(`[Role Watchdog] رصد العضو ${member.user?.tag || ban.user_tag} بدون رتبة منع التوظيف في ${guild.name}! جاري إعادتها فوراً...`);
            try {
              await member.roles.add(role, 'إعادة تلقائية عبر مراقب الرتب المستمر (Role Watchdog) - منع نشط في النظام');
              logger.info(`[Role Watchdog] تمت إعادة رتبة منع التوظيف بنجاح للعضو ${member.user?.tag || ban.user_tag}`);
            } catch (err) {
              logger.error(`[Role Watchdog] تعذر إعادة الرتبة للعضو ${ban.user_id}: ${err.message}`);
            }
          }
        }
      }
    } catch (err) {
      logger.error('خطأ في دورة مراقب الرتب التلقائي:', err.message);
    }
  }
}

module.exports = SchedulerService;
