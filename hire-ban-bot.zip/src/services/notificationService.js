const SettingsRepository = require('../database/repositories/settingsRepository');
const { Embeds } = require('../utils/embedBuilder');
const logger = require('../utils/logger');

class NotificationService {
  /**
   * Safely fetch a text channel from a guild
   */
  static async getSafeChannel(guild, channelId) {
    if (!guild || !channelId) return null;
    try {
      let channel = guild.channels.cache.get(channelId);
      if (!channel) {
        channel = await guild.channels.fetch(channelId).catch(() => null);
      }
      if (channel && channel.isTextBased()) {
        return channel;
      }
      return null;
    } catch (err) {
      logger.warn(`تعذر الوصول إلى الروم ${channelId} في السيرفر ${guild.id}: ${err.message}`);
      return null;
    }
  }

  /**
   * Send notification for a newly issued hire ban
   */
  static async notifyBanIssued(guild, { user, moderator, reason, durationSeconds, expiresAt, banId }) {
    const settings = SettingsRepository.getSettings(guild.id);
    const notifs = settings.notification_settings || {};

    // 1. Send to citizen channel (public announcement)
    if (notifs.ban && settings.citizen_channel_id) {
      try {
        const citizenChannel = await this.getSafeChannel(guild, settings.citizen_channel_id);
        if (citizenChannel) {
          const embed = Embeds.banCitizenEmbed({ user, moderator, reason, durationSeconds, expiresAt });
          await citizenChannel.send({ embeds: [embed] }).catch(e => {
            logger.warn(`فشل إرسال إشعار المنع لروم المواطنين (${citizenChannel.id}): ${e.message}`);
          });
        }
      } catch (err) {
        logger.warn(`خطأ أثناء إرسال إشعار المواطنين: ${err.message}`);
      }
    }

    // 2. Send to audit log channel
    if (notifs.logs && settings.log_channel_id) {
      try {
        const logChannel = await this.getSafeChannel(guild, settings.log_channel_id);
        if (logChannel) {
          const embed = Embeds.banLogEmbed({ user, moderator, reason, durationSeconds, expiresAt, banId });
          await logChannel.send({ embeds: [embed] }).catch(e => {
            logger.warn(`فشل إرسال إشعار السجل لروم السجلات (${logChannel.id}): ${e.message}`);
          });
        }
      } catch (err) {
        logger.warn(`خطأ أثناء إرسال إشعار السجلات: ${err.message}`);
      }
    }
  }

  /**
   * Send notification for revoked ban
   */
  static async notifyBanRevoked(guild, { user, moderator, reason, banId }) {
    const settings = SettingsRepository.getSettings(guild.id);
    const notifs = settings.notification_settings || {};

    if (notifs.revoke && settings.log_channel_id) {
      try {
        const logChannel = await this.getSafeChannel(guild, settings.log_channel_id);
        if (logChannel) {
          const embed = Embeds.revokeLogEmbed({ user, moderator, reason, banId });
          await logChannel.send({ embeds: [embed] }).catch(e => {
            logger.warn(`فشل إرسال إشعار إلغاء المنع: ${e.message}`);
          });
        }
      } catch (err) {
        logger.warn(`خطأ أثناء إرسال إشعار إلغاء المنع: ${err.message}`);
      }
    }
  }

  /**
   * Send notification for auto-expired ban
   */
  static async notifyBanExpired(guild, { user, banId, roleRemoved }) {
    const settings = SettingsRepository.getSettings(guild.id);
    const notifs = settings.notification_settings || {};

    if (notifs.expire && settings.log_channel_id) {
      try {
        const logChannel = await this.getSafeChannel(guild, settings.log_channel_id);
        if (logChannel) {
          const embed = Embeds.expireLogEmbed({ user, banId, roleRemoved });
          await logChannel.send({ embeds: [embed] }).catch(e => {
            logger.warn(`فشل إرسال إشعار انتهاء المنع: ${e.message}`);
          });
        }
      } catch (err) {
        logger.warn(`خطأ أثناء إرسال إشعار انتهاء المنع: ${err.message}`);
      }
    }
  }

  /**
   * Send notification when an actively banned member rejoins
   */
  static async notifyMemberRejoin(guild, { user, banId, expiresAt }) {
    const settings = SettingsRepository.getSettings(guild.id);
    const notifs = settings.notification_settings || {};

    if (notifs.rejoin && settings.log_channel_id) {
      try {
        const logChannel = await this.getSafeChannel(guild, settings.log_channel_id);
        if (logChannel) {
          const embed = Embeds.rejoinLogEmbed({ user, banId, expiresAt });
          await logChannel.send({ embeds: [embed] }).catch(e => {
            logger.warn(`فشل إرسال إشعار عودة العضو الممنوع: ${e.message}`);
          });
        }
      } catch (err) {
        logger.warn(`خطأ أثناء إرسال إشعار عودة العضو الممنوع: ${err.message}`);
      }
    }
  }

  /**
   * Send system error notice to log channel
   */
  static async notifySystemError(guild, { action, error, targetUserId = null, details = null }) {
    try {
      const settings = SettingsRepository.getSettings(guild.id);
      if (settings.log_channel_id) {
        const logChannel = await this.getSafeChannel(guild, settings.log_channel_id);
        if (logChannel) {
          const embed = Embeds.errorLogEmbed({ action, error, targetUserId, details });
          await logChannel.send({ embeds: [embed] }).catch(() => {});
        }
      }
    } catch {
      // Ignore notification failures
    }
  }
}

module.exports = NotificationService;
