const rateLimit = require('express-rate-limit');

// 1. General API: 100 requests per minute
const apiLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 100,
  standardHeaders: true,
  legacyHeaders: false,
  validate: { trustProxy: false },
  message: { error: 'تم تجاوز الحد المسموح من الطلبات، يرجى المحاولة بعد قليل.' }
});

// 2. Passcode Login Limiter: 10 attempts per 15 minutes (with internal progressive delay & lockout)
const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 10,
  standardHeaders: true,
  legacyHeaders: false,
  validate: { trustProxy: false },
  message: { error: 'تم تجاوز الحد المسموح لمحاولات تسجيل الدخول، يرجى الانتظار 15 دقيقة.' }
});

// 3. OAuth2 Callback Limiter: 15 attempts per 5 minutes
const oauthLimiter = rateLimit({
  windowMs: 5 * 60 * 1000,
  max: 15,
  standardHeaders: true,
  legacyHeaders: false,
  validate: { trustProxy: false },
  message: { error: 'تم تكرار محاولات الربط مع Discord، يرجى الانتظار 5 دقائق.' }
});

// 4. 2FA Verification Limiter: 10 attempts per 10 minutes
const twoFaLimiter = rateLimit({
  windowMs: 10 * 60 * 1000,
  max: 10,
  standardHeaders: true,
  legacyHeaders: false,
  validate: { trustProxy: false },
  message: { error: 'تم تجاوز الحد المسموح لمحاولات 2FA، يرجى الانتظار 10 دقائق.' }
});

// 5. Ban Action Limiter: 20 bans per minute
const banLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 20,
  standardHeaders: true,
  legacyHeaders: false,
  validate: { trustProxy: false },
  message: { error: 'لقد قمت بعدد كبير من عمليات المنع في وقت قصير، يرجى الانتظار دقيقة.' }
});

// 6. Unban / Revoke Limiter: 20 per minute
const unbanLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 20,
  standardHeaders: true,
  legacyHeaders: false,
  validate: { trustProxy: false },
  message: { error: 'لقد قمت بعدد كبير من عمليات إلغاء المنع في وقت قصير، يرجى الانتظار دقيقة.' }
});

// 7. Settings Update Limiter: 10 per minute
const settingsLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 10,
  standardHeaders: true,
  legacyHeaders: false,
  validate: { trustProxy: false },
  message: { error: 'تم تجاوز الحد المسموح لتعديل الإعدادات، يرجى الانتظار دقيقة.' }
});

module.exports = {
  apiLimiter,
  loginLimiter,
  oauthLimiter,
  twoFaLimiter,
  banLimiter,
  unbanLimiter,
  settingsLimiter,
  sensitiveActionLimiter: banLimiter
};
