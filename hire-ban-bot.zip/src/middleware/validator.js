const { z } = require('zod');

const snowflakeRegex = /^\d{17,20}$/;

const schemas = {
  guildIdParam: z.object({
    guildId: z.string().regex(snowflakeRegex, 'معرف السيرفر غير صالح.')
  }),

  banIdParam: z.object({
    id: z.string().regex(/^\d+$/, 'معرف المنع غير صالح.').transform(Number)
  }),

  createBan: z.object({
    userId: z.string().regex(snowflakeRegex, 'معرف العضو غير صالح (يجب أن يتكون من 17-20 رقماً).'),
    durationValue: z.union([z.string().min(1).max(20), z.number().int().min(1).max(3650)]),
    durationUnit: z.enum(['m', 'h', 'd', 'w', 'perm']).optional(),
    reason: z.string().max(500, 'السبب يجب ألا يتجاوز 500 حرف.').optional().default('منع توظيف إداري')
  }),

  extendBan: z.object({
    durationValue: z.union([z.string().min(1).max(20), z.number().int().min(1).max(3650)]),
    durationUnit: z.enum(['m', 'h', 'd', 'w', 'perm']),
    reason: z.string().max(500, 'السبب يجب ألا يتجاوز 500 حرف.').optional().default('تعديل المدة من لوحة التحكم')
  }),

  revokeBan: z.object({
    reason: z.string().max(500, 'السبب يجب ألا يتجاوز 500 حرف.').optional().default('إلغاء عبر لوحة التحكم')
  }),

  settings: z.object({
    admin_channel_id: z.string().regex(snowflakeRegex).nullable().optional(),
    citizen_channel_id: z.string().regex(snowflakeRegex).nullable().optional(),
    log_channel_id: z.string().regex(snowflakeRegex).nullable().optional(),
    ban_role_id: z.string().regex(snowflakeRegex).nullable().optional(),
    allowed_roles: z.array(z.string().regex(snowflakeRegex)).optional().default([]),
    cancel_roles: z.array(z.string().regex(snowflakeRegex)).optional().default([]),
    dashboard_roles: z.array(z.string().regex(snowflakeRegex)).optional().default([]),
    allow_permanent_bans: z.boolean().optional().default(true),
    notification_settings: z.record(z.boolean()).optional()
  }),

  passcode: z.object({
    passcode: z.string().min(1, 'يرجى إدخال رمز المرور.').max(100),
    totpToken: z.string().regex(/^\d{6}$/, 'رمز المصادقة الثنائية يجب أن يتكون من 6 أرقام.').optional()
  })
};

function validateBody(schema) {
  return (req, res, next) => {
    const result = schema.safeParse(req.body);
    if (!result.success) {
      const firstError = result.error.errors[0]?.message || 'البيانات المدخلة غير صالحة.';
      return res.status(400).json({ error: firstError, details: result.error.format() });
    }
    req.validatedBody = result.data;
    next();
  };
}

function validateParams(schema) {
  return (req, res, next) => {
    const result = schema.safeParse(req.params);
    if (!result.success) {
      const firstError = result.error.errors[0]?.message || 'معرفات المسار غير صالحة.';
      return res.status(400).json({ error: firstError });
    }
    req.validatedParams = result.data;
    next();
  };
}

module.exports = {
  schemas,
  validateBody,
  validateParams
};
