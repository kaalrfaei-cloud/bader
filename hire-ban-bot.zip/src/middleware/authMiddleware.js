function requireAuth(req, res, next) {
  if (!req.session || !req.session.user) {
    if (req.xhr || req.headers.accept?.includes('application/json') || req.path.startsWith('/api/')) {
      return res.status(401).json({ error: 'غير مصرح به. يرجى تسجيل الدخول بواسطة Discord.' });
    }
    return res.redirect('/auth/login');
  }
  next();
}

module.exports = { requireAuth };
