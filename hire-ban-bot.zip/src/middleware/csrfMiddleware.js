const crypto = require('crypto');

/**
 * Strict CSRF protection middleware for sessions
 */
function csrfProtection(req, res, next) {
  if (!req.session) {
    return next();
  }

  // Ensure a CSRF token exists for this session
  if (!req.session.csrfToken) {
    req.session.csrfToken = crypto.randomBytes(32).toString('hex');
  }

  // Read-only methods don't mutate state; expose token in response headers
  if (['GET', 'HEAD', 'OPTIONS'].includes(req.method)) {
    res.setHeader('X-CSRF-Token', req.session.csrfToken);
    return next();
  }

  // Exempt ONLY login entrypoints (OAuth callback, passcode login, and OAuth init)
  const exemptPaths = ['/auth/login', '/auth/callback', '/auth/passcode'];
  const path = req.path || req.originalUrl || '';
  if (exemptPaths.some(p => path.endsWith(p))) {
    return next();
  }

  // All state-changing requests (POST, PUT, DELETE, PATCH) MUST provide valid CSRF token
  const clientToken = req.headers['x-csrf-token'] || req.body?._csrf;

  if (!clientToken || clientToken !== req.session.csrfToken) {
    return res.status(403).json({
      error: 'رمز التحقق الأمني (CSRF Token) غير صالح أو مفقود. يرجى تحديث الصفحة والمحاولة مجدداً.'
    });
  }

  next();
}

module.exports = csrfProtection;
