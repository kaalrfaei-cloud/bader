const { EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const SettingsRepository = require('../../database/repositories/settingsRepository');
const BanRepository = require('../../database/repositories/banRepository');
const { formatDuration } = require('../../utils/timeParser');
const logger = require('../../utils/logger');

function normalizeArabic(text) {
  if (!text) return '';
  return text
    .replace(/[\u064B-\u065F\u0640]/g, '') // remove tashkeel & tatweel
    .replace(/[؟?!\.,؛:ـ]/g, '')           // remove common punctuation
    .trim();
}

async function handleBanCheck(message, targetUserId, targetUser, isSelf) {
  const activeBan = BanRepository.getActiveBan(message.guild.id, targetUserId);
  const targetTag = targetUser ? (targetUser.tag || targetUser.username) : `المعرف: ${targetUserId}`;
  const targetMention = `<@${targetUserId}>`;

  if (!activeBan) {
    const embed = new EmbedBuilder()
      .setColor('#10b981')
      .setTitle('✅ لا يوجد منع توظيف')
      .setDescription(
        isSelf
          ? `أهلاً بك ${targetMention}، **ليس لديك أي منع توظيف حالياً** في سيرفر **${message.guild.name}** ويمكنك التوظيف بشكل طبيعي.`
          : `العضو ${targetMention} (${targetTag}) **ليس لديه أي منع توظيف حالياً** في هذا السيرفر.`
      )
      .setFooter({ text: 'نظام الاستعلام عن منع التوظيف • روم المواطنين' })
      .setTimestamp();

    const fallbackText = isSelf
      ? `✅ أهلاً بك ${targetMention}، **ليس لديك أي منع توظيف حالياً** في سيرفر **${message.guild.name}** ويمكنك التوظيف بشكل طبيعي.`
      : `✅ العضو ${targetMention} (${targetTag}) **ليس لديه أي منع توظيف حالياً** في هذا السيرفر.`;

    try {
      return await message.channel.send({ embeds: [embed] });
    } catch (e1) {
      try {
        return await message.reply({ embeds: [embed] });
      } catch (e2) {
        return await message.channel.send({ content: fallbackText }).catch(() => {});
      }
    }
  }

  // Active ban found! Calculate remaining duration and exact timestamps
  let remainingText = '';
  let expiresTimestampText = '';

  if (activeBan.expires_at) {
    const expiresMs = new Date(activeBan.expires_at).getTime();
    const remainingMs = expiresMs - Date.now();

    if (remainingMs <= 0) {
      remainingText = 'منتهي الصلاحية (جاري الرفع تلقائياً عبر النظام)';
      expiresTimestampText = 'انتهى';
    } else {
      const remainingSecs = Math.floor(remainingMs / 1000);
      const formatted = formatDuration(remainingSecs);
      const discordTimestamp = Math.floor(expiresMs / 1000);
      remainingText = `⏳ **${formatted}** (<t:${discordTimestamp}:R>)`;
      expiresTimestampText = `<t:${discordTimestamp}:F> (<t:${discordTimestamp}:R>)`;
    }
  } else {
    remainingText = '♾️ **منع دائم**';
    expiresTimestampText = 'منع دائم (غير محدد التاريخ)';
  }

  const startTimestamp = Math.floor(new Date(activeBan.created_at).getTime() / 1000);

  const embed = new EmbedBuilder()
    .setColor('#ef4444')
    .setTitle('🚫 تفاصيل منع التوظيف')
    .setDescription(
      isSelf
        ? `تنبيه ${targetMention}، يوجد عليك **منع توظيف نشط** حالياً في هذا السيرفر.`
        : `تنبيه: العضو ${targetMention} لديه **منع توظيف نشط** حالياً في هذا السيرفر.`
    )
    .addFields(
      { name: '👤 العضو', value: `${targetMention} (${targetTag})`, inline: true },
      { name: '📋 الحالة', value: '🔴 **منع توظيف نشط**', inline: true },
      { name: '⏳ الوقت المتبقي', value: remainingText, inline: false },
      { name: '📝 سبب المنع', value: activeBan.reason || 'لا يوجد سبب مسجل', inline: false },
      { name: '📅 تاريخ البداية', value: `<t:${startTimestamp}:F> (<t:${startTimestamp}:R>)`, inline: true },
      { name: '⏰ تاريخ الانتهاء', value: expiresTimestampText, inline: true }
    )
    .setFooter({ text: 'بـوت مـنـع الـتـوظـيـف • روم المواطنين' })
    .setTimestamp();

  try {
    return await message.channel.send({ embeds: [embed] });
  } catch (e1) {
    try {
      return await message.reply({ embeds: [embed] });
    } catch (e2) {
      const fallbackText = `🚫 **تنبيه منع توظيف**\nالعضو: ${targetMention}\nالحالة: نشط\nالوقت المتبقي: ${remainingText}\nالسبب: ${activeBan.reason || 'لا يوجد'}`;
      return await message.channel.send({ content: fallbackText }).catch(() => {});
    }
  }
}

// In-memory message deduplication cache
const processedMessageIds = new Set();

module.exports = {
  name: 'messageCreate',
  once: false,
  async execute(message) {
    // 1. Ignore bot messages and non-guild channels
    if (!message || message.author?.bot || !message.guild) return;

    // 2. Prevent duplicate execution for the same message (in-process deduplication)
    if (message.id) {
      if (processedMessageIds.has(message.id)) return;
      processedMessageIds.add(message.id);
      setTimeout(() => processedMessageIds.delete(message.id), 30000).unref();
    }

    // 3. Fetch guild settings
    let settings = {};
    try {
      settings = SettingsRepository.getSettings(message.guild.id) || {};
    } catch (e) {
      settings = {};
    }

    let citizenChannelId = settings.citizen_channel_id;
    const adminChannelId = settings.admin_channel_id;

    // Auto-detect citizen channel by name if not explicitly configured in settings
    const chName = (message.channel.name || '').toLowerCase();
    const isCitizenByName = chName.includes('استعلام') || chName.includes('مواطن') || chName.includes('منع-التوظيف');

    if (!citizenChannelId && isCitizenByName) {
      citizenChannelId = message.channel.id;
      try {
        SettingsRepository.saveSettings(message.guild.id, { citizen_channel_id: citizenChannelId });
        logger.info(`[Auto-Config] تم تعيين روم المواطنين تلقائياً للسيرفر ${message.guild.name}: #${chName} (${citizenChannelId})`);
      } catch {}
    }

    const content = message.content ? message.content.trim() : '';
    const cleanContent = normalizeArabic(content);

    const isCitizenChannel = Boolean(citizenChannelId && message.channel.id === citizenChannelId);
    const isAdminChannel = Boolean(adminChannelId && message.channel.id === adminChannelId);

    // Rule 1: If message is outside the designated citizen/admin channels, DO NOT respond at all!
    if (citizenChannelId && !isCitizenChannel && !isAdminChannel) {
      return;
    }

    // In citizen channel: ONLY allow valid ban check queries. Everything else is deleted silently without replies.
    if (isCitizenChannel) {
      const mentionedUser = message.mentions?.users?.first ? message.mentions.users.first() : null;
      const idMatch = content.match(/\b(\d{17,20})\b/);
      const isExactCommand = /^(منع|فحص|استعلام|check|ban)$/i.test(cleanContent);
      const isPrefixCommand = /^(منع|فحص|استعلام|check|ban)\s+/i.test(cleanContent);
      const isPureId = /^\d{17,20}$/.test(cleanContent);
      const isPureMention = /^<@!?\d{17,20}>$/.test(cleanContent);

      const isValidCheck = isExactCommand || isPrefixCommand || isPureId || (isPureMention && mentionedUser);

      if (isValidCheck) {
        // Delete the user's check command message immediately to keep citizen channel completely clean
        try {
          await message.delete().catch(() => {});
        } catch {}

        if (mentionedUser) {
          await handleBanCheck(message, mentionedUser.id, mentionedUser, mentionedUser.id === message.author.id);
          return;
        } else if (idMatch) {
          const targetUserId = idMatch[1];
          let targetUser = null;
          try {
            targetUser = await message.client.users.fetch(targetUserId).catch(() => null);
          } catch {}
          await handleBanCheck(message, targetUserId, targetUser, targetUserId === message.author.id);
          return;
        } else {
          // Self check (e.g. typing "منع")
          await handleBanCheck(message, message.author.id, message.author, true);
          return;
        }
      }

      // Non-command chatter in citizen room: delete message immediately and DO NOT reply
      try {
        await message.delete().catch((err) => {
          logger.warn(`تعذر حذف الرسالة غير المصرح بها في روم المواطنين (تأكد من إعطاء البوت صلاحية Manage Messages): ${err.message}`);
        });
      } catch (err) {
        logger.warn(`تعذر حذف الرسالة غير المصرح بها في روم المواطنين: ${err.message}`);
      }
      return;
    }

    // In admin channel: only trigger if explicitly starts with command
    if (isAdminChannel) {
      const mentionedUser = message.mentions?.users?.first ? message.mentions.users.first() : null;
      const idMatch = content.match(/\b(\d{17,20})\b/);
      const isExactCommand = /^(منع|فحص|استعلام)$/i.test(cleanContent);
      const isPrefixCommand = /^(منع|فحص|استعلام)\s+/i.test(cleanContent);

      if (isExactCommand || isPrefixCommand) {
        if (mentionedUser) {
          await handleBanCheck(message, mentionedUser.id, mentionedUser, mentionedUser.id === message.author.id);
        } else if (idMatch) {
          const targetUserId = idMatch[1];
          let targetUser = null;
          try {
            targetUser = await message.client.users.fetch(targetUserId).catch(() => null);
          } catch {}
          await handleBanCheck(message, targetUserId, targetUser, targetUserId === message.author.id);
        } else {
          await handleBanCheck(message, message.author.id, message.author, true);
        }
      }
    }
  }
};
