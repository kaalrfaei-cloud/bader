const { EmbedBuilder } = require('discord.js');
const SettingsRepository = require('../../database/repositories/settingsRepository');
const BanRepository = require('../../database/repositories/banRepository');
const { formatDuration } = require('../../utils/timeParser');
const logger = require('../../utils/logger');

async function handleBanCheck(message, targetUserId, targetUser, isSelf) {
  const activeBan = BanRepository.getActiveBan(message.guild.id, targetUserId);
  const targetTag = targetUser ? (targetUser.tag || targetUser.username) : `المعرف: ${targetUserId}`;
  const targetMention = `<@${targetUserId}>`;

  if (!activeBan) {
    const embed = new EmbedBuilder()
      .setColor('#10b981')
      .setTitle('✅ لا يوجد منع توظيف')
      .setDescription(
        isSelf
          ? `أهلاً بك ${targetMention}، **ليس لديك أي منع توظيف حالياً** في سيرفر **${message.guild.name}** ويمكنك التوظيف بشكل طبيعي.`
          : `العضو ${targetMention} (${targetTag}) **ليس لديه أي منع توظيف حالياً** في هذا السيرفر.`
      )
      .setFooter({ text: 'نظام الاستعلام عن منع التوظيف • روم المواطنين' })
      .setTimestamp();

    const fallbackText = isSelf
      ? `✅ أهلاً بك ${targetMention}، **ليس لديك أي منع توظيف حالياً** في سيرفر **${message.guild.name}** ويمكنك التوظيف بشكل طبيعي.`
      : `✅ العضو ${targetMention} (${targetTag}) **ليس لديه أي منع توظيف حالياً** في هذا السيرفر.`;

    try {
      return await message.reply({ embeds: [embed] });
    } catch (e1) {
      try {
        return await message.channel.send({ embeds: [embed] });
      } catch (e2) {
        return await message.channel.send({ content: fallbackText }).catch(() => {});
      }
    }
  }

  // Active ban found! Calculate remaining duration
  let remainingText = '';
  let expiresTimestampText = '';

  if (activeBan.expires_at) {
    const expiresMs = new Date(activeBan.expires_at).getTime();
    const remainingMs = expiresMs - Date.now();

    if (remainingMs <= 0) {
      remainingText = 'منتهي الصلاحية (جاري الرفع تلقائياً عبر النظام)';
      expiresTimestampText = 'انتهى';
    } else {
      const remainingSecs = Math.floor(remainingMs / 1000);
      const formatted = formatDuration(remainingSecs);
      const discordTimestamp = Math.floor(expiresMs / 1000);
      remainingText = `⏳ **${formatted}** (<t:${discordTimestamp}:R>)`;
      expiresTimestampText = `<t:${discordTimestamp}:F>`;
    }
  } else {
    remainingText = '♾️ **منع دائم**';
    expiresTimestampText = 'منع دائم (غير محدد التاريخ)';
  }

  const startTimestamp = Math.floor(new Date(activeBan.created_at).getTime() / 1000);

  const embed = new EmbedBuilder()
    .setColor('#ef4444')
    .setTitle('🚫 تفاصيل منع التوظيف')
    .setDescription(
      isSelf
        ? `تنبيه ${targetMention}، يوجد عليك **منع توظيف نشط** حالياً في هذا السيرفر.`
        : `تنبيه: العضو ${targetMention} لديه **منع توظيف نشط** حالياً في هذا السيرفر.`
    )
    .addFields(
      { name: '👤 العضو', value: `${targetMention} (${targetTag})`, inline: true },
      { name: '📋 الحالة', value: '🔴 **منع توظيف نشط**', inline: true },
      { name: '⏳ الوقت المتبقي', value: remainingText, inline: false },
      { name: '📝 سبب المنع', value: activeBan.reason || 'لا يوجد سبب مسجل', inline: false },
      { name: '📅 تاريخ البداية', value: `<t:${startTimestamp}:F> (<t:${startTimestamp}:R>)`, inline: true },
      { name: '⏰ تاريخ الانتهاء', value: expiresTimestampText, inline: true }
    )
    .setFooter({ text: 'بـوت مـنـع الـتـوظـيـف • روم المواطنين' })
    .setTimestamp();

  try {
    return await message.reply({ embeds: [embed] });
  } catch (e1) {
    try {
      return await message.channel.send({ embeds: [embed] });
    } catch (e2) {
      const fallbackText = `🚫 **تنبيه منع توظيف**\nالعضو: ${targetMention}\nالحالة: نشط\nالوقت المتبقي: ${remainingText}\nالسبب: ${activeBan.reason || 'لا يوجد'}`;
      return await message.channel.send({ content: fallbackText }).catch(() => {});
    }
  }
}

module.exports = {
  name: 'messageCreate',
  once: false,
  async execute(message) {
    // 1. Ignore bot messages and non-guild channels
    if (!message || message.author.bot || !message.guild) return;

    // 2. Fetch guild settings
    let settings = {};
    try {
      settings = SettingsRepository.getSettings(message.guild.id) || {};
    } catch (e) {
      settings = {};
    }

    const citizenChannelId = settings.citizen_channel_id;
    const content = message.content ? message.content.trim() : '';

    const isCitizenChannel = citizenChannelId && message.channel.id === citizenChannelId;
    const hasBanWord = /(منع|فحص|استعلام|check|ban)/i.test(content);
    const mentionedUser = message.mentions?.users?.first ? message.mentions.users.first() : null;
    const idMatch = content.match(/\b(\d{17,20})\b/);

    // Trigger check if message contains ban keywords OR is in citizen channel with mention/ID/check
    if (hasBanWord || (isCitizenChannel && (mentionedUser || idMatch || content === 'منع' || content === 'فحص' || content === 'استعلام'))) {
      if (mentionedUser) {
        // Checking for mentioned member
        await handleBanCheck(message, mentionedUser.id, mentionedUser, mentionedUser.id === message.author.id);
        return;
      } else if (idMatch) {
        // Checking by Discord ID
        const targetUserId = idMatch[1];
        let targetUser = null;
        try {
          targetUser = await message.client.users.fetch(targetUserId).catch(() => null);
        } catch {}
        await handleBanCheck(message, targetUserId, targetUser, targetUserId === message.author.id);
        return;
      } else {
        // Checking self
        await handleBanCheck(message, message.author.id, message.author, true);
        return;
      }
    }

    // If message is in citizen channel and is NOT a valid check command, auto-delete to keep it clean
    if (citizenChannelId && message.channel.id === citizenChannelId) {
      try {
        await message.delete();
        const warning = await message.channel.send({
          content: `⚠️ <@${message.author.id}> هذا الروم مخصص فقط للاستعلام عن منع التوظيف.\n**الأوامر المتاحة:**\n• \`منع\` (لفحص المنع عن نفسك)\n• \`منع @منشن\` (لفحص مدة المنع لعضو آخر)`
        }).catch(() => null);

        if (warning) {
          setTimeout(() => warning.delete().catch(() => {}), 5000);
        }
      } catch (err) {
        logger.warn(`تعذر حذف الرسالة غير المصرح بها في روم المواطنين: ${err.message}`);
      }
    }
  }
};
