const BanRepository = require('../../database/repositories/banRepository');
const SettingsRepository = require('../../database/repositories/settingsRepository');
const AuditLogRepository = require('../../database/repositories/auditLogRepository');
const logger = require('../../utils/logger');
const { EmbedBuilder } = require('discord.js');

// Cache to prevent duplicate triggers / loops when the bot restores the role
const restoringMembers = new Set();

module.exports = {
  name: 'guildMemberUpdate',
  once: false,
  async execute(oldMember, newMember) {
    if (!newMember || !newMember.guild) return;

    try {
      const guild = newMember.guild;
      const settings = SettingsRepository.getSettings(guild.id);
      const banRoleId = settings.ban_role_id;
      if (!banRoleId) return;

      const hadRole = oldMember.roles.cache.has(banRoleId);
      const hasRole = newMember.roles.cache.has(banRoleId);

      // Only act if the ban role was removed from the member
      if (hadRole && !hasRole) {
        const memberId = newMember.id;

        // Skip if currently being restored by the bot
        if (restoringMembers.has(memberId)) return;

        // Check if there is an active ban in the database
        const activeBan = BanRepository.getActiveBan(guild.id, memberId);
        if (activeBan) {
          logger.warn(`[Anti-Tamper] محاولة سحب رتبة منع التوظيف يدوياً عن العضو ${newMember.user.tag} (${memberId}) بينما المنع ما زال نشطاً في النظام! جاري إعادة الرتبة فورياً...`);

          restoringMembers.add(memberId);
          setTimeout(() => restoringMembers.delete(memberId), 10000).unref();

          try {
            await newMember.roles.add(banRoleId, 'إعادة تلقائية فورية: منع التوظيف نشط في النظام ومحمي من السحب اليدوي');
            logger.info(`[Anti-Tamper] تمت إعادة رتبة منع التوظيف بنجاح للعضو ${newMember.user.tag}`);

            // 1. Audit Log record
            AuditLogRepository.createLog({
              guildId: guild.id,
              action: 'ROLE_TAMPER_PREVENTED',
              targetUserId: memberId,
              targetUserTag: newMember.user.tag,
              moderatorId: 'SYSTEM',
              moderatorTag: 'نظام الحماية التلقائي',
              details: {
                banId: activeBan.id,
                reason: 'تم إحباط محاولة سحب الرتبة يدوياً وإعادتها فورياً'
              }
            });

            // 2. Alert notification to log channel
            if (settings.log_channel_id) {
              const logChannel = guild.channels.cache.get(settings.log_channel_id) || await guild.channels.fetch(settings.log_channel_id).catch(() => null);
              if (logChannel && logChannel.isTextBased()) {
                const embed = new EmbedBuilder()
                  .setColor('#ef4444')
                  .setTitle('🛡️ نظام الحماية: إحباط محاولة سحب رتبة يدوياً')
                  .setDescription(`حاول أحد الإداريين سحب رتبة منع التوظيف يدوياً عن العضو <@${memberId}> (${newMember.user.tag}) من خارج النظام.`)
                  .addFields(
                    { name: '👤 العضو المعني', value: `<@${memberId}>`, inline: true },
                    { name: '📋 حالة المنع', value: '🔴 **نشط ومسجل في قاعدة البيانات**', inline: true },
                    { name: '⚡ إجراء النظام', value: '✅ **تمت إعادة الرتبة للعضو فورياً وبشكل تلقائي ومحكم**', inline: false }
                  )
                  .setFooter({ text: 'بـوت مـنـع الـتـوظـيـف • الحماية من التلاعب اليدوي' })
                  .setTimestamp();

                await logChannel.send({ embeds: [embed] }).catch(() => {});
              }
            }
          } catch (roleErr) {
            logger.error(`[Anti-Tamper] تعذر إعادة الرتبة للعضو ${memberId}: ${roleErr.message}`);
          }
        }
      }
    } catch (err) {
      logger.error('خطأ في معالج guildMemberUpdate:', err.message);
    }
  }
};
