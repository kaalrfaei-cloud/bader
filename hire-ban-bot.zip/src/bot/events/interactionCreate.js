const logger = require('../../utils/logger');

module.exports = {
  name: 'interactionCreate',
  once: false,
  async execute(interaction) {
    if (!interaction.isChatInputCommand()) return;

    const command = interaction.client.commands.get(interaction.commandName);
    if (!command) {
      logger.warn(`لم يتم العثور على معالج للأمر: ${interaction.commandName}`);
      return;
    }

    try {
      await command.execute(interaction);
    } catch (error) {
      logger.error(`خطأ أثناء تنفيذ الأمر ${interaction.commandName}:`, error.message);

      const errorMessage = {
        content: `❌ حدث خطأ غير متوقع أثناء تنفيذ الأمر: ${error.message}`,
        ephemeral: true
      };

      if (interaction.replied || interaction.deferred) {
        await interaction.followUp(errorMessage).catch(() => {});
      } else {
        await interaction.reply(errorMessage).catch(() => {});
      }
    }
  }
};
