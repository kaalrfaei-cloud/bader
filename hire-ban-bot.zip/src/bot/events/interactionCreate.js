const logger = require('../../utils/logger');
const SettingsRepository = require('../../database/repositories/settingsRepository');

module.exports = {
  name: 'interactionCreate',
  once: false,
  async execute(interaction) {
    // Handle Button Interactions
    if (interaction.isButton()) {
      const customId = interaction.customId || '';
      // If button is an expired confirmation button
      if (customId.startsWith('confirm_hire_ban_') || customId.startsWith('cancel_hire_ban_')) {
        if (!interaction.replied && !interaction.deferred) {
          await interaction.reply({
            content: '⚠️ انتهت مهلة هذا الزر. يرجى إعادة استخدام الأمر من جديد.',
            ephemeral: true
          }).catch(() => {});
        }
      }
      return;
    }

    if (!interaction.isChatInputCommand()) return;

    // Check channel restrictions for admin moderation commands
    if (interaction.guild) {
      const settings = SettingsRepository.getSettings(interaction.guild.id);
      const adminChannelId = settings.admin_channel_id;
      // Unified admin command names
      const adminCommands = ['منع', 'رفع-المنع', 'الغاء-منع', 'الغاء-المنع', 'إعدادات', 'اعدادات', 'قائمة-الممنوعين', 'الممنوعين'];

      if (adminChannelId && adminCommands.includes(interaction.commandName) && interaction.channelId !== adminChannelId) {
        const channelExists = interaction.guild.channels?.cache ? interaction.guild.channels.cache.has(adminChannelId) : true;
        if (channelExists) {
          return interaction.reply({
            content: `❌ أوامر إدارة منع التوظيف مخصصة فقط لروم الإدارة المعتمد: <#${adminChannelId}>`,
            ephemeral: true
          });
        }
      }
    }

    const command = interaction.client.commands.get(interaction.commandName);
    if (!command) {
      logger.warn(`لم يتم العثور على معالج للأمر: ${interaction.commandName}`);
      return;
    }

    try {
      await command.execute(interaction);
    } catch (error) {
      logger.error(`[Security Logs] خطأ أثناء تنفيذ الأمر ${interaction.commandName} بواسطة ${interaction.user?.tag || interaction.user?.id}:`, error.stack || error);

      const errorMessage = {
        content: '❌ حدث خطأ أثناء تنفيذ العملية، يرجى التواصل مع الإدارة.',
        ephemeral: true
      };

      if (interaction.replied || interaction.deferred) {
        await interaction.followUp(errorMessage).catch(() => {});
      } else {
        await interaction.reply(errorMessage).catch(() => {});
      }
    }
  }
};
