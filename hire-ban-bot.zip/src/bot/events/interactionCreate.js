const logger = require('../../utils/logger');
const SettingsRepository = require('../../database/repositories/settingsRepository');

module.exports = {
  name: 'interactionCreate',
  once: false,
  async execute(interaction) {
    if (!interaction.isChatInputCommand()) return;

    // Check channel restrictions for admin moderation commands
    if (interaction.guild) {
      const settings = SettingsRepository.getSettings(interaction.guild.id);
      const adminChannelId = settings.admin_channel_id;
      const adminCommands = ['منع', 'الغاء-منع', 'الغاء-المنع', 'إعدادات', 'اعدادات', 'قائمة-الممنوعين'];

      if (adminChannelId && adminCommands.includes(interaction.commandName) && interaction.channelId !== adminChannelId) {
        return interaction.reply({
          content: `❌ أوامر إدارة منع التوظيف مخصصة فقط لروم الإدارة المعتمد: <#${adminChannelId}>`,
          ephemeral: true
        });
      }
    }

    const command = interaction.client.commands.get(interaction.commandName);
    if (!command) {
      logger.warn(`لم يتم العثور على معالج للأمر: ${interaction.commandName}`);
      return;
    }

    try {
      await command.execute(interaction);
    } catch (error) {
      logger.error(`خطأ أثناء تنفيذ الأمر ${interaction.commandName}:`, error.message);

      const errorMessage = {
        content: `❌ حدث خطأ غير متوقع أثناء تنفيذ الأمر: ${error.message}`,
        ephemeral: true
      };

      if (interaction.replied || interaction.deferred) {
        await interaction.followUp(errorMessage).catch(() => {});
      } else {
        await interaction.reply(errorMessage).catch(() => {});
      }
    }
  }
};
