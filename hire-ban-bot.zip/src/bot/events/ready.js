const { ActivityType } = require('discord.js');
const logger = require('../../utils/logger');
const SchedulerService = require('../../services/schedulerService');

module.exports = {
  name: 'ready',
  once: true,
  async execute(client) {
    logger.success(`تم تسجيل دخول البوت بنجاح باسم: ${client.user.tag} (ID: ${client.user.id})`);
    logger.info(`متصل حالياً في ${client.guilds.cache.size} سيرفر.`);

    // Set bot presence
    client.user.setPresence({
      activities: [{ name: 'إدارة منع التوظيف | /مساعدة', type: ActivityType.Watching }],
      status: 'online'
    });

    // Initialize and start scheduler for expiration checks (Optimized 60s cycle for ultra-low CPU)
    if (!client.scheduler) {
      client.scheduler = new SchedulerService(client, 60000);
      client.scheduler.start();
    }

    // Automatically register/sync Slash Commands globally without manual steps
    if (client.application && client.commands.size > 0) {
      try {
        const commands = Array.from(client.commands.values()).map(c => c.data.toJSON());
        await client.application.commands.set(commands);
        logger.success(`تم تسجيل وتفعيل كافة أوامر الـ Slash Commands (${commands.length} أمر) تلقائياً بنجاح.`);
      } catch (cmdErr) {
        logger.warn(`تعذر التسجيل التلقائي للأوامر: ${cmdErr.message}`);
      }
    }
  }
};
