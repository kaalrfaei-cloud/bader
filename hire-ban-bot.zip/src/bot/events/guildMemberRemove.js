const BanRepository = require('../../database/repositories/banRepository');
const AuditLogRepository = require('../../database/repositories/auditLogRepository');
const logger = require('../../utils/logger');

module.exports = {
  name: 'guildMemberRemove',
  once: false,
  async execute(member) {
    try {
      const activeBan = BanRepository.getActiveBan(member.guild.id, member.id);
      if (activeBan) {
        logger.info(`العضو الممنوع ${member.user?.tag || member.id} غادر السيرفر ${member.guild.name}. المنع محفوظ في قاعدة البيانات.`);
        AuditLogRepository.createLog({
          guildId: member.guild.id,
          action: 'MEMBER_LEAVE_WHILE_BANNED',
          targetUserId: member.id,
          targetUserTag: member.user?.tag || member.user?.username || 'مستخدم خارج السيرفر',
          moderatorId: 'SYSTEM',
          moderatorTag: 'نظام المراقبة',
          details: {
            banId: activeBan.id,
            expiresAt: activeBan.expires_at,
            note: 'غادر العضو السيرفر ولديه منع توظيف نشط'
          }
        });
      }
    } catch (err) {
      logger.error(`خطأ أثناء معالجة مغادرة العضو ${member.id}:`, err.message);
    }
  }
};
