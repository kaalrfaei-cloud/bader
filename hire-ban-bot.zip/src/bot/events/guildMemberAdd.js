const BanService = require('../../services/banService');
const logger = require('../../utils/logger');

module.exports = {
  name: 'guildMemberAdd',
  once: false,
  async execute(member) {
    try {
      await BanService.handleRejoiningMember(member);
    } catch (err) {
      logger.error(`خطأ أثناء معالجة انضمام العضو ${member.id}:`, err.message);
    }
  }
};
