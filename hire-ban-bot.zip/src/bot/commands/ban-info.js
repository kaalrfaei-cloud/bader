const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const PermissionsGuard = require('../../security/permissions');
const BanRepository = require('../../database/repositories/banRepository');
const { formatDuration, formatDiscordTimestamp } = require('../../utils/timeParser');
const { THEME } = require('../../utils/embedBuilder');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('معلومات-منع')
    .setDescription('عرض تفاصيل وحالة منع التوظيف لعضو معين')
    .addUserOption(option =>
      option
        .setName('العضو')
        .setDescription('العضو المراد فحص سجله')
        .setRequired(true)
    ),

  async execute(interaction) {
    const guild = interaction.guild;
    const targetUser = interaction.options.getUser('العضو');

    const activeBan = BanRepository.getActiveBan(guild.id, targetUser.id);

    if (!activeBan) {
      // Check last ban in history
      const { bans } = BanRepository.listBans({
        guildId: guild.id,
        search: targetUser.id,
        limit: 1
      });

      if (!bans || bans.length === 0) {
        return interaction.reply({
          content: `ℹ️ لا يوجد أي سجل منع توظيف مسجل للعضو <@${targetUser.id}> في هذا السيرفر.`,
          ephemeral: true
        });
      }

      const lastBan = bans[0];
      const statusText = lastBan.status === 'EXPIRED' ? 'منتهي الصلاحية' : (lastBan.status === 'REVOKED' ? 'تم إلغاؤه يدوياً' : lastBan.status);

      const embed = new EmbedBuilder()
        .setColor(THEME.DARK)
        .setTitle(`ℹ️ تفاصيل آخر منع توظيف - ${targetUser.username}`)
        .addFields(
          { name: '👤 العضو', value: `<@${targetUser.id}>`, inline: true },
          { name: '🆔 رقم المنع', value: `#${lastBan.id}`, inline: true },
          { name: '📌 الحالة الحالية', value: `⚪ ${statusText}`, inline: true },
          { name: '⏱️ المدة السابقة', value: lastBan.duration_seconds ? formatDuration(lastBan.duration_seconds) : 'دائم', inline: true },
          { name: '📅 تاريخ البداية', value: formatDiscordTimestamp(lastBan.created_at), inline: true },
          { name: '👮 الإداري المنفذ', value: `<@${lastBan.moderator_id}>`, inline: true },
          { name: '📝 السبب', value: lastBan.reason || 'لا يوجد', inline: false }
        )
        .setFooter({ text: 'العضو ليس عليه منع توظيف نشط حالياً' })
        .setTimestamp();

      return interaction.reply({ embeds: [embed], ephemeral: true });
    }

    // Active ban found!
    const durationText = activeBan.duration_seconds ? formatDuration(activeBan.duration_seconds) : 'منع دائم';
    const expiresText = activeBan.expires_at ? formatDiscordTimestamp(activeBan.expires_at) : 'لا ينتهي (منع دائم)';

    let remainingText = 'دائم';
    if (activeBan.expires_at) {
      const remainingSec = Math.max(0, Math.floor((new Date(activeBan.expires_at).getTime() - Date.now()) / 1000));
      remainingText = formatDuration(remainingSec);
    }

    const embed = new EmbedBuilder()
      .setColor(THEME.PRIMARY)
      .setTitle(`🚫 منع توظيف نشط - ${targetUser.username}`)
      .setThumbnail(targetUser.displayAvatarURL({ dynamic: true }))
      .addFields(
        { name: '👤 العضو', value: `<@${targetUser.id}>`, inline: true },
        { name: '🆔 رقم المنع', value: `#${activeBan.id}`, inline: true },
        { name: '🔴 الحالة', value: 'نشط وفعال', inline: true },
        { name: '⏱️ المدة الإجمالية', value: durationText, inline: true },
        { name: '⏳ المتبقي على الانتهاء', value: remainingText, inline: true },
        { name: '📅 ينتهي في', value: expiresText, inline: false },
        { name: '👮 الإداري الذي أصدر المنع', value: `<@${activeBan.moderator_id}>`, inline: true },
        { name: '📅 تاريخ الإصدار', value: formatDiscordTimestamp(activeBan.created_at), inline: true },
        { name: '📝 سبب المنع', value: activeBan.reason || 'لا يوجد سبب محدد', inline: false }
      )
      .setFooter({ text: 'نظام منع التوظيف • Hire Ban Bot' })
      .setTimestamp();

    return interaction.reply({ embeds: [embed], ephemeral: true });
  }
};
