const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const PermissionsGuard = require('../../security/permissions');
const SettingsRepository = require('../../database/repositories/settingsRepository');
const BanRepository = require('../../database/repositories/banRepository');
const { formatDuration, formatDiscordTimestamp } = require('../../utils/timeParser');
const { THEME } = require('../../utils/embedBuilder');
const logger = require('../../utils/logger');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('معلومات-منع')
    .setDescription('عرض تفاصيل وحالة منع التوظيف')
    .addUserOption(option =>
      option
        .setName('العضو')
        .setDescription('العضو المراد الاستعلام عن حالته (اتركه فارغاً للاستعلام عن نفسك)')
        .setRequired(false)
    ),

  async execute(interaction) {
    try {
      const guild = interaction.guild;
      const member = interaction.member;
      const settings = SettingsRepository.getSettings(guild.id);

      // Default to self if target user is not specified
      const targetUser = interaction.options.getUser('العضو') || interaction.user;
      const isSelfCheck = targetUser.id === interaction.user.id;

      // If querying another member, enforce Permission Guard
      const isAdminOrMod = PermissionsGuard.canViewAdminBanDetails(member, settings);
      if (!isSelfCheck && !isAdminOrMod) {
        return interaction.reply({
          content: '❌ ليس لديك الصلاحية للاستعلام عن السجل الإداري للأعضاء الآخرين (مخصص للإدارة فقط).',
          ephemeral: true
        });
      }

      let activeBan = BanRepository.getActiveBan(guild.id, targetUser.id);

      // Check Discord member role state
      let targetMember = guild.members?.cache?.get(targetUser.id);
      if (!targetMember && guild.members?.fetch) {
        targetMember = await guild.members.fetch(targetUser.id).catch(() => null);
      }
      const banRoleId = settings.ban_role_id;
      const hasBanRole = Boolean(banRoleId && targetMember?.roles?.cache && (
        targetMember.roles.cache.has ? targetMember.roles.cache.has(banRoleId) : false
      ));

      // Auto-heal if member has role in Discord but DB missing record
      if (!activeBan && hasBanRole) {
        try {
          BanRepository.createBan({
            guild_id: guild.id,
            user_id: targetUser.id,
            user_tag: targetUser.tag || targetUser.username,
            reason: 'رتبة منع التوظيف نشطة على العضو في ديسكورد',
            moderator_id: 'DISCORD',
            moderator_tag: 'رتبة ديسكورد',
            duration_seconds: null,
            created_at: new Date().toISOString(),
            expires_at: null,
            status: 'ACTIVE'
          });
          activeBan = BanRepository.getActiveBan(guild.id, targetUser.id);
        } catch {}
      }

      // CASE 1: No active ban and no role
      if (!activeBan && !hasBanRole) {
        if (isSelfCheck) {
          return interaction.reply({
            content: '✅ لا يوجد عليك أي منع توظيف نشط حالياً في هذا السيرفر.',
            ephemeral: true
          });
        }

        // For admin querying someone else: check history
        const { bans } = BanRepository.listBans({
          guildId: guild.id,
          search: targetUser.id,
          limit: 1
        });

        if (!bans || bans.length === 0) {
          return interaction.reply({
            content: `ℹ️ لا يوجد أي سجل منع توظيف مسجل للعضو <@${targetUser.id}> في هذا السيرفر.`,
            ephemeral: true
          });
        }

        const lastBan = bans[0];
        const statusText = lastBan.status === 'EXPIRED' ? 'منتهي الصلاحية' : (lastBan.status === 'REVOKED' ? 'تم إلغاؤه يدوياً' : lastBan.status);

        const embed = new EmbedBuilder()
          .setColor(THEME.DARK)
          .setTitle(`ℹ️ تفاصيل آخر منع توظيف - ${targetUser.username}`)
          .addFields(
            { name: '👤 العضو', value: `<@${targetUser.id}>`, inline: true },
            { name: '🆔 رقم المنع', value: `#${lastBan.id}`, inline: true },
            { name: '📌 الحالة الحالية', value: `⚪ ${statusText}`, inline: true },
            { name: '⏱️ المدة السابقة', value: lastBan.duration_seconds ? formatDuration(lastBan.duration_seconds) : 'دائم', inline: true },
            { name: '📅 تاريخ البداية', value: formatDiscordTimestamp(lastBan.created_at), inline: true },
            { name: '👮 الإداري المنفذ', value: `<@${lastBan.moderator_id}>`, inline: true },
            { name: '📝 السبب', value: lastBan.reason || 'لا يوجد', inline: false }
          )
          .setFooter({ text: 'العضو ليس عليه منع توظيف نشط حالياً' })
          .setTimestamp();

        return interaction.reply({ embeds: [embed], ephemeral: true });
      }

      // CASE 2: Active ban exists!
      const durationText = activeBan.duration_seconds ? formatDuration(activeBan.duration_seconds) : 'منع دائم';
      const expiresText = activeBan.expires_at ? formatDiscordTimestamp(activeBan.expires_at) : 'لا ينتهي (منع دائم)';

      let remainingText = 'دائم';
      if (activeBan.expires_at) {
        const remainingSec = Math.max(0, Math.floor((new Date(activeBan.expires_at).getTime() - Date.now()) / 1000));
        const unixTimestamp = Math.floor(new Date(activeBan.expires_at).getTime() / 1000);
        remainingText = `${formatDuration(remainingSec)} • <t:${unixTimestamp}:R>`;
      }

      // Citizen view: Clean status without administrative metadata
      if (isSelfCheck && !isAdminOrMod) {
        const citizenEmbed = new EmbedBuilder()
          .setColor(THEME.DANGER)
          .setTitle('⚠️ حالة منع التوظيف الخاصة بك')
          .setDescription('يوجد عليك حالياً منع توظيف نشط وفعال في هذا السيرفر.')
          .addFields(
            { name: '⏱️ مدة المنع', value: durationText, inline: true },
            { name: '⏳ المتبقي على الانتهاء', value: remainingText, inline: true },
            { name: '📅 تاريخ وتوقيت الانتهاء', value: expiresText, inline: false },
            { name: '📝 سبب المنع', value: activeBan.reason || 'مخالفة اللوائح والشروط', inline: false }
          )
          .setFooter({ text: 'لأي استفسار أو اعتراض، يرجى مراجعة إدارة السيرفر' })
          .setTimestamp();

        return interaction.reply({ embeds: [citizenEmbed], ephemeral: true });
      }

      // Full Administrative view
      const adminEmbed = new EmbedBuilder()
        .setColor(THEME.PRIMARY)
        .setTitle(`🚫 منع توظيف نشط - ${targetUser.username}`)
        .setThumbnail(targetUser.displayAvatarURL({ dynamic: true }))
        .addFields(
          { name: '👤 العضو', value: `<@${targetUser.id}>`, inline: true },
          { name: '🆔 رقم المنع', value: `#${activeBan.id}`, inline: true },
          { name: '🔴 الحالة', value: 'نشط وفعال (ACTIVE)', inline: true },
          { name: '⏱️ المدة الإجمالية', value: durationText, inline: true },
          { name: '⏳ المتبقي على الانتهاء', value: remainingText, inline: true },
          { name: '📅 ينتهي في', value: expiresText, inline: false },
          { name: '👮 الإداري الذي أصدر المنع', value: `<@${activeBan.moderator_id}> (\`${activeBan.moderator_tag}\`)`, inline: true },
          { name: '📅 تاريخ الإصدار', value: formatDiscordTimestamp(activeBan.created_at), inline: true },
          { name: '📝 سبب المنع', value: activeBan.reason || 'لا يوجد سبب محدد', inline: false }
        )
        .setFooter({ text: 'نظام منع التوظيف الإداري • Hire Ban Bot' })
        .setTimestamp();

      return interaction.reply({ embeds: [adminEmbed], ephemeral: true });
    } catch (err) {
      logger.error(`[Security Logs] خطأ في أمر /معلومات-منع بواسطة ${interaction.user.tag}:`, err.stack || err);
      const replyFn = (interaction.replied || interaction.deferred) ? 'followUp' : 'reply';
      return Promise.resolve(interaction[replyFn]({
        content: '❌ حدث خطأ أثناء تنفيذ العملية، يرجى التواصل مع الإدارة.',
        ephemeral: true
      })).catch(() => {});
    }
  }
};
