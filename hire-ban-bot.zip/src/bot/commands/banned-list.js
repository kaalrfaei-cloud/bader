const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const PermissionsGuard = require('../../security/permissions');
const BanRepository = require('../../database/repositories/banRepository');
const { formatDiscordTimestamp } = require('../../utils/timeParser');
const { THEME } = require('../../utils/embedBuilder');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('الممنوعين')
    .setDescription('عرض قائمة الأعضاء الممنوعين حالياً من التوظيف')
    .addIntegerOption(option =>
      option
        .setName('الصفحة')
        .setDescription('رقم الصفحة المراد عرضها')
        .setMinValue(1)
        .setRequired(false)
    ),

  async execute(interaction) {
    const guild = interaction.guild;
    const page = interaction.options.getInteger('الصفحة') || 1;
    const limit = 8;
    const offset = (page - 1) * limit;

    const { bans, total } = BanRepository.listBans({
      guildId: guild.id,
      status: 'ACTIVE',
      limit,
      offset
    });

    const totalPages = Math.ceil(total / limit) || 1;

    if (total === 0) {
      return interaction.reply({
        content: '✅ لا يوجد أي عضو ممنوع من التوظيف حالياً في هذا السيرفر.',
        ephemeral: true
      });
    }

    const embed = new EmbedBuilder()
      .setColor(THEME.PRIMARY)
      .setTitle(`🚫 قائمة الممنوعين من التوظيف (إجمالي: ${total})`)
      .setDescription(`عرض الصفحة **${page}** من **${totalPages}**`)
      .setFooter({ text: 'لإدارة كاملة، يرجى زيارة لوحة التحكم (Dashboard)' })
      .setTimestamp();

    for (const b of bans) {
      const expires = b.expires_at ? formatDiscordTimestamp(b.expires_at) : 'منع دائم';
      embed.addFields({
        name: `👤 ${b.user_tag} [#${b.id}]`,
        value: `• **المعرف:** \`${b.user_id}\`\n• **الإداري:** <@${b.moderator_id}>\n• **ينتهي:** ${expires}\n• **السبب:** ${b.reason || 'غير محدد'}`,
        inline: false
      });
    }

    return interaction.reply({ embeds: [embed], ephemeral: true });
  }
};
