const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { THEME } = require('../../utils/embedBuilder');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('مساعدة')
    .setDescription('دليل أوامر وشرح نظام بوت منع التوظيف'),

  async execute(interaction) {
    const dashboardUrl = process.env.DASHBOARD_URL || `http://localhost:${process.env.PORT || 3000}`;

    const embed = new EmbedBuilder()
      .setColor(THEME.PRIMARY)
      .setTitle('📚 دليل أوامر بوت منع التوظيف (Hire Ban Bot)')
      .setDescription(`نظام احترافي لإدارة ومنع التوظيف داخل سيرفرات الديسكورد مع لوحة تحكم مخصصة.`)
      .addFields(
        {
          name: '🚫 `/منع`',
          value: 'إصدار منع توظيف لعضو محدد مع تحديد المدة (ساعات/أيام/دائم) والسبب، وتأكيد بالزر قبل التنفيذ.'
        },
        {
          name: '🔓 `/الغاء-منع`',
          value: 'إلغاء عقوبة منع التوظيف عن عضو وإزالة الرول فوراً من قبل الإدارة العليا.'
        },
        {
          name: 'ℹ️ `/معلومات-منع`',
          value: 'الاستعلام عن تفاصيل منع عضو، الوقت المتبقي، الإداري المنفذ، وتاريخ الانتهاء.'
        },
        {
          name: '📋 `/الممنوعين`',
          value: 'عرض قائمة بجميع الأعضاء الذين لديهم منع توظيف نشط بالسيرفر.'
        },
        {
          name: '⚙️ `/إعدادات`',
          value: 'عرض إعدادات السيرفر الحالية، الرومات المعينة، ورتب الصلاحيات.'
        },
        {
          name: '🌐 لوحة التحكم (Dashboard)',
          value: `يمكنك الدخول إلى لوحة التحكم عبر الرابط:\n[${dashboardUrl}](${dashboardUrl})\nلتحديد الرومات، الرتب، مشاهدة السجلات، وتصدير البيانات.`
        }
      )
      .setFooter({ text: 'نظام حماية التوظيف المتكامل' })
      .setTimestamp();

    return interaction.reply({ embeds: [embed], ephemeral: true });
  }
};
