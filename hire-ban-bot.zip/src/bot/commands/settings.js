const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const SettingsRepository = require('../../database/repositories/settingsRepository');
const PermissionsGuard = require('../../security/permissions');
const { THEME } = require('../../utils/embedBuilder');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('إعدادات')
    .setDescription('عرض إعدادات نظام منع التوظيف الحالية للسيرفر'),

  async execute(interaction) {
    const guild = interaction.guild;
    const member = interaction.member;

    const settings = SettingsRepository.getSettings(guild.id);
    if (!PermissionsGuard.canManageSettings(member, settings)) {
      return interaction.reply({
        content: '❌ هذا الأمر مخصص لإدارة السيرفر فقط.',
        ephemeral: true
      });
    }

    const banRole = settings.ban_role_id ? `<@&${settings.ban_role_id}>` : '❌ غير محددة';
    const adminChannel = settings.admin_channel_id ? `<#${settings.admin_channel_id}>` : '❌ غير محدد';
    const citizenChannel = settings.citizen_channel_id ? `<#${settings.citizen_channel_id}>` : '❌ غير محدد';
    const logChannel = settings.log_channel_id ? `<#${settings.log_channel_id}>` : '❌ غير محدد';

    const allowedRoles = (settings.allowed_roles || []).length > 0
      ? settings.allowed_roles.map(r => `<@&${r}>`).join(', ')
      : 'صلاحيات الإدارة الافتراضية';

    const cancelRoles = (settings.cancel_roles || []).length > 0
      ? settings.cancel_roles.map(r => `<@&${r}>`).join(', ')
      : 'الإدارة العليا فقط';

    const dashboardUrl = process.env.DASHBOARD_URL || `http://localhost:${process.env.PORT || 3000}`;

    const embed = new EmbedBuilder()
      .setColor(THEME.DARK)
      .setTitle(`⚙️ إعدادات نظام منع التوظيف - ${guild.name}`)
      .setDescription(`يمكنك تعديل وتحديث كافة الإعدادات والرومات بسهولة عبر [لوحة التحكم (${dashboardUrl})](${dashboardUrl}).`)
      .addFields(
        { name: '🎭 رتبة منع التوظيف', value: banRole, inline: true },
        { name: '🔒 المنع الدائم', value: settings.allow_permanent_bans ? '✅ مفعّل' : '❌ معطّل', inline: true },
        { name: '\u200B', value: '\u200B', inline: true },
        { name: '📢 روم المواطنين', value: citizenChannel, inline: true },
        { name: '📜 روم السجلات', value: logChannel, inline: true },
        { name: '🛡️ روم الإدارة', value: adminChannel, inline: true },
        { name: '👮 رتب إعطاء المنع', value: allowedRoles, inline: false },
        { name: '👑 رتب إلغاء وإدارة المنع', value: cancelRoles, inline: false }
      )
      .setFooter({ text: 'Hire Ban Bot Settings' })
      .setTimestamp();

    return interaction.reply({ embeds: [embed], ephemeral: true });
  }
};
