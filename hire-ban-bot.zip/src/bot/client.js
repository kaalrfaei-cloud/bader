const { Client, GatewayIntentBits, Collection } = require('discord.js');
const fs = require('fs');
const path = require('path');
const logger = require('../utils/logger');

function createDiscordClient() {
  const client = new Client({
    intents: [
      GatewayIntentBits.Guilds,
      GatewayIntentBits.GuildMembers,
      GatewayIntentBits.GuildMessages,
      GatewayIntentBits.MessageContent
    ],
    // Ultra-light RAM consumption with auto-sweeping
    sweepers: {
      messages: {
        interval: 300, // Sweep every 5 minutes
        lifetime: 60   // Discard messages older than 1 minute
      }
    }
  });

  client.commands = new Collection();

  // Load commands
  const commandsPath = path.join(__dirname, 'commands');
  if (fs.existsSync(commandsPath)) {
    const commandFiles = fs.readdirSync(commandsPath).filter(file => file.endsWith('.js'));
    for (const file of commandFiles) {
      const filePath = path.join(commandsPath, file);
      const command = require(filePath);
      if (command.data && command.execute) {
        client.commands.set(command.data.name, command);
      } else {
        logger.warn(`الأمر في الملف ${file} ينقصه data أو execute.`);
      }
    }
  }

  // Load events
  const eventsPath = path.join(__dirname, 'events');
  if (fs.existsSync(eventsPath)) {
    const eventFiles = fs.readdirSync(eventsPath).filter(file => file.endsWith('.js'));
    for (const file of eventFiles) {
      const filePath = path.join(eventsPath, file);
      const event = require(filePath);
      if (event.once) {
        client.once(event.name, (...args) => event.execute(...args));
      } else {
        client.on(event.name, (...args) => event.execute(...args));
      }
    }
  }

  // Rate limit event handler
  client.rest.on('rateLimited', (info) => {
    logger.warn(`تجاوز معدل طلبات ديسكورد (Rate Limit): المهلة ${info.timeToReset}ms على المسار ${info.route}`);
  });

  client.on('error', (error) => {
    logger.error('خطأ في عميل Discord Client:', error.message);
  });

  return client;
}

module.exports = { createDiscordClient };
