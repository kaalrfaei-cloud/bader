const { getDb } = require('../db');

class AuditLogRepository {
  /**
   * Insert a new audit log record
   */
  static createLog({ guildId, action, targetUserId = null, targetUserTag = null, moderatorId = null, moderatorTag = null, details = {} }) {
    const db = getDb();
    const now = new Date().toISOString();
    const detailsJson = typeof details === 'string' ? details : JSON.stringify(details || {});

    const stmt = db.prepare(`
      INSERT INTO audit_logs (
        guild_id, action, target_user_id, target_user_tag,
        moderator_id, moderator_tag, details, created_at
      ) VALUES (
        ?, ?, ?, ?, ?, ?, ?, ?
      )
    `);

    const result = stmt.run(
      guildId,
      action,
      targetUserId,
      targetUserTag,
      moderatorId,
      moderatorTag,
      detailsJson,
      now
    );

    return {
      id: result.lastInsertRowid,
      guild_id: guildId,
      action,
      target_user_id: targetUserId,
      target_user_tag: targetUserTag,
      moderator_id: moderatorId,
      moderator_tag: moderatorTag,
      details: detailsJson,
      created_at: now
    };
  }

  /**
   * Paginated listing of audit logs with search and date filters
   */
  static listLogs({ guildId, action = null, search = '', fromDate = null, toDate = null, limit = 50, offset = 0 }) {
    const db = getDb();
    const conditions = ['guild_id = ?'];
    const params = [guildId];

    if (action && action !== 'ALL') {
      conditions.push('action = ?');
      params.push(action);
    }

    if (fromDate) {
      conditions.push('created_at >= ?');
      params.push(fromDate);
    }

    if (toDate) {
      conditions.push('created_at <= ?');
      params.push(toDate);
    }

    if (search && search.trim() !== '') {
      const q = `%${search.trim()}%`;
      conditions.push('(target_user_tag LIKE ? OR target_user_id LIKE ? OR moderator_tag LIKE ? OR moderator_id LIKE ? OR details LIKE ?)');
      params.push(q, q, q, q, q);
    }

    const whereClause = conditions.join(' AND ');

    const countStmt = db.prepare(`SELECT COUNT(*) as total FROM audit_logs WHERE ${whereClause}`);
    const totalRow = countStmt.get(...params);
    const total = totalRow ? totalRow.total : 0;

    const listStmt = db.prepare(`
      SELECT * FROM audit_logs
      WHERE ${whereClause}
      ORDER BY id DESC
      LIMIT ? OFFSET ?
    `);

    const rows = listStmt.all(...params, limit, offset);

    const logs = rows.map(r => {
      let parsedDetails = {};
      try {
        parsedDetails = JSON.parse(r.details || '{}');
      } catch {
        parsedDetails = { raw: r.details };
      }
      return { ...r, details: parsedDetails };
    });

    return { logs, total, limit, offset };
  }

  /**
   * Generate CSV format string of all audit logs for a guild
   */
  static exportLogsCsv(guildId) {
    const db = getDb();
    const stmt = db.prepare(`
      SELECT id, action, target_user_id, target_user_tag, moderator_id, moderator_tag, details, created_at
      FROM audit_logs
      WHERE guild_id = ?
      ORDER BY id DESC
    `);
    const rows = stmt.all(guildId);

    // CSV header
    const headers = ['ID', 'Action', 'Target_User_ID', 'Target_User_Tag', 'Moderator_ID', 'Moderator_Tag', 'Details', 'Created_At'];
    const escapeCsv = (str) => {
      if (str === null || str === undefined) return '""';
      const s = String(str).replace(/"/g, '""');
      return `"${s}"`;
    };

    const lines = [headers.join(',')];
    for (const r of rows) {
      lines.push([
        r.id,
        escapeCsv(r.action),
        escapeCsv(r.target_user_id),
        escapeCsv(r.target_user_tag),
        escapeCsv(r.moderator_id),
        escapeCsv(r.moderator_tag),
        escapeCsv(r.details),
        escapeCsv(r.created_at)
      ].join(','));
    }

    return lines.join('\n');
  }
}

module.exports = AuditLogRepository;
