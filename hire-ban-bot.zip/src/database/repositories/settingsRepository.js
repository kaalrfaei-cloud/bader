const { getDb } = require('../db');

const DEFAULT_NOTIFICATIONS = {
  ban: true,
  revoke: true,
  expire: true,
  rejoin: true,
  logs: true
};

class SettingsRepository {
  /**
   * Get guild settings or default if not configured yet
   */
  static getSettings(guildId) {
    const db = getDb();
    const stmt = db.prepare('SELECT * FROM guild_settings WHERE guild_id = ?');
    const row = stmt.get(guildId);

    if (!row) {
      return {
        guild_id: guildId,
        admin_channel_id: null,
        citizen_channel_id: null,
        log_channel_id: null,
        ban_role_id: null,
        allowed_roles: [],
        cancel_roles: [],
        dashboard_roles: [],
        allow_permanent_bans: true,
        notification_settings: { ...DEFAULT_NOTIFICATIONS },
        updated_at: new Date().toISOString()
      };
    }

    return {
      guild_id: row.guild_id,
      admin_channel_id: row.admin_channel_id,
      citizen_channel_id: row.citizen_channel_id,
      log_channel_id: row.log_channel_id,
      ban_role_id: row.ban_role_id,
      allowed_roles: this._parseJson(row.allowed_roles, []),
      cancel_roles: this._parseJson(row.cancel_roles, []),
      dashboard_roles: this._parseJson(row.dashboard_roles, []),
      allow_permanent_bans: Boolean(row.allow_permanent_bans),
      notification_settings: this._parseJson(row.notification_settings, { ...DEFAULT_NOTIFICATIONS }),
      updated_at: row.updated_at
    };
  }

  /**
   * Upsert guild settings (supports partial updates)
   */
  static saveSettings(guildId, data) {
    const db = getDb();
    const current = this.getSettings(guildId);
    const merged = { ...current, ...data };
    const now = new Date().toISOString();

    const allowedRolesJson = JSON.stringify(Array.isArray(merged.allowed_roles) ? merged.allowed_roles : []);
    const cancelRolesJson = JSON.stringify(Array.isArray(merged.cancel_roles) ? merged.cancel_roles : []);
    const dashboardRolesJson = JSON.stringify(Array.isArray(merged.dashboard_roles) ? merged.dashboard_roles : []);
    const notifJson = JSON.stringify(merged.notification_settings || DEFAULT_NOTIFICATIONS);
    const allowPerm = merged.allow_permanent_bans === false || merged.allow_permanent_bans === 0 ? 0 : 1;

    const stmt = db.prepare(`
      INSERT INTO guild_settings (
        guild_id, admin_channel_id, citizen_channel_id, log_channel_id,
        ban_role_id, allowed_roles, cancel_roles, dashboard_roles,
        allow_permanent_bans, notification_settings, updated_at
      ) VALUES (
        @guild_id, @admin_channel_id, @citizen_channel_id, @log_channel_id,
        @ban_role_id, @allowed_roles, @cancel_roles, @dashboard_roles,
        @allow_permanent_bans, @notification_settings, @updated_at
      )
      ON CONFLICT(guild_id) DO UPDATE SET
        admin_channel_id = excluded.admin_channel_id,
        citizen_channel_id = excluded.citizen_channel_id,
        log_channel_id = excluded.log_channel_id,
        ban_role_id = excluded.ban_role_id,
        allowed_roles = excluded.allowed_roles,
        cancel_roles = excluded.cancel_roles,
        dashboard_roles = excluded.dashboard_roles,
        allow_permanent_bans = excluded.allow_permanent_bans,
        notification_settings = excluded.notification_settings,
        updated_at = excluded.updated_at
    `);

    stmt.run({
      guild_id: guildId,
      admin_channel_id: merged.admin_channel_id || null,
      citizen_channel_id: merged.citizen_channel_id || null,
      log_channel_id: merged.log_channel_id || null,
      ban_role_id: merged.ban_role_id || null,
      allowed_roles: allowedRolesJson,
      cancel_roles: cancelRolesJson,
      dashboard_roles: dashboardRolesJson,
      allow_permanent_bans: allowPerm,
      notification_settings: notifJson,
      updated_at: now
    });

    return this.getSettings(guildId);
  }

  static _parseJson(val, fallback) {
    if (!val) return fallback;
    try {
      return JSON.parse(val);
    } catch {
      return fallback;
    }
  }
}

module.exports = SettingsRepository;
