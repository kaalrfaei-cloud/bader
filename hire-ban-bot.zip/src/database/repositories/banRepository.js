const { getDb } = require('../db');

class BanRepository {
  /**
   * Find currently active ban for a user in a specific guild
   */
  static getActiveBan(guildId, userId) {
    const db = getDb();
    const stmt = db.prepare(`
      SELECT * FROM bans
      WHERE guild_id = ? AND user_id = ? AND status = 'ACTIVE'
      ORDER BY id DESC LIMIT 1
    `);
    return stmt.get(guildId, userId) || null;
  }

  /**
   * Get ban by ID, optionally scoped to guildId to prevent IDOR
   */
  static getBanById(id, guildId = null) {
    const db = getDb();
    if (guildId) {
      const stmt = db.prepare('SELECT * FROM bans WHERE id = ? AND guild_id = ?');
      return stmt.get(id, guildId) || null;
    }
    const stmt = db.prepare('SELECT * FROM bans WHERE id = ?');
    return stmt.get(id) || null;
  }

  /**
   * Atomically create a new ban. Checks for existing active ban inside transaction.
   */
  static createBan(data) {
    const db = getDb();

    const insertTx = db.transaction(() => {
      // Check if user already has an active ban in this guild
      const existing = db.prepare(`
        SELECT id FROM bans
        WHERE guild_id = ? AND user_id = ? AND status = 'ACTIVE'
      `).get(data.guild_id, data.user_id);

      if (existing) {
        const error = new Error('العضو لديه منع نشط مسبقاً في هذا السيرفر.');
        error.code = 'ACTIVE_BAN_EXISTS';
        error.existingBanId = existing.id;
        throw error;
      }

      const stmt = db.prepare(`
        INSERT INTO bans (
          guild_id, user_id, user_tag, reason, moderator_id, moderator_tag,
          duration_seconds, created_at, expires_at, status
        ) VALUES (
          @guild_id, @user_id, @user_tag, @reason, @moderator_id, @moderator_tag,
          @duration_seconds, @created_at, @expires_at, 'ACTIVE'
        )
      `);

      const result = stmt.run(data);
      return {
        id: result.lastInsertRowid,
        ...data,
        status: 'ACTIVE'
      };
    });

    return insertTx();
  }

  /**
   * Revoke an active ban
   */
  static revokeBan(id, guildId, revokedBy, revokedByTag, reason) {
    const db = getDb();
    const stmt = db.prepare(`
      UPDATE bans
      SET status = 'REVOKED',
          revoked_at = ?,
          revoked_by = ?,
          revoked_by_tag = ?,
          revoke_reason = ?
      WHERE id = ? AND guild_id = ? AND status = 'ACTIVE'
    `);

    const now = new Date().toISOString();
    const result = stmt.run(now, revokedBy, revokedByTag, reason || null, id, guildId);
    return result.changes > 0;
  }

  /**
   * Mark ban as expired (used by worker scheduler)
   */
  static markExpired(id) {
    const db = getDb();
    const stmt = db.prepare(`
      UPDATE bans
      SET status = 'EXPIRED'
      WHERE id = ? AND status = 'ACTIVE'
    `);
    const result = stmt.run(id);
    return result.changes > 0;
  }

  /**
   * Fetch all active bans that have expired by current time
   */
  static getExpiredActiveBans(currentIsoTime = new Date().toISOString()) {
    const db = getDb();
    const stmt = db.prepare(`
      SELECT * FROM bans
      WHERE status = 'ACTIVE'
        AND expires_at IS NOT NULL
        AND expires_at <= ?
    `);
    return stmt.all(currentIsoTime);
  }

  /**
   * Update duration and expiration date for an existing active ban
   */
  static updateBanDuration(id, guildId, newDurationSeconds, newExpiresAt) {
    const db = getDb();
    const stmt = db.prepare(`
      UPDATE bans
      SET duration_seconds = ?,
          expires_at = ?
      WHERE id = ? AND guild_id = ? AND status = 'ACTIVE'
    `);
    const result = stmt.run(newDurationSeconds, newExpiresAt, id, guildId);
    return result.changes > 0;
  }

  /**
   * Paginated listing of bans with optional filters
   */
  static listBans({ guildId, status = null, search = '', limit = 20, offset = 0, sortBy = 'id', sortOrder = 'DESC' }) {
    const db = getDb();
    const conditions = ['guild_id = ?'];
    const params = [guildId];

    if (status && status !== 'ALL') {
      if (status === 'PERMANENT') {
        conditions.push("status = 'ACTIVE' AND expires_at IS NULL");
      } else {
        conditions.push('status = ?');
        params.push(status);
      }
    }

    if (search && search.trim() !== '') {
      const q = `%${search.trim()}%`;
      conditions.push('(user_tag LIKE ? OR user_id LIKE ? OR moderator_tag LIKE ? OR reason LIKE ?)');
      params.push(q, q, q, q);
    }

    const whereClause = conditions.join(' AND ');

    // Validate sort column to avoid SQL injection
    const allowedSort = ['id', 'created_at', 'expires_at', 'status', 'user_tag'];
    const safeSortBy = allowedSort.includes(sortBy) ? sortBy : 'id';
    const safeSortOrder = sortOrder.toUpperCase() === 'ASC' ? 'ASC' : 'DESC';

    const countStmt = db.prepare(`SELECT COUNT(*) as total FROM bans WHERE ${whereClause}`);
    const totalRow = countStmt.get(...params);
    const total = totalRow ? totalRow.total : 0;

    const listStmt = db.prepare(`
      SELECT * FROM bans
      WHERE ${whereClause}
      ORDER BY ${safeSortBy} ${safeSortOrder}
      LIMIT ? OFFSET ?
    `);

    const bans = listStmt.all(...params, limit, offset);
    return { bans, total, limit, offset };
  }

  /**
   * Summary counts for dashboard overview
   */
  static getStats(guildId) {
    const db = getDb();
    const today = new Date().toISOString().slice(0, 10);

    const activeCount = db.prepare("SELECT COUNT(*) as c FROM bans WHERE guild_id = ? AND status = 'ACTIVE'").get(guildId).c;
    const expiredCount = db.prepare("SELECT COUNT(*) as c FROM bans WHERE guild_id = ? AND status = 'EXPIRED'").get(guildId).c;
    const revokedCount = db.prepare("SELECT COUNT(*) as c FROM bans WHERE guild_id = ? AND status = 'REVOKED'").get(guildId).c;
    const totalBans = db.prepare('SELECT COUNT(*) as c FROM bans WHERE guild_id = ?').get(guildId).c;

    const todayBans = db.prepare("SELECT COUNT(*) as c FROM bans WHERE guild_id = ? AND created_at >= ?").get(guildId, `${today}T00:00:00.000Z`).c;
    const todayRevoked = db.prepare("SELECT COUNT(*) as c FROM bans WHERE guild_id = ? AND revoked_at >= ?").get(guildId, `${today}T00:00:00.000Z`).c;

    const recentBans = db.prepare(`
      SELECT * FROM bans WHERE guild_id = ? ORDER BY id DESC LIMIT 5
    `).all(guildId);

    return {
      activeBans: activeCount,
      expiredBans: expiredCount,
      revokedBans: revokedCount,
      totalBans,
      todayBans,
      todayRevoked,
      recentBans
    };
  }

  /**
   * Analytics data for charts
   */
  static getAnalytics(guildId) {
    const db = getDb();

    // Bans per day for last 7 days
    const daysStmt = db.prepare(`
      SELECT substr(created_at, 1, 10) as day, COUNT(*) as count
      FROM bans
      WHERE guild_id = ? AND created_at >= date('now', '-7 days')
      GROUP BY substr(created_at, 1, 10)
      ORDER BY day ASC
    `);
    const dailyBans = daysStmt.all(guildId);

    // Top moderators
    const modStmt = db.prepare(`
      SELECT moderator_tag, moderator_id, COUNT(*) as count
      FROM bans
      WHERE guild_id = ?
      GROUP BY moderator_id
      ORDER BY count DESC
      LIMIT 5
    `);
    const topModerators = modStmt.all(guildId);

    // Top reasons
    const reasonStmt = db.prepare(`
      SELECT reason, COUNT(*) as count
      FROM bans
      WHERE guild_id = ?
      GROUP BY reason
      ORDER BY count DESC
      LIMIT 5
    `);
    const topReasons = reasonStmt.all(guildId);

    return {
      dailyBans,
      topModerators,
      topReasons
    };
  }
}

module.exports = BanRepository;
