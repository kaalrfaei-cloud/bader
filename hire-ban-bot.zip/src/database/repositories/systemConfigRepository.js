const { getDb } = require('../db');

class SystemConfigRepository {
  static get(key, defaultValue = null) {
    const db = getDb();
    const stmt = db.prepare('SELECT value FROM system_config WHERE key = ?');
    const row = stmt.get(key);
    return row ? row.value : defaultValue;
  }

  static set(key, value) {
    const db = getDb();
    const stmt = db.prepare(`
      INSERT INTO system_config (key, value, updated_at)
      VALUES (?, ?, ?)
      ON CONFLICT(key) DO UPDATE SET
        value = excluded.value,
        updated_at = excluded.updated_at
    `);
    stmt.run(key, String(value), new Date().toISOString());
  }

  static delete(key) {
    const db = getDb();
    const stmt = db.prepare('DELETE FROM system_config WHERE key = ?');
    stmt.run(key);
  }

  static is2FAEnabled() {
    return this.get('totp_enabled') === 'true';
  }

  static get2FASecret() {
    return this.get('totp_secret', null);
  }

  static enable2FA(secret) {
    this.set('totp_secret', secret);
    this.set('totp_enabled', 'true');
  }

  static disable2FA() {
    this.delete('totp_secret');
    this.set('totp_enabled', 'false');
  }
}

module.exports = SystemConfigRepository;
