-- Hire Ban Bot Database Schema (SQLite / SQL)

CREATE TABLE IF NOT EXISTS guild_settings (
  guild_id TEXT PRIMARY KEY,
  admin_channel_id TEXT,
  citizen_channel_id TEXT,
  log_channel_id TEXT,
  ban_role_id TEXT,
  allowed_roles TEXT DEFAULT '[]',
  cancel_roles TEXT DEFAULT '[]',
  dashboard_roles TEXT DEFAULT '[]',
  allow_permanent_bans INTEGER DEFAULT 1,
  notification_settings TEXT DEFAULT '{"ban":true,"revoke":true,"expire":true,"rejoin":true,"logs":true}',
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS bans (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  guild_id TEXT NOT NULL,
  user_id TEXT NOT NULL,
  user_tag TEXT NOT NULL,
  reason TEXT NOT NULL,
  moderator_id TEXT NOT NULL,
  moderator_tag TEXT NOT NULL,
  duration_seconds INTEGER,
  created_at TEXT NOT NULL,
  expires_at TEXT,
  status TEXT NOT NULL DEFAULT 'ACTIVE',
  revoked_at TEXT,
  revoked_by TEXT,
  revoked_by_tag TEXT,
  revoke_reason TEXT
);

CREATE INDEX IF NOT EXISTS idx_bans_lookup ON bans(guild_id, user_id, status);
CREATE INDEX IF NOT EXISTS idx_bans_expiration ON bans(status, expires_at);

CREATE TABLE IF NOT EXISTS audit_logs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  guild_id TEXT NOT NULL,
  action TEXT NOT NULL,
  target_user_id TEXT,
  target_user_tag TEXT,
  moderator_id TEXT,
  moderator_tag TEXT,
  details TEXT,
  created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_audit_logs_guild ON audit_logs(guild_id, created_at DESC);

CREATE TABLE IF NOT EXISTS system_config (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS dashboard_sessions (
  sid TEXT PRIMARY KEY,
  sess TEXT NOT NULL,
  expire INTEGER NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_sessions_expire ON dashboard_sessions(expire);

