/**
 * Hire Ban Bot - Frontend Application
 */

const App = {
  state: {
    authenticated: false,
    user: null,
    csrfToken: '',
    guilds: [],
    selectedGuildId: null,
    activeTab: 'overview',
    bansPage: 1,
    bansTotal: 0,
    logsPage: 1,
    charts: {}
  },

  async init() {
    this.handleUrlFeedback();
    this.setupEventListeners();
    await this.checkAuth();
  },

  handleUrlFeedback() {
    try {
      const urlParams = new URLSearchParams(window.location.search);
      const errorMsg = urlParams.get('error');
      const infoMsg = urlParams.get('info') || urlParams.get('success');
      if (errorMsg) {
        this.showToast(decodeURIComponent(errorMsg), 'error');
        const errEl = document.getElementById('passcode-error');
        if (errEl) {
          errEl.textContent = decodeURIComponent(errorMsg);
          errEl.style.display = 'block';
        }
      } else if (infoMsg) {
        this.showToast(decodeURIComponent(infoMsg), 'success');
      }
      if (errorMsg || infoMsg) {
        const cleanUrl = window.location.pathname;
        window.history.replaceState({}, document.title, cleanUrl);
      }
    } catch (_) {}
  },

  setupEventListeners() {
    const sidebar = document.querySelector('.sidebar');
    const backdrop = document.getElementById('sidebar-backdrop');
    const mobileToggle = document.getElementById('mobile-toggle');
    const sidebarClose = document.getElementById('sidebar-close');

    const openSidebar = () => {
      sidebar?.classList.add('open');
      backdrop?.classList.add('active');
    };

    const closeSidebar = () => {
      sidebar?.classList.remove('open');
      backdrop?.classList.remove('active');
    };

    // Nav items
    document.querySelectorAll('.nav-item').forEach(item => {
      item.addEventListener('click', (e) => {
        const tab = item.getAttribute('data-tab');
        if (tab) {
          this.switchTab(tab);
          closeSidebar();
        }
      });
    });

    // Mobile sidebar toggle & backdrop & close
    mobileToggle?.addEventListener('click', openSidebar);
    sidebarClose?.addEventListener('click', closeSidebar);
    backdrop?.addEventListener('click', closeSidebar);

    // Discord Login Button loading state
    const discordLoginBtn = document.getElementById('btn-discord-login');
    if (discordLoginBtn) {
      discordLoginBtn.addEventListener('click', () => {
        discordLoginBtn.style.opacity = '0.75';
        discordLoginBtn.style.pointerEvents = 'none';
        discordLoginBtn.innerHTML = `
          <svg style="animation: spin 1s linear infinite; margin-left: 8px;" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
            <circle cx="12" cy="12" r="10" stroke-opacity="0.25"></circle>
            <path d="M12 2a10 10 0 0 1 10 10"></path>
          </svg>
          جاري التحويل إلى ديسكورد...
        `;
      });
    }

    // Passcode Login Form
    const passcodeForm = document.getElementById('form-passcode-login');
    if (passcodeForm) {
      passcodeForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const input = document.getElementById('input-passcode');
        const totpInput = document.getElementById('input-totp');
        const totpContainer = document.getElementById('container-2fa-input');
        const errEl = document.getElementById('passcode-error');
        const passcode = input?.value?.trim() || '';
        const totpToken = totpInput?.value?.trim() || '';
        if (errEl) errEl.style.display = 'none';

        if (!passcode) {
          if (errEl) { errEl.textContent = 'يرجى إدخال رمز المرور'; errEl.style.display = 'block'; }
          return;
        }

        const payload = { passcode };
        if (totpContainer && totpContainer.style.display !== 'none' && totpToken) {
          payload.totpToken = totpToken;
        }

        try {
          const res = await fetch('/auth/passcode', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
          });
          const data = await res.json();
          if (res.ok && data.success) {
            window.location.reload();
          } else if (data.require2fa) {
            if (totpContainer) {
              totpContainer.style.display = 'flex';
              totpInput?.focus();
            }
            if (errEl) {
              errEl.textContent = 'أدخل رمز المصادقة (6 أرقام) من تطبيق Authenticator ثم اضغط دخول';
              errEl.style.color = 'var(--accent-amber)';
              errEl.style.display = 'block';
            }
          } else {
            if (errEl) {
              errEl.textContent = data.error || 'رمز المرور غير صحيح';
              errEl.style.color = '#ef4444';
              errEl.style.display = 'block';
            }
          }
        } catch (err) {
          if (errEl) {
            errEl.textContent = 'فشل الاتصال بالخادم';
            errEl.style.color = '#ef4444';
            errEl.style.display = 'block';
          }
        }
      });
    }

    // Guild selector change
    document.getElementById('guild-select')?.addEventListener('change', (e) => {
      this.state.selectedGuildId = e.target.value;
      localStorage.setItem('selectedGuildId', this.state.selectedGuildId);
      this.loadCurrentTab();
    });

    // Logout button
    document.getElementById('btn-logout')?.addEventListener('click', () => this.logout());

    // Search and filter in Bans
    document.getElementById('ban-search')?.addEventListener('input', this.debounce(() => {
      this.state.bansPage = 1;
      this.loadBans();
    }, 400));

    document.getElementById('ban-status-filter')?.addEventListener('change', () => {
      this.state.bansPage = 1;
      this.loadBans();
    });

    // Search and filter in Logs
    document.getElementById('log-search')?.addEventListener('input', this.debounce(() => {
      this.state.logsPage = 1;
      this.loadLogs();
    }, 400));

    document.getElementById('log-action-filter')?.addEventListener('change', () => {
      this.state.logsPage = 1;
      this.loadLogs();
    });

    // Toggle permanent duration handling
    document.getElementById('add-ban-duration-unit')?.addEventListener('change', (e) => {
      const valInput = document.getElementById('add-ban-duration-val');
      if (valInput) {
        if (e.target.value === 'perm') {
          valInput.value = '';
          valInput.disabled = true;
          valInput.placeholder = 'منع دائم';
          valInput.removeAttribute('required');
        } else {
          valInput.disabled = false;
          valInput.placeholder = 'مثال: 7 أو 24';
          valInput.setAttribute('required', 'required');
        }
      }
    });

    // Add Ban Modal open
    document.getElementById('btn-open-add-ban')?.addEventListener('click', () => {
      this.openModal('modal-add-ban');
    });

    // Add Ban Form submit directly
    document.getElementById('form-add-ban')?.addEventListener('submit', (e) => {
      e.preventDefault();
      this.handleAddBanSubmit();
    });

    // Settings Form submit
    document.getElementById('form-settings')?.addEventListener('submit', (e) => {
      e.preventDefault();
      this.saveSettings();
    });

    // Export CSV button
    document.getElementById('btn-export-csv')?.addEventListener('click', () => {
      if (!this.state.selectedGuildId) return;
      window.location.href = `/api/guilds/${this.state.selectedGuildId}/logs/export`;
    });

    // 2FA Setup Buttons
    document.getElementById('btn-setup-2fa')?.addEventListener('click', () => {
      this.open2FASetupModal();
    });

    document.getElementById('btn-confirm-enable-2fa')?.addEventListener('click', () => {
      this.confirmEnable2FA();
    });

    document.getElementById('btn-disable-2fa')?.addEventListener('click', () => {
      this.openModal('modal-disable-2fa');
      const err = document.getElementById('error-disable-2fa');
      if (err) err.style.display = 'none';
      const input = document.getElementById('input-disable-2fa-passcode');
      if (input) input.value = '';
    });

    document.getElementById('btn-confirm-disable-2fa')?.addEventListener('click', () => {
      this.confirmDisable2FA();
    });

    // Close buttons on all modals
    document.querySelectorAll('.modal-close, .btn-modal-cancel').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const modal = btn.closest('.modal-overlay');
        if (modal) modal.classList.remove('active');
      });
    });

    // Close modal on click outside on the backdrop
    document.querySelectorAll('.modal-overlay').forEach(overlay => {
      overlay.addEventListener('click', (e) => {
        if (e.target === overlay) {
          overlay.classList.remove('active');
        }
      });
    });

    // Close modal on Escape key
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') {
        document.querySelectorAll('.modal-overlay.active').forEach(m => m.classList.remove('active'));
      }
    });
  },

  async checkAuth() {
    try {
      const res = await fetch('/auth/me');
      const data = await res.json();

      if (data.authenticated) {
        this.state.authenticated = true;
        this.state.user = data.user;
        this.state.csrfToken = data.csrfToken;
        this.state.guilds = data.guilds || [];

        this.renderUser();
        this.renderGuildPicker();

        document.getElementById('login-screen').style.display = 'none';
        document.getElementById('app-container').style.display = 'flex';

        if (this.state.guilds.length > 0) {
          const savedGuild = localStorage.getItem('selectedGuildId');
          const hasSaved = this.state.guilds.some(g => g.id === savedGuild);
          this.state.selectedGuildId = hasSaved ? savedGuild : this.state.guilds[0].id;
          document.getElementById('guild-select').value = this.state.selectedGuildId;
          this.switchTab('overview');
        } else {
          const mainContent = document.querySelector('.main-content');
          if (mainContent) {
            mainContent.innerHTML = `
              <div style="display:flex; flex-direction:column; align-items:center; justify-content:center; min-height:60vh; text-align:center; padding:30px;">
                <div style="font-size:3.5rem; margin-bottom:16px;">🛡️</div>
                <h2 style="font-size:1.4rem; margin-bottom:10px; color:#fff;">لوحة التحكم محصورة بالمسؤولين (Administrators)</h2>
                <p style="color:var(--text-muted); max-width:520px; line-height:1.7; margin-bottom:24px;">
                  أهلاً بك <strong>${this.escape(this.state.user.username)}</strong>.<br>
                  حسابك لا يمتلك صلاحية المسؤول (Administrator) في أي سيرفر متصل به البوت حالياً.<br>
                  • لإدارة البوت: يجب أن يمنحك مالك السيرفر صلاحية <strong>Administrator</strong>.<br>
                  • للاستعلام عن منعك كمواطن: توجه إلى سيرفر الديسكورد واكتب <code>منع</code> في روم المواطنين.
                </p>
                <button class="btn btn-secondary" onclick="App.logout()">تسجيل الخروج</button>
              </div>
            `;
          }
        }
      } else {
        document.getElementById('login-screen').style.display = 'flex';
        document.getElementById('app-container').style.display = 'none';
      }
    } catch (err) {
      console.error('فشل فحص الجلسة:', err);
      document.getElementById('login-screen').style.display = 'flex';
    }
  },

  renderUser() {
    if (!this.state.user) return;
    const user = this.state.user;
    document.getElementById('user-name').textContent = user.username;
    document.getElementById('user-id').textContent = user.id;

    const avatarUrl = user.avatar
      ? `https://cdn.discordapp.com/avatars/${user.id}/${user.avatar}.png`
      : '/assets/logo.jpg';
    document.getElementById('user-avatar').src = avatarUrl;
  },

  renderGuildPicker() {
    const select = document.getElementById('guild-select');
    select.innerHTML = '';

    for (const g of this.state.guilds) {
      const opt = document.createElement('option');
      opt.value = g.id;
      opt.textContent = `${g.name} (${g.memberCount} عضو)`;
      select.appendChild(opt);
    }
  },

  switchTab(tabId) {
    this.state.activeTab = tabId;

    document.querySelectorAll('.nav-item').forEach(el => {
      el.classList.toggle('active', el.getAttribute('data-tab') === tabId);
    });

    document.querySelectorAll('.page-view').forEach(el => {
      el.classList.toggle('active', el.id === `page-${tabId}`);
    });

    this.loadCurrentTab();
  },

  loadCurrentTab() {
    if (!this.state.selectedGuildId) return;

    switch (this.state.activeTab) {
      case 'overview':
        this.loadOverview();
        break;
      case 'bans':
        this.loadBans();
        break;
      case 'logs':
        this.loadLogs();
        break;
      case 'staff':
        this.loadStaff();
        break;
      case 'settings':
        this.loadSettings();
        break;
      case 'analytics':
        this.loadAnalytics();
        break;
      default:
        break;
    }
  },

  // 1. Overview
  async loadOverview() {
    const guildId = this.state.selectedGuildId;
    try {
      const res = await fetch(`/api/guilds/${guildId}/stats`);
      const data = await res.json();
      if (!data.success) throw new Error(data.error);

      const s = data.stats;
      document.getElementById('stat-active').textContent = s.activeBans;
      document.getElementById('stat-today').textContent = s.todayBans;
      document.getElementById('stat-revoked').textContent = s.revokedBans;
      document.getElementById('stat-total').textContent = s.totalBans;

      // Status pill
      const botPill = document.getElementById('bot-status-pill');
      if (data.botStatus.online) {
        botPill.className = 'status-pill online';
        botPill.innerHTML = `<span class="status-dot"></span> البوت متصل (${data.botStatus.ping}ms)`;
      } else {
        botPill.className = 'status-pill offline';
        botPill.innerHTML = `<span class="status-dot"></span> البوت غير متصل`;
      }

      // Recent table
      const tbody = document.getElementById('table-recent-bans');
      tbody.innerHTML = '';
      if (s.recentBans.length === 0) {
        tbody.innerHTML = `<tr><td colspan="5" style="text-align: center; color: var(--text-muted); padding: 24px;">لا توجد أي عمليات منع مسجلة حتى الآن.</td></tr>`;
      } else {
        for (const b of s.recentBans) {
          const tr = document.createElement('tr');
          const badgeClass = b.status === 'ACTIVE' ? 'badge-active' : (b.status === 'REVOKED' ? 'badge-revoked' : 'badge-expired');
          const badgeLabel = b.status === 'ACTIVE' ? 'نشط' : (b.status === 'REVOKED' ? 'ملغى' : 'منتهي');
          const expires = b.expires_at ? new Date(b.expires_at).toLocaleString('ar-SA') : 'دائم';

          tr.innerHTML = `
            <td><strong>${this.escape(b.user_tag)}</strong><br><small style="color:var(--text-muted)">${this.escape(b.user_id)}</small></td>
            <td>${this.escape(b.moderator_tag)}</td>
            <td>${this.escape(b.reason)}</td>
            <td>${expires}</td>
            <td><span class="badge ${badgeClass}">${badgeLabel}</span></td>
          `;
          tbody.appendChild(tr);
        }
      }
    } catch (err) {
      this.showToast(err.message, 'error');
    }
  },

  // 2. Bans List
  async loadBans() {
    const guildId = this.state.selectedGuildId;
    const search = document.getElementById('ban-search')?.value || '';
    const status = document.getElementById('ban-status-filter')?.value || 'ALL';
    const page = this.state.bansPage;

    try {
      const res = await fetch(`/api/guilds/${guildId}/bans?page=${page}&limit=12&search=${encodeURIComponent(search)}&status=${status}`);
      const data = await res.json();
      if (!data.success) throw new Error(data.error);

      const tbody = document.getElementById('table-bans');
      tbody.innerHTML = '';

      if (data.bans.length === 0) {
        tbody.innerHTML = `<tr><td colspan="8" style="text-align:center; padding:30px; color:var(--text-muted);">لم يتم العثور على أي نتائج مطابقة.</td></tr>`;
      } else {
        for (const b of data.bans) {
          const tr = document.createElement('tr');
          const badgeClass = b.status === 'ACTIVE' ? 'badge-active' : (b.status === 'REVOKED' ? 'badge-revoked' : 'badge-expired');
          const badgeLabel = b.status === 'ACTIVE' ? 'نشط' : (b.status === 'REVOKED' ? 'ملغى' : 'منتهي');
          const start = new Date(b.created_at).toLocaleDateString('ar-SA');
          const end = b.expires_at ? new Date(b.expires_at).toLocaleString('ar-SA') : 'منع دائم';

          tr.innerHTML = `
            <td>#${b.id}</td>
            <td>
              <strong>${this.escape(b.user_tag)}</strong>
              <button class="btn btn-secondary btn-sm btn-copy" title="نسخ المعرف" style="margin-right:6px; padding:2px 6px;">📋</button>
            </td>
            <td><small style="color:var(--text-muted)">${this.escape(b.user_id)}</small></td>
            <td>${this.escape(b.reason)}</td>
            <td>${start}</td>
            <td>${end}</td>
            <td><span class="badge ${badgeClass}">${badgeLabel}</span></td>
            <td>
              <div style="display:flex; gap:6px;">
                ${b.status === 'ACTIVE' ? `
                  <button class="btn btn-danger btn-sm btn-revoke">إلغاء</button>
                  <button class="btn btn-secondary btn-sm btn-extend">تعديل المدة</button>
                ` : `<span style="color:var(--text-muted)">—</span>`}
              </div>
            </td>
          `;

          const btnCopy = tr.querySelector('.btn-copy');
          if (btnCopy) btnCopy.addEventListener('click', () => this.copyText(b.user_id));

          const btnRevoke = tr.querySelector('.btn-revoke');
          if (btnRevoke) btnRevoke.addEventListener('click', () => this.promptRevokeBan(b.id, b.user_tag));

          const btnExtend = tr.querySelector('.btn-extend');
          if (btnExtend) btnExtend.addEventListener('click', () => this.promptExtendBan(b.id, b.user_tag));

          tbody.appendChild(tr);
        }
      }

      // Pagination
      document.getElementById('ban-page-info').textContent = `صفحة ${data.page} من ${data.totalPages} (إجمالي ${data.total})`;
      document.getElementById('btn-ban-prev').disabled = data.page <= 1;
      document.getElementById('btn-ban-next').disabled = data.page >= data.totalPages;

      document.getElementById('btn-ban-prev').onclick = () => {
        if (this.state.bansPage > 1) {
          this.state.bansPage--;
          this.loadBans();
        }
      };
      document.getElementById('btn-ban-next').onclick = () => {
        if (this.state.bansPage < data.totalPages) {
          this.state.bansPage++;
          this.loadBans();
        }
      };
    } catch (err) {
      this.showToast(err.message, 'error');
    }
  },

  // 3. Add Ban Direct Submit
  async handleAddBanSubmit() {
    const userId = document.getElementById('add-ban-user').value.trim();
    const durationUnit = document.getElementById('add-ban-duration-unit').value;
    const durationVal = durationUnit === 'perm' ? '' : document.getElementById('add-ban-duration-val').value.trim();
    const reason = document.getElementById('add-ban-reason').value.trim();

    if (!userId) {
      this.showToast('يرجى إدخال معرف العضو (Discord User ID)', 'warning');
      return;
    }

    if (durationUnit !== 'perm' && !durationVal) {
      this.showToast('يرجى تحديد قيمة مدة المنع (مثال: 7 أو 24)', 'warning');
      return;
    }

    const submitBtn = document.querySelector('#form-add-ban button[type="submit"]');
    const originalText = submitBtn ? submitBtn.innerHTML : 'تطبيق منع التوظيف 🚫';
    if (submitBtn) {
      submitBtn.disabled = true;
      submitBtn.innerHTML = 'جاري التنفيذ... ⏳';
    }

    try {
      await this.executeAddBan({ userId, durationVal, durationUnit, reason });
      this.closeModal('modal-add-ban');
      document.getElementById('form-add-ban').reset();
    } catch (err) {
      this.showToast(err.message, 'error');
    } finally {
      if (submitBtn) {
        submitBtn.disabled = false;
        submitBtn.innerHTML = originalText;
      }
    }
  },

  async executeAddBan({ userId, durationVal, durationUnit, reason }) {
    const guildId = this.state.selectedGuildId;
    if (!guildId) {
      throw new Error('يرجى اختيار سيرفر أولاً من القائمة العلوية.');
    }

    const res = await fetch(`/api/guilds/${guildId}/bans`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-CSRF-Token': this.state.csrfToken
      },
      body: JSON.stringify({
        userId,
        durationValue: durationVal,
        durationUnit,
        reason
      })
    });

    const data = await res.json();
    if (!data.success) throw new Error(data.error);

    this.showToast(data.message, 'success');
    this.loadBans();
  },

  // Revoke Ban Prompt
  promptRevokeBan(banId, userTag) {
    const reason = prompt(`هل أنت متأكد من إلغاء منع التوظيف عن ${userTag}؟\nاكتب سبب الإلغاء (اختياري):`);
    if (reason === null) return; // user cancelled

    this.executeRevokeBan(banId, reason);
  },

  async executeRevokeBan(banId, reason) {
    const guildId = this.state.selectedGuildId;
    try {
      const res = await fetch(`/api/guilds/${guildId}/bans/${banId}/revoke`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-CSRF-Token': this.state.csrfToken
        },
        body: JSON.stringify({ reason })
      });

      const data = await res.json();
      if (!data.success) throw new Error(data.error);

      this.showToast(data.message, 'success');
      this.loadBans();
    } catch (err) {
      this.showToast(err.message, 'error');
    }
  },

  // Extend / Shorten Ban Prompt
  promptExtendBan(banId, userTag) {
    const newDuration = prompt(`تعديل مدة المنع للعضو ${userTag}:\nأدخل المدة الجديدة (مثال: 7d أو 24h أو دائم):`);
    if (!newDuration) return;

    this.executeExtendBan(banId, newDuration);
  },

  async executeExtendBan(banId, newDuration) {
    const guildId = this.state.selectedGuildId;
    try {
      const res = await fetch(`/api/guilds/${guildId}/bans/${banId}/extend`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-CSRF-Token': this.state.csrfToken
        },
        body: JSON.stringify({ durationValue: newDuration })
      });

      const data = await res.json();
      if (!data.success) throw new Error(data.error);

      this.showToast(data.message, 'success');
      this.loadBans();
    } catch (err) {
      this.showToast(err.message, 'error');
    }
  },

  // 4. Audit Logs
  async loadLogs() {
    const guildId = this.state.selectedGuildId;
    const search = document.getElementById('log-search')?.value || '';
    const action = document.getElementById('log-action-filter')?.value || 'ALL';
    const page = this.state.logsPage;

    try {
      const res = await fetch(`/api/guilds/${guildId}/logs?page=${page}&limit=20&search=${encodeURIComponent(search)}&action=${action}`);
      const data = await res.json();
      if (!data.success) throw new Error(data.error);

      const tbody = document.getElementById('table-logs');
      tbody.innerHTML = '';

      if (data.logs.length === 0) {
        tbody.innerHTML = `<tr><td colspan="5" style="text-align:center; padding:30px; color:var(--text-muted);">لا توجد أي سجلات مطابقة.</td></tr>`;
      } else {
        for (const l of data.logs) {
          const tr = document.createElement('tr');
          const time = new Date(l.created_at).toLocaleString('ar-SA');
          const actionLabels = {
            BAN_ISSUED: '🚫 إعطاء منع',
            BAN_REVOKED: '🔓 إلغاء منع',
            BAN_EXPIRED: '⏰ انتهاء المدة',
            MEMBER_REJOIN: '🔄 عودة عضو ومواصلة المنع',
            BAN_EXTENDED: '📈 تمديد المدة',
            BAN_SHORTENED: '📉 تقصير المدة',
            SETTINGS_UPDATED: '⚙️ تعديل الإعدادات'
          };
          const label = actionLabels[l.action] || l.action;

          tr.innerHTML = `
            <td><strong>${label}</strong></td>
            <td>${this.escape(l.target_user_tag || '—')}</td>
            <td>${this.escape(l.moderator_tag || 'النظام')}</td>
            <td>${time}</td>
            <td><small style="color:var(--text-muted)">${this.escape(JSON.stringify(l.details))}</small></td>
          `;
          tbody.appendChild(tr);
        }
      }

      document.getElementById('log-page-info').textContent = `صفحة ${data.page} من ${data.totalPages} (إجمالي ${data.total})`;
      document.getElementById('btn-log-prev').disabled = data.page <= 1;
      document.getElementById('btn-log-next').disabled = data.page >= data.totalPages;

      document.getElementById('btn-log-prev').onclick = () => {
        if (this.state.logsPage > 1) {
          this.state.logsPage--;
          this.loadLogs();
        }
      };
      document.getElementById('btn-log-next').onclick = () => {
        if (this.state.logsPage < data.totalPages) {
          this.state.logsPage++;
          this.loadLogs();
        }
      };
    } catch (err) {
      this.showToast(err.message, 'error');
    }
  },

  // 5. Staff Page
  async loadStaff() {
    const guildId = this.state.selectedGuildId;
    try {
      const res = await fetch(`/api/guilds/${guildId}/staff`);
      const data = await res.json();
      if (!data.success) throw new Error(data.error);

      const tbody = document.getElementById('table-staff');
      tbody.innerHTML = '';

      if (data.staff.length === 0) {
        tbody.innerHTML = `<tr><td colspan="5" style="text-align:center; padding:30px; color:var(--text-muted);">لم يتم العثور على أي أعضاء إداريين برتب مصرحة.</td></tr>`;
      } else {
        for (const s of data.staff) {
          const tr = document.createElement('tr');
          const rolesHtml = s.roles.map(r => `<span class="badge" style="background:${r.color}22; color:${r.color}; border:1px solid ${r.color}44;">${this.escape(r.name)}</span>`).join(' ');

          const permsHtml = [
            s.isOwner ? '<span class="badge badge-perm">مالك السيرفر</span>' : '',
            s.isAdmin ? '<span class="badge badge-active">Admin</span>' : '',
            s.canIssueBan ? '<span class="badge badge-revoked">منع</span>' : '',
            s.canRevokeBan ? '<span class="badge badge-perm">إلغاء</span>' : '',
            s.canManageSettings ? '<span class="badge badge-active">إعدادات</span>' : ''
          ].filter(Boolean).join(' ');

          tr.innerHTML = `
            <td>
              <div style="display:flex; align-items:center; gap:8px;">
                <img src="${this.escape(s.avatar || '/assets/logo.jpg')}" style="width:32px; height:32px; border-radius:50%;">
                <div>
                  <strong>${this.escape(s.tag)}</strong>
                  <br><small style="color:var(--text-muted)">${this.escape(s.id)}</small>
                </div>
              </div>
            </td>
            <td>${rolesHtml || '—'}</td>
            <td>${permsHtml}</td>
            <td><span class="badge badge-revoked">مصرح</span></td>
          `;
          tbody.appendChild(tr);
        }
      }
    } catch (err) {
      this.showToast(err.message, 'error');
    }
  },

  // 6. Settings Page
  async loadSettings() {
    const guildId = this.state.selectedGuildId;
    try {
      // Fetch settings, roles, channels in parallel
      const [settingsRes, rolesRes, channelsRes] = await Promise.all([
        fetch(`/api/guilds/${guildId}/settings`),
        fetch(`/api/guilds/${guildId}/discord-roles`),
        fetch(`/api/guilds/${guildId}/discord-channels`)
      ]);

      const settingsData = await settingsRes.json();
      const rolesData = await rolesRes.json();
      const channelsData = await channelsRes.json();

      if (!settingsData.success) throw new Error(settingsData.error);

      const s = settingsData.settings;
      const roles = rolesData.roles || [];
      const channels = channelsData.channels || [];

      // Populate Ban Role dropdown
      const banRoleSelect = document.getElementById('setting-ban-role');
      banRoleSelect.innerHTML = '<option value="">-- اختر رتبة منع التوظيف --</option>';
      for (const r of roles) {
        const opt = document.createElement('option');
        opt.value = r.id;
        opt.textContent = `${r.name}`;
        if (s.ban_role_id === r.id) opt.selected = true;
        banRoleSelect.appendChild(opt);
      }

      // Populate Channels dropdowns
      const channelSelects = [
        { el: document.getElementById('setting-channel-citizen'), val: s.citizen_channel_id },
        { el: document.getElementById('setting-channel-log'), val: s.log_channel_id },
        { el: document.getElementById('setting-channel-admin'), val: s.admin_channel_id }
      ];

      for (const cs of channelSelects) {
        cs.el.innerHTML = '<option value="">-- غير محدد --</option>';
        for (const c of channels) {
          const opt = document.createElement('option');
          opt.value = c.id;
          opt.textContent = `#${c.name}`;
          if (cs.val === c.id) opt.selected = true;
          cs.el.appendChild(opt);
        }
      }

      // Populate Interactive Role Chips
      this.renderRoleChips('chips-allowed-roles', 'setting-allowed-roles', 'count-allowed-roles', roles, s.allowed_roles);
      this.renderRoleChips('chips-cancel-roles', 'setting-cancel-roles', 'count-cancel-roles', roles, s.cancel_roles);
      this.renderRoleChips('chips-dashboard-roles', 'setting-dashboard-roles', 'count-dashboard-roles', roles, s.dashboard_roles);

      // Toggles
      document.getElementById('setting-allow-perm').checked = s.allow_permanent_bans;
      const notifs = s.notification_settings || {};
      document.getElementById('notif-ban').checked = notifs.ban !== false;
      document.getElementById('notif-revoke').checked = notifs.revoke !== false;
      document.getElementById('notif-expire').checked = notifs.expire !== false;
      document.getElementById('notif-rejoin').checked = notifs.rejoin !== false;
      document.getElementById('notif-logs').checked = notifs.logs !== false;

      // Also refresh 2FA status
      this.load2FAStatus();

    } catch (err) {
      this.showToast(err.message, 'error');
    }
  },

  renderRoleChips(wrapId, selectId, countId, roles, selectedIds) {
    const wrap = document.getElementById(wrapId);
    const select = document.getElementById(selectId);
    const countEl = document.getElementById(countId);
    if (!wrap || !select) return;

    wrap.innerHTML = '';
    select.innerHTML = '';

    if (!roles || roles.length === 0) {
      wrap.innerHTML = '<span style="color:var(--text-muted); font-size:0.85rem; padding:8px;">لا توجد رتب متاحة في السيرفر حالياً. تأكد من صلاحيات البوت.</span>';
      return;
    }

    const updateCount = () => {
      const selectedCount = select.selectedOptions.length;
      if (countEl) {
        countEl.textContent = selectedCount > 0 ? `تم تحديد (${selectedCount} رتبة):` : 'انقر على الرتب لاختيارها:';
      }
    };

    const currentSelected = new Set(selectedIds || []);

    roles.forEach(r => {
      // Hidden select option
      const opt = document.createElement('option');
      opt.value = r.id;
      opt.textContent = r.name;
      const isSelected = currentSelected.has(r.id);
      if (isSelected) opt.selected = true;
      select.appendChild(opt);

      // Interactive visual chip
      const chip = document.createElement('div');
      chip.className = `role-chip ${isSelected ? 'selected' : ''}`;
      chip.dataset.roleId = r.id;

      const dot = document.createElement('span');
      dot.className = 'role-dot';
      const roleColor = r.color && r.color !== '#000000' ? r.color : '#9ca3af';
      dot.style.backgroundColor = roleColor;
      dot.style.color = roleColor;

      const label = document.createElement('span');
      label.textContent = r.name;

      chip.appendChild(dot);
      chip.appendChild(label);

      chip.onclick = () => {
        opt.selected = !opt.selected;
        chip.classList.toggle('selected', opt.selected);
        updateCount();
      };

      wrap.appendChild(chip);
    });

    updateCount();
  },

  toggleAllRoleChips(groupName, selectAll) {
    const mapping = {
      'allowed_roles': { wrapId: 'chips-allowed-roles', selectId: 'setting-allowed-roles', countId: 'count-allowed-roles' },
      'cancel_roles': { wrapId: 'chips-cancel-roles', selectId: 'setting-cancel-roles', countId: 'count-cancel-roles' },
      'dashboard_roles': { wrapId: 'chips-dashboard-roles', selectId: 'setting-dashboard-roles', countId: 'count-dashboard-roles' }
    };

    const cfg = mapping[groupName];
    if (!cfg) return;

    const wrap = document.getElementById(cfg.wrapId);
    const select = document.getElementById(cfg.selectId);
    const countEl = document.getElementById(cfg.countId);
    if (!wrap || !select) return;

    const chips = wrap.querySelectorAll('.role-chip');
    const options = select.options;

    for (let i = 0; i < options.length; i++) {
      options[i].selected = selectAll;
    }

    chips.forEach(chip => {
      chip.classList.toggle('selected', selectAll);
    });

    if (countEl) {
      const selectedCount = select.selectedOptions.length;
      countEl.textContent = selectedCount > 0 ? `تم تحديد (${selectedCount} رتبة):` : 'انقر على الرتب لاختيارها:';
    }
  },

  setDurationPreset(val, unit) {
    const valInput = document.getElementById('add-ban-duration-val');
    const unitSelect = document.getElementById('add-ban-duration-unit');
    if (!valInput || !unitSelect) return;

    unitSelect.value = unit;
    unitSelect.dispatchEvent(new Event('change'));

    if (unit === 'perm') {
      valInput.value = '';
    } else {
      valInput.value = val;
    }

    // Highlight active preset button
    document.querySelectorAll('.btn-preset').forEach(btn => {
      const isActive = (unit === 'perm' && btn.textContent.includes('دائم')) ||
                       (btn.textContent.includes(String(val)) && (unit === 'h' ? btn.textContent.includes('ساعة') : btn.textContent.includes('يوم') || btn.textContent.includes('أسبوع') || btn.textContent.includes('شهر')));
      btn.classList.toggle('active', isActive);
    });
  },

  async load2FAStatus() {
    try {
      const res = await fetch('/auth/2fa/status');
      const data = await res.json();
      const badge = document.getElementById('badge-2fa-status');
      const setupBtn = document.getElementById('btn-setup-2fa');
      const disableBtn = document.getElementById('btn-disable-2fa');

      if (data.enabled) {
        if (badge) {
          badge.textContent = 'مفعلة ومحمية 🛡️';
          badge.className = 'badge badge-revoked';
        }
        if (setupBtn) setupBtn.textContent = '🔄 إعادة ضبط الباركود (Re-configure)';
        if (disableBtn) disableBtn.style.display = 'inline-block';
      } else {
        if (badge) {
          badge.textContent = 'معطلة ❌';
          badge.className = 'badge badge-expired';
        }
        if (setupBtn) setupBtn.textContent = '📲 إعداد وربط المصادقة الثنائية (Google Authenticator)';
        if (disableBtn) disableBtn.style.display = 'none';
      }
    } catch (e) {
      console.warn('Could not load 2FA status:', e);
    }
  },

  async open2FASetupModal() {
    try {
      const res = await fetch('/auth/2fa/setup');
      const data = await res.json();
      if (!data.success) throw new Error(data.error || 'فشل توليد الباركود');

      const img = document.getElementById('img-2fa-qr');
      const secretEl = document.getElementById('text-2fa-secret');
      const errEl = document.getElementById('error-confirm-2fa');
      const tokenInput = document.getElementById('input-confirm-2fa-token');

      if (img) img.src = data.qrUrl;
      if (secretEl) secretEl.textContent = data.secret;
      if (errEl) errEl.style.display = 'none';
      if (tokenInput) tokenInput.value = '';

      this.openModal('modal-setup-2fa');
    } catch (err) {
      this.showToast(err.message, 'error');
    }
  },

  async confirmEnable2FA() {
    const tokenInput = document.getElementById('input-confirm-2fa-token');
    const errEl = document.getElementById('error-confirm-2fa');
    const token = tokenInput?.value?.trim() || '';

    if (!token || token.length !== 6) {
      if (errEl) {
        errEl.textContent = 'يرجى إدخال الرمز المكون من 6 أرقام من التطبيق';
        errEl.style.display = 'block';
      }
      return;
    }

    try {
      const res = await fetch('/auth/2fa/enable', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-CSRF-Token': this.state.csrfToken
        },
        body: JSON.stringify({ token })
      });
      const data = await res.json();
      if (!res.ok || !data.success) {
        if (errEl) {
          errEl.textContent = data.error || 'الرمز غير صحيح';
          errEl.style.display = 'block';
        }
        return;
      }

      this.showToast(data.message || 'تم تفعيل المصادقة الثنائية بنجاح!', 'success');
      this.closeModal('modal-setup-2fa');
      this.load2FAStatus();
    } catch (err) {
      if (errEl) {
        errEl.textContent = 'حدث خطأ أثناء الاتصال بالخادم';
        errEl.style.display = 'block';
      }
    }
  },

  async confirmDisable2FA() {
    const input = document.getElementById('input-disable-2fa-passcode');
    const errEl = document.getElementById('error-disable-2fa');
    const passcode = input?.value?.trim() || '';

    if (!passcode) {
      if (errEl) {
        errEl.textContent = 'يرجى إدخال رمز المرور للتأكيد';
        errEl.style.display = 'block';
      }
      return;
    }

    try {
      const res = await fetch('/auth/2fa/disable', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-CSRF-Token': this.state.csrfToken
        },
        body: JSON.stringify({ passcode })
      });
      const data = await res.json();
      if (!res.ok || !data.success) {
        if (errEl) {
          errEl.textContent = data.error || 'رمز المرور غير صحيح';
          errEl.style.display = 'block';
        }
        return;
      }

      this.showToast(data.message || 'تم تعطيل المصادقة الثنائية', 'warning');
      this.closeModal('modal-disable-2fa');
      this.load2FAStatus();
    } catch (err) {
      if (errEl) {
        errEl.textContent = 'حدث خطأ أثناء الاتصال بالخادم';
        errEl.style.display = 'block';
      }
    }
  },

  async saveSettings() {
    const guildId = this.state.selectedGuildId;

    const getSelected = (selectEl) => {
      return Array.from(selectEl.selectedOptions).map(o => o.value);
    };

    const payload = {
      ban_role_id: document.getElementById('setting-ban-role').value || null,
      citizen_channel_id: document.getElementById('setting-channel-citizen').value || null,
      log_channel_id: document.getElementById('setting-channel-log').value || null,
      admin_channel_id: document.getElementById('setting-channel-admin').value || null,
      allowed_roles: getSelected(document.getElementById('setting-allowed-roles')),
      cancel_roles: getSelected(document.getElementById('setting-cancel-roles')),
      dashboard_roles: getSelected(document.getElementById('setting-dashboard-roles')),
      allow_permanent_bans: document.getElementById('setting-allow-perm').checked,
      notification_settings: {
        ban: document.getElementById('notif-ban').checked,
        revoke: document.getElementById('notif-revoke').checked,
        expire: document.getElementById('notif-expire').checked,
        rejoin: document.getElementById('notif-rejoin').checked,
        logs: document.getElementById('notif-logs').checked
      }
    };

    try {
      const res = await fetch(`/api/guilds/${guildId}/settings`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-CSRF-Token': this.state.csrfToken
        },
        body: JSON.stringify(payload)
      });

      const data = await res.json();
      if (!data.success) throw new Error(data.error);

      this.showToast(data.message, 'success');
    } catch (err) {
      this.showToast(err.message, 'error');
    }
  },

  // 7. Analytics Charts
  async loadAnalytics() {
    const guildId = this.state.selectedGuildId;
    try {
      const res = await fetch(`/api/guilds/${guildId}/analytics`);
      const data = await res.json();
      if (!data.success) throw new Error(data.error);

      const a = data.analytics;

      // Chart 1: Daily Bans
      const ctxDaily = document.getElementById('chart-daily-bans')?.getContext('2d');
      if (ctxDaily) {
        if (this.state.charts.daily) this.state.charts.daily.destroy();

        const labels = a.dailyBans.map(d => d.day);
        const counts = a.dailyBans.map(d => d.count);

        this.state.charts.daily = new Chart(ctxDaily, {
          type: 'line',
          data: {
            labels: labels.length > 0 ? labels : ['لا توجد بيانات'],
            datasets: [{
              label: 'عمليات المنع اليومية',
              data: counts.length > 0 ? counts : [0],
              borderColor: '#ef4444',
              backgroundColor: 'rgba(239, 68, 68, 0.15)',
              tension: 0.3,
              fill: true
            }]
          },
          options: {
            responsive: true,
            plugins: { legend: { labels: { color: '#f3f4f6', font: { family: 'Cairo' } } } },
            scales: {
              x: { ticks: { color: '#9ca3af' }, grid: { color: '#242938' } },
              y: { ticks: { color: '#9ca3af' }, grid: { color: '#242938' }, beginAtZero: true }
            }
          }
        });
      }

      // Chart 2: Top Moderators
      const ctxMods = document.getElementById('chart-top-mods')?.getContext('2d');
      if (ctxMods) {
        if (this.state.charts.mods) this.state.charts.mods.destroy();

        const labels = a.topModerators.map(m => m.moderator_tag);
        const counts = a.topModerators.map(m => m.count);

        this.state.charts.mods = new Chart(ctxMods, {
          type: 'bar',
          data: {
            labels: labels.length > 0 ? labels : ['لا يوجد إداريين'],
            datasets: [{
              label: 'العمليات المنفذة',
              data: counts.length > 0 ? counts : [0],
              backgroundColor: '#3b82f6'
            }]
          },
          options: {
            responsive: true,
            plugins: { legend: { labels: { color: '#f3f4f6', font: { family: 'Cairo' } } } },
            scales: {
              x: { ticks: { color: '#9ca3af' }, grid: { color: '#242938' } },
              y: { ticks: { color: '#9ca3af' }, grid: { color: '#242938' }, beginAtZero: true }
            }
          }
        });
      }

      // Chart 3: Top Reasons
      const ctxReasons = document.getElementById('chart-top-reasons')?.getContext('2d');
      if (ctxReasons) {
        if (this.state.charts.reasons) this.state.charts.reasons.destroy();

        const labels = a.topReasons.map(r => r.reason);
        const counts = a.topReasons.map(r => r.count);

        this.state.charts.reasons = new Chart(ctxReasons, {
          type: 'doughnut',
          data: {
            labels: labels.length > 0 ? labels : ['لا توجد أسباب'],
            datasets: [{
              data: counts.length > 0 ? counts : [1],
              backgroundColor: ['#ef4444', '#f59e0b', '#10b981', '#3b82f6', '#8b5cf6']
            }]
          },
          options: {
            responsive: true,
            plugins: { legend: { position: 'bottom', labels: { color: '#f3f4f6', font: { family: 'Cairo' } } } }
          }
        });
      }

    } catch (err) {
      this.showToast(err.message, 'error');
    }
  },

  // Modal helpers
  openModal(modalId) {
    document.getElementById(modalId)?.classList.add('active');
  },

  closeModal(modalId) {
    document.getElementById(modalId)?.classList.remove('active');
  },

  // Toast notifications
  showToast(message, type = 'info') {
    const container = document.getElementById('toast-container');
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;

    let icon = 'ℹ️';
    if (type === 'success') icon = '✅';
    if (type === 'error') icon = '❌';
    if (type === 'warning') icon = '⚠️';

    toast.innerHTML = `<span>${icon}</span><span>${this.escape(message)}</span>`;
    container.appendChild(toast);

    setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transition = 'opacity 0.4s';
      setTimeout(() => toast.remove(), 400);
    }, 4000);
  },

  // Utility helpers
  async logout() {
    await fetch('/auth/logout', {
      method: 'POST',
      headers: { 'X-CSRF-Token': this.state.csrfToken }
    });
    window.location.reload();
  },

  copyText(text) {
    const safeText = String(text || '');
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(safeText).then(() => {
        this.showToast(`تم نسخ المعرف: ${safeText}`, 'success');
      }).catch(() => {
        this.fallbackCopy(safeText);
      });
    } else {
      this.fallbackCopy(safeText);
    }
  },

  fallbackCopy(text) {
    try {
      const ta = document.createElement('textarea');
      ta.value = text;
      ta.style.position = 'fixed';
      ta.style.opacity = '0';
      document.body.appendChild(ta);
      ta.focus();
      ta.select();
      document.execCommand('copy');
      document.body.removeChild(ta);
      this.showToast(`تم نسخ المعرف: ${text}`, 'success');
    } catch {
      this.showToast(`تعذر النسخ التلقائي: ${text}`, 'info');
    }
  },

  escape(str) {
    if (str === null || str === undefined) return '';
    const div = document.createElement('div');
    div.textContent = String(str);
    return div.innerHTML;
  },

  debounce(fn, delay) {
    let timeout;
    return (...args) => {
      clearTimeout(timeout);
      timeout = setTimeout(() => fn.apply(this, args), delay);
    };
  }
};

window.App = App;

window.addEventListener('DOMContentLoaded', () => {
  App.init();
});
