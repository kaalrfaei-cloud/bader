const Database = require('better-sqlite3');
const fs = require('fs');
const path = require('path');
const logger = require('../utils/logger');

let db = null;

function initDatabase(customPath = null) {
  const dbPath = customPath || process.env.DATABASE_PATH || path.resolve(__dirname, '../../data/hire_ban.sqlite');
  const dir = path.dirname(dbPath);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }

  logger.info(`جاري تهيئة قاعدة البيانات من: ${dbPath}`);
  db = new Database(dbPath);

  // Performance and durability pragmas
  db.pragma('journal_mode = WAL');
  db.pragma('synchronous = NORMAL');
  db.pragma('foreign_keys = ON');

  // Load and execute schema
  const schemaPath = path.resolve(__dirname, 'schema.sql');
  const schema = fs.readFileSync(schemaPath, 'utf8');
  db.exec(schema);

  logger.success('تمت تهيئة جداول قاعدة البيانات بنجاح.');
  return db;
}

function getDb() {
  if (!db) {
    return initDatabase();
  }
  return db;
}

function closeDatabase() {
  if (db) {
    try {
      db.close();
      logger.info('تم إغلاق اتصال قاعدة البيانات بنجاح.');
    } catch (e) {
      logger.error('خطأ أثناء إغلاق قاعدة البيانات:', e.message);
    }
    db = null;
  }
}

module.exports = {
  initDatabase,
  getDb,
  closeDatabase
};
