const express = require('express');
const session = require('express-session');
const helmet = require('helmet');
const cors = require('cors');
const compression = require('compression');
const path = require('path');
const logger = require('../../src/utils/logger');
const csrfProtection = require('../../src/middleware/csrfMiddleware');
const antiHackingFirewall = require('../../src/middleware/antiHackingFirewall');
const SQLiteSessionStore = require('../../src/security/sqliteSessionStore');
const { apiLimiter } = require('../../src/middleware/rateLimitMiddleware');
const createAuthRoutes = require('./routes/auth');
const createApiRoutes = require('./routes/api');

function createDashboardServer(discordClient) {
  const app = express();

  // Hide server fingerprint
  app.disable('x-powered-by');

  // Trust proxy: trust 1 hop for reverse proxy (Render / Cloudflare / Nginx) to prevent client spoofing of X-Forwarded-For
  app.set('trust proxy', 1);

  // Compress all responses with gzip for maximum performance
  app.use(compression());

  // Security Headers via Helmet
  app.use(helmet({
    contentSecurityPolicy: false,
    crossOriginEmbedderPolicy: false
  }));

  // Restrict CORS: Allow only trusted origins (Dashboard URL, Render URL, and local dev)
  app.use(cors({
    origin: (origin, callback) => {
      // Allow requests with no origin (e.g. same-origin navigations, curl, server-to-server)
      if (!origin) return callback(null, true);

      let parsedUrl;
      try {
        parsedUrl = new URL(origin);
      } catch {
        return callback(null, false);
      }

      const hostname = parsedUrl.hostname;
      // Allow local development strictly by hostname match
      if (hostname === 'localhost' || hostname === '127.0.0.1' || hostname === '::1') {
        return callback(null, true);
      }

      // Explicit trusted origins from environment variables
      const allowedOrigins = [];
      if (process.env.DASHBOARD_URL) {
        try {
          allowedOrigins.push(new URL(process.env.DASHBOARD_URL).origin);
        } catch (_) {}
      }
      if (process.env.RENDER_EXTERNAL_URL) {
        try {
          allowedOrigins.push(new URL(process.env.RENDER_EXTERNAL_URL).origin);
        } catch (_) {}
      }

      if (allowedOrigins.includes(parsedUrl.origin)) {
        return callback(null, true);
      }

      return callback(null, false);
    },
    credentials: true
  }));

  app.use(express.json({ limit: '200kb' }));
  app.use(express.urlencoded({ extended: true, limit: '200kb' }));

  // Proactive Anti-Hacking & Scanner Firewall
  app.use(antiHackingFirewall);

  // Session configuration with database store (SQLite) & hardened cookies
  const isProd = process.env.NODE_ENV === 'production';
  const crypto = require('crypto');
  let sessionSecret = process.env.SESSION_SECRET;
  if (!sessionSecret || !sessionSecret.trim() || sessionSecret.length < 32) {
    if (isProd) {
      logger.warn('⚠️ SESSION_SECRET غير محدد أو قصير في Render. تم توليد مفتاح جلسة عشوائي مشفر تلقائياً لحماية النظام ومنع تعطل الخادم.');
    }
    // Generate a secure ephemeral secret
    sessionSecret = crypto.randomBytes(32).toString('hex');
  }

  const sessionStore = new SQLiteSessionStore({
    ttl: 12 * 3600 // 12 hours
  });

  app.use(session({
    store: sessionStore,
    secret: sessionSecret,
    resave: false,
    saveUninitialized: false,
    name: isProd ? '__Host-hireban_sid' : 'hireban_dev_sid',
    cookie: {
      httpOnly: true,
      secure: isProd, // Enforce secure cookies on HTTPS
      sameSite: 'lax',
      path: '/',
      maxAge: 12 * 60 * 60 * 1000 // 12 hours
    }
  }));

  // Apply CSRF protection across state-mutating requests
  app.use(csrfProtection);

  // Serve static assets with caching headers strictly from frontend/public directory
  const publicDir = path.resolve(__dirname, '../frontend/public');
  app.use(express.static(publicDir, {
    maxAge: '1d',
    etag: true,
    dotfiles: 'ignore' // NEVER serve hidden files like .env
  }));

  // Public Health Check Endpoint for Render / Keep-Alive / Uptime Monitors
  // Stripped of internal diagnostics, bot credentials, and guild metrics for information disclosure protection
  app.get(['/health', '/api/health'], (req, res) => {
    const isOnline = Boolean(discordClient && (discordClient.isReady() || discordClient.user || discordClient._isReadyFlag));
    res.json({
      status: 'ok',
      botOnline: isOnline,
      uptime: Math.floor(process.uptime()),
      timestamp: new Date().toISOString()
    });
  });

  // Mount Auth routes
  app.use('/auth', createAuthRoutes(discordClient));

  // Mount API routes with general rate limiter
  app.use('/api', apiLimiter, createApiRoutes(discordClient));

  // Strict Whitelist for SPA Pages (Never serve index.html to file probes or unknown routes)
  const VALID_SPA_PAGES = new Set([
    '/',
    '/login',
    '/dashboard',
    '/bans',
    '/settings',
    '/audit',
    '/logs',
    '/profile',
    '/history'
  ]);

  app.use((req, res) => {
    const cleanPath = (req.path || '/').toLowerCase().replace(/\/+$/, '') || '/';
    if (req.method === 'GET' && VALID_SPA_PAGES.has(cleanPath)) {
      return res.sendFile(path.join(publicDir, 'index.html'));
    }
    return res.status(404).send('Not Found');
  });

  // Global Secure Error Handler (No sensitive leaks to client)
  app.use((err, req, res, next) => {
    logger.error('خطأ غير معالج في خادم الداشبورد:', err.stack || err.message);
    if (res.headersSent) {
      return next(err);
    }
    const statusCode = err.status || 500;
    const clientMessage = isProd
      ? 'حدث خطأ داخلي في خادم لوحة التحكم.'
      : (err.message || 'حدث خطأ داخلي.');

    res.status(statusCode).json({ error: clientMessage });
  });

  return app;
}

module.exports = { createDashboardServer };
