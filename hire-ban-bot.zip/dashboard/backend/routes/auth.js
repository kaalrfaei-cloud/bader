const express = require('express');
const crypto = require('crypto');
const logger = require('../../../src/utils/logger');
const PermissionsGuard = require('../../../src/security/permissions');
const SettingsRepository = require('../../../src/database/repositories/settingsRepository');
const SystemConfigRepository = require('../../../src/database/repositories/systemConfigRepository');
const AuditLogRepository = require('../../../src/database/repositories/auditLogRepository');
const TotpService = require('../../../src/security/totp');
const PasscodeSecurity = require('../../../src/security/passcodeSecurity');
const { loginLimiter, oauthLimiter, twoFaLimiter } = require('../../../src/middleware/rateLimitMiddleware');
const { validateBody, schemas } = require('../../../src/middleware/validator');

function createAuthRoutes(discordClient) {
  const router = express.Router();

  const { resolveClientSecret } = require('../../../src/utils/securityCipher');
  const CLIENT_ID = process.env.DISCORD_CLIENT_ID || '1553971453253255248';
  const CLIENT_SECRET = resolveClientSecret();

  const isProd = process.env.NODE_ENV === 'production';
  const isDevMock = !isProd && process.env.DEV_MOCK_AUTH === 'true';

  function getRedirectUri(req) {
    const host = req.headers['x-forwarded-host'] || req.get('host');
    const isLocal = host.includes('localhost') || host.includes('127.0.0.1');
    const proto = isLocal ? 'http' : 'https';
    return `${proto}://${host}/auth/callback`;
  }

  const sessionSecret = process.env.SESSION_SECRET || 'hire-ban-bot-security-secret-2026';

  function generateOAuthState() {
    const timestamp = Date.now();
    const nonce = crypto.randomBytes(16).toString('hex');
    const payload = `${timestamp}.${nonce}`;
    const hmac = crypto.createHmac('sha256', sessionSecret).update(payload).digest('hex');
    return `${payload}.${hmac}`;
  }

  function verifyOAuthState(stateStr) {
    if (!stateStr || typeof stateStr !== 'string') return false;
    const parts = stateStr.split('.');
    if (parts.length !== 3) return false;
    const [timestamp, nonce, hmac] = parts;
    const timeNum = Number(timestamp);
    if (isNaN(timeNum)) return false;

    // Check expiry (15 minutes)
    if (Date.now() - timeNum > 15 * 60 * 1000 || Date.now() - timeNum < -60 * 1000) {
      logger.warn('OAuth State expired or timestamp invalid');
      return false;
    }

    const payload = `${timestamp}.${nonce}`;
    const expectedHmac = crypto.createHmac('sha256', sessionSecret).update(payload).digest('hex');

    const hmacBuf = Buffer.from(hmac, 'utf8');
    const expectedBuf = Buffer.from(expectedHmac, 'utf8');
    if (hmacBuf.length !== expectedBuf.length) return false;

    return crypto.timingSafeEqual(hmacBuf, expectedBuf);
  }

  // 1. Initiate OAuth2 Login
  router.get('/login', oauthLimiter, (req, res) => {
    // Only in development environment mock auth is permitted
    if (isDevMock) {
      req.session.regenerate((err) => {
        if (err) return res.status(500).send('Session error');
        req.session.user = { id: 'admin_owner', username: 'مدير النظام (Mock Dev)', avatar: null };
        req.session.isAdminMaster = true;
        req.session.csrfToken = crypto.randomBytes(32).toString('hex');
        req.session.save(() => res.redirect('/'));
      });
      return;
    }

    if (!CLIENT_ID || !CLIENT_SECRET || CLIENT_SECRET === 'your_discord_client_secret_here') {
      return res.redirect('/?error=' + encodeURIComponent('إعدادات Discord OAuth2 غير مكتملة. يرجى الدخول برمز المرور الإداري.'));
    }

    const redirectUri = getRedirectUri(req);
    req.session.oauthRedirectUri = redirectUri;

    const state = generateOAuthState();
    req.session.oauthState = state;

    const authUrl = new URL('https://discord.com/oauth2/authorize');
    authUrl.searchParams.set('client_id', CLIENT_ID);
    authUrl.searchParams.set('redirect_uri', redirectUri);
    authUrl.searchParams.set('response_type', 'code');
    authUrl.searchParams.set('scope', 'identify guilds');
    authUrl.searchParams.set('state', state);

    req.session.save((err) => {
      if (err) logger.error('خطأ أثناء حفظ الجلسة عند تسجيل الدخول:', err.message);
      res.redirect(authUrl.toString());
    });
  });

  // 2. OAuth2 Callback
  router.get('/callback', oauthLimiter, async (req, res) => {
    const { code, state, error } = req.query;

    if (error) {
      logger.warn(`فشل تسجيل الدخول بواسطة Discord: ${error}`);
      return res.redirect('/?error=' + encodeURIComponent('تم إلغاء تسجيل الدخول بواسطة Discord.'));
    }

    const isStateValid = verifyOAuthState(state) || (req.session?.oauthState && req.session.oauthState === state);
    if (!code || !state || !isStateValid) {
      logger.warn('فشل التحقق من OAuth State (CSRF mismatch or tampered)');
      return res.status(403).send('طلب غير صالح أو تم التلاعب برمز التحقق (State Mismatch). يرجى المحاولة مجدداً.');
    }

    const redirectUri = req.session?.oauthRedirectUri || getRedirectUri(req);
    if (req.session) {
      delete req.session.oauthState;
      delete req.session.oauthRedirectUri;
    }

    try {
      // Exchange code for token
      const tokenResponse = await fetch('https://discord.com/api/v10/oauth2/token', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams({
          client_id: CLIENT_ID,
          client_secret: CLIENT_SECRET,
          grant_type: 'authorization_code',
          code,
          redirect_uri: redirectUri
        })
      });

      if (!tokenResponse.ok) {
        const errText = await tokenResponse.text();
        logger.error(`فشل استبدال كود OAuth2: ${errText}`);
        return res.redirect('/?error=' + encodeURIComponent('فشل استبدال رمز الدخول مع Discord.'));
      }

      const tokenData = await tokenResponse.json();
      const accessToken = tokenData.access_token;

      // Fetch user profile
      const userRes = await fetch('https://discord.com/api/v10/users/@me', {
        headers: { Authorization: `Bearer ${accessToken}` }
      });
      const userData = await userRes.json();

      // Fetch user guilds
      const guildsRes = await fetch('https://discord.com/api/v10/users/@me/guilds', {
        headers: { Authorization: `Bearer ${accessToken}` }
      });
      const userGuilds = await guildsRes.json();

      const adminGuildsMap = {};
      if (Array.isArray(userGuilds)) {
        for (const ug of userGuilds) {
          const isOwner = Boolean(ug.owner);
          let isAdmin = false;
          try {
            const perms = BigInt(ug.permissions || 0);
            isAdmin = (perms & 8n) === 8n;
          } catch {}
          if (isOwner || isAdmin) {
            adminGuildsMap[ug.id] = { isOwner, isAdmin: true };
          }
        }
      }

      // Regenerate session to prevent session fixation
      req.session.regenerate((err) => {
        if (err) {
          logger.error('خطأ تجديد الجلسة بعد OAuth2:', err.message);
          return res.redirect('/?error=' + encodeURIComponent('فشل تهيئة الجلسة الآمنة.'));
        }

        req.session.user = {
          id: userData.id,
          username: userData.username,
          avatar: userData.avatar
            ? `https://cdn.discordapp.com/avatars/${userData.id}/${userData.avatar}.png`
            : null
        };
        req.session.adminGuilds = adminGuildsMap;
        req.session.csrfToken = crypto.randomBytes(32).toString('hex');

        AuditLogRepository.createLog({
          guildId: 'SYSTEM',
          action: 'LOGIN_SUCCESS_OAUTH',
          moderatorId: userData.id,
          moderatorTag: userData.username,
          details: { ip: req.ip }
        });

        req.session.save(() => {
          res.redirect('/?auth=success');
        });
      });
    } catch (err) {
      logger.error('خطأ غير متوقع في OAuth callback:', err.message);
      res.redirect('/?error=' + encodeURIComponent('حدث خطأ أثناء إتمام عملية تسجيل الدخول.'));
    }
  });

  // 3. User Session Info & Accessible Guilds (with Live Discord Revalidation)
  router.get('/me', async (req, res) => {
    if (!req.session || !req.session.user) {
      return res.json({ authenticated: false });
    }

    const userId = req.session.user.id;
    const isMasterAdmin = Boolean(req.session.isAdminMaster) || userId === 'admin_owner';
    const accessibleGuilds = [];
    const adminGuilds = req.session.adminGuilds || {};

    if (discordClient && discordClient.guilds && discordClient.guilds.cache) {
      for (const [guildId, guild] of discordClient.guilds.cache) {
        if (isMasterAdmin || isDevMock) {
          accessibleGuilds.push({
            id: guild.id,
            name: guild.name,
            icon: typeof guild.iconURL === 'function' ? guild.iconURL() : null,
            memberCount: guild.memberCount || 0,
            canManageSettings: true
          });
          continue;
        }

        // Live verification from guild cache or fetch
        const isOwner = guild.ownerId === userId || Boolean(adminGuilds[guildId]?.isOwner);
        let isAdmin = Boolean(adminGuilds[guildId]?.isAdmin) || isOwner;

        const cachedMember = guild.members?.cache ? guild.members.cache.get(userId) : null;
        if (cachedMember?.permissions?.has) {
          isAdmin = isAdmin || cachedMember.permissions.has(8n);
        }

        const settings = SettingsRepository.getSettings(guildId);
        const hasDashboardRole = (settings.dashboard_roles || []).some(rId => cachedMember?.roles?.cache?.has(rId));

        if (isOwner || isAdmin || hasDashboardRole) {
          accessibleGuilds.push({
            id: guild.id,
            name: guild.name,
            icon: typeof guild.iconURL === 'function' ? guild.iconURL() : null,
            memberCount: guild.memberCount || 0,
            canManageSettings: isOwner || isAdmin
          });
        }
      }
    }

    if (!req.session.csrfToken) {
      req.session.csrfToken = crypto.randomBytes(32).toString('hex');
    }

    res.json({
      authenticated: true,
      user: req.session.user,
      csrfToken: req.session.csrfToken,
      guilds: accessibleGuilds
    });
  });

  // 4. Admin Passcode Login (with Anti-Brute-Force Lockout, Scrypt Hash, and 2FA)
  router.post('/passcode', loginLimiter, validateBody(schemas.passcode), async (req, res) => {
    const { passcode, totpToken } = req.validatedBody;
    const clientIp = req.ip || req.connection?.remoteAddress || 'unknown';

    // 1. Check brute force lockout
    const lockout = PasscodeSecurity.checkLockout(clientIp);
    if (lockout.isLocked) {
      logger.warn(`محاولة دخول مرفوضة (عنوان مقفول مؤقتاً): ${clientIp} - متبقي ${lockout.remainingSeconds} ثانية.`);
      return res.status(429).json({
        error: `تم قفل محاولات الدخول مؤقتاً لحماية النظام. يرجى الانتظار ${Math.ceil(lockout.remainingSeconds / 60)} دقيقة.`
      });
    }

    // 2. Resolve Master Passcode
    const masterKey = process.env.ADMIN_PASSCODE || 'admin2026';
    const isPasscodeValid = PasscodeSecurity.verifyPasscode(passcode, masterKey);

    if (!isPasscodeValid) {
      const attempt = await PasscodeSecurity.recordFailedAttempt(clientIp);
      AuditLogRepository.createLog({
        guildId: 'SYSTEM',
        action: 'LOGIN_FAILURE',
        moderatorId: 'UNAUTHORIZED',
        moderatorTag: `IP: ${clientIp}`,
        details: { attempts: attempt.count, locked: attempt.isLocked }
      });

      return res.status(401).json({
        error: attempt.isLocked
          ? 'تم تجاوز الحد الأقصى للمحاولات وتم قفل الدخول مؤقتاً لمدة 15 دقيقة.'
          : 'بيانات الدخول غير صحيحة. يرجى التأكد وإعادة المحاولة.'
      });
    }

    // 3. Check 2FA if enabled
    const is2faActive = SystemConfigRepository.is2FAEnabled() || Boolean(process.env.ADMIN_2FA_SECRET);
    if (is2faActive) {
      const secret = SystemConfigRepository.get2FASecret() || process.env.ADMIN_2FA_SECRET;
      if (!totpToken) {
        return res.json({ require2fa: true, message: 'يرجى إدخال رمز المصادقة الثنائية (2FA)' });
      }
      const isValid = TotpService.verifyToken(totpToken, secret);
      if (!isValid) {
        await PasscodeSecurity.recordFailedAttempt(clientIp);
        return res.status(401).json({ error: 'رمز التحقق (2FA) غير صحيح أو منتهي الصلاحية.' });
      }
    }

    // Success! Clear failed attempts
    PasscodeSecurity.recordSuccessfulAttempt(clientIp);

    // Regenerate session ID to prevent Session Fixation
    req.session.regenerate((err) => {
      if (err) {
        logger.error('خطأ تجديد الجلسة للمدير:', err.message);
        return res.status(500).json({ error: 'تعذر إنشاء جلسة آمنة' });
      }

      const ownerUser = discordClient.application?.owner?.user || discordClient.application?.owner;
      req.session.user = {
        id: ownerUser?.id || 'admin_owner',
        username: ownerUser?.username || 'مدير النظام (Admin)',
        avatar: ownerUser?.avatar || null
      };
      req.session.isAdminMaster = true;
      req.session.csrfToken = crypto.randomBytes(32).toString('hex');

      AuditLogRepository.createLog({
        guildId: 'SYSTEM',
        action: 'LOGIN_SUCCESS_PASSCODE',
        moderatorId: req.session.user.id,
        moderatorTag: req.session.user.username,
        details: { ip: clientIp, has2fa: is2faActive }
      });

      req.session.save(() => {
        logger.info(`تم تسجيل دخول المدير بنجاح ${is2faActive ? '(مع 2FA)' : ''} من: ${clientIp}`);
        res.json({ success: true, redirect: '/' });
      });
    });
  });

  // 5. Get 2FA Status
  router.get('/2fa/status', (req, res) => {
    const enabled = SystemConfigRepository.is2FAEnabled() || Boolean(process.env.ADMIN_2FA_SECRET);
    res.json({ enabled });
  });

  // 6. Setup 2FA: Generate Secret & QR Code Locally
  router.get('/2fa/setup', async (req, res) => {
    if (!req.session?.user) {
      return res.status(401).json({ error: 'يجب تسجيل الدخول أولاً كمدير لتفعيل المصادقة الثنائية.' });
    }
    const secret = TotpService.generateSecret(16);
    req.session.tempTotpSecret = secret;

    const otpAuthUrl = TotpService.getOtpAuthUrl({
      issuer: 'بوت منع التوظيف',
      accountName: req.session.user.username || 'Admin',
      secret
    });

    // 100% offline local Base64 QR generation
    const qrUrl = await TotpService.getQrCodeUrl(otpAuthUrl);

    res.json({
      success: true,
      secret,
      otpAuthUrl,
      qrUrl
    });
  });

  // 7. Verify and Activate 2FA (Protected by CSRF & twoFaLimiter)
  router.post('/2fa/enable', twoFaLimiter, (req, res) => {
    if (!req.session?.user) {
      return res.status(401).json({ error: 'غير مصرح' });
    }
    const { token } = req.body || {};
    const secret = req.session.tempTotpSecret;

    if (!secret) {
      return res.status(400).json({ error: 'انتهت صلاحية جلسة الإعداد. يرجى طلب باركود جديد.' });
    }

    const isValid = TotpService.verifyToken(token, secret);
    if (!isValid) {
      return res.status(400).json({ error: 'الرمز غير صحيح. تأكد من إدخال الرمز المكون من 6 أرقام من تطبيق Authenticator.' });
    }

    SystemConfigRepository.enable2FA(secret);
    delete req.session.tempTotpSecret;

    AuditLogRepository.createLog({
      guildId: 'SYSTEM',
      action: '2FA_ENABLED',
      moderatorId: req.session.user.id,
      moderatorTag: req.session.user.username,
      details: { ip: req.ip }
    });

    logger.success(`تم تفعيل المصادقة الثنائية (2FA) بنجاح للمدير.`);
    res.json({ success: true, message: 'تم تفعيل المصادقة الثنائية (2FA) بنجاح وحماية لوحة التحكم!' });
  });

  // 8. Disable 2FA (Protected by CSRF, twoFaLimiter, Passcode & optional current 2FA token)
  router.post('/2fa/disable', twoFaLimiter, (req, res) => {
    if (!req.session?.user) {
      return res.status(401).json({ error: 'غير مصرح' });
    }
    const { passcode, totpToken } = req.body || {};
    const masterKey = process.env.ADMIN_PASSCODE || 'admin2026';

    if (!PasscodeSecurity.verifyPasscode(passcode, masterKey)) {
      return res.status(401).json({ error: 'رمز المرور غير صحيح لتأكيد الإلغاء.' });
    }

    // Require current 2FA token if active
    const is2faActive = SystemConfigRepository.is2FAEnabled() || Boolean(process.env.ADMIN_2FA_SECRET);
    if (is2faActive && totpToken) {
      const secret = SystemConfigRepository.get2FASecret() || process.env.ADMIN_2FA_SECRET;
      if (!TotpService.verifyToken(totpToken, secret)) {
        return res.status(401).json({ error: 'رمز 2FA غير صحيح.' });
      }
    }

    SystemConfigRepository.disable2FA();

    AuditLogRepository.createLog({
      guildId: 'SYSTEM',
      action: '2FA_DISABLED',
      moderatorId: req.session.user.id,
      moderatorTag: req.session.user.username,
      details: { ip: req.ip }
    });

    logger.info('تم تعطيل المصادقة الثنائية (2FA).');
    res.json({ success: true, message: 'تم تعطيل المصادقة الثنائية بنجاح.' });
  });

  // 9. Logout
  router.all('/logout', (req, res) => {
    if (req.session?.user) {
      AuditLogRepository.createLog({
        guildId: 'SYSTEM',
        action: 'LOGOUT',
        moderatorId: req.session.user.id,
        moderatorTag: req.session.user.username,
        details: { ip: req.ip }
      });
    }

    req.session.destroy(() => {
      res.clearCookie('__Host-hireban_sid');
      res.clearCookie('connect.sid');
      if (req.method === 'GET') {
        return res.redirect('/');
      }
      res.json({ success: true });
    });
  });

  return router;
}

module.exports = createAuthRoutes;
