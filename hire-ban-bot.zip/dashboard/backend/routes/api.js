const express = require('express');
const { requireAuth } = require('../../../src/middleware/authMiddleware');
const AntiIdorGuard = require('../../../src/security/antiIdor');
const PermissionsGuard = require('../../../src/security/permissions');
const {
  banLimiter,
  unbanLimiter,
  settingsLimiter
} = require('../../../src/middleware/rateLimitMiddleware');
const {
  validateBody,
  validateParams,
  schemas
} = require('../../../src/middleware/validator');
const BanRepository = require('../../../src/database/repositories/banRepository');
const SettingsRepository = require('../../../src/database/repositories/settingsRepository');
const AuditLogRepository = require('../../../src/database/repositories/auditLogRepository');
const BanService = require('../../../src/services/banService');
const { parseDuration } = require('../../../src/utils/timeParser');
const logger = require('../../../src/utils/logger');

function createApiRoutes(discordClient) {
  const router = express.Router();

  // All API routes require session authentication
  router.use(requireAuth);

  // Guild scope verification middleware (Anti-IDOR with Live Discord Revalidation)
  const verifyGuild = AntiIdorGuard.verifyGuildAccess(discordClient);

  // 1. Guild Overview Stats
  router.get('/guilds/:guildId/stats', validateParams(schemas.guildIdParam), verifyGuild, (req, res) => {
    const { guildId } = req.params;
    const stats = BanRepository.getStats(guildId);

    const botStatus = {
      online: discordClient.isReady(),
      uptimeSeconds: Math.floor(discordClient.uptime / 1000) || 0,
      ping: discordClient.ws.ping || 0,
      guildCount: discordClient.guilds.cache.size,
      botTag: discordClient.user?.tag || 'Hire Ban Bot'
    };

    res.json({
      success: true,
      stats,
      botStatus,
      database: 'Connected (SQLite WAL)'
    });
  });

  // 2. Bans List (Paginated & Filtered)
  router.get('/guilds/:guildId/bans', validateParams(schemas.guildIdParam), verifyGuild, (req, res) => {
    const { guildId } = req.params;
    const { status, search, limit = 15, page = 1, sortBy = 'id', sortOrder = 'DESC' } = req.query;

    const parsedLimit = Math.min(Math.max(parseInt(limit, 10) || 15, 1), 100);
    const parsedPage = Math.max(parseInt(page, 10) || 1, 1);
    const offset = (parsedPage - 1) * parsedLimit;

    const result = BanRepository.listBans({
      guildId,
      status: status || null,
      search: search || '',
      limit: parsedLimit,
      offset,
      sortBy,
      sortOrder
    });

    res.json({
      success: true,
      ...result,
      page: parsedPage,
      totalPages: Math.ceil(result.total / parsedLimit) || 1
    });
  });

  // 3. Issue a Ban (Mutation with Zod Validation, Strict Permissions & Anti-IDOR)
  router.post('/guilds/:guildId/bans',
    validateParams(schemas.guildIdParam),
    verifyGuild,
    banLimiter,
    validateBody(schemas.createBan),
    async (req, res) => {
      const member = req.verifiedMember;
      const settings = req.guildSettings;

      if (!PermissionsGuard.canIssueBan(member, settings)) {
        AuditLogRepository.createLog({
          guildId: req.params.guildId,
          action: 'PERMISSION_DENIED_BAN',
          moderatorId: req.session.user.id,
          moderatorTag: req.session.user.username,
          details: { attemptedAction: 'ISSUE_BAN' }
        });
        return res.status(403).json({ error: 'ليس لديك صلاحية لإصدار عقوبة منع التوظيف في هذا السيرفر.' });
      }

      const { userId, durationValue, durationUnit, reason } = req.validatedBody;

      // Parse & Validate Duration
      const parsed = parseDuration(durationValue, durationUnit);
      if (parsed.error) {
        return res.status(400).json({ error: parsed.error });
      }

      if (parsed.isPermanent && !settings.allow_permanent_bans) {
        return res.status(400).json({ error: 'المنع الدائم معطل حالياً في إعدادات هذا السيرفر.' });
      }

      try {
        const banRecord = await BanService.issueBan({
          guild: req.verifiedGuild,
          targetUserId: userId,
          moderator: req.session.user,
          durationSeconds: parsed.seconds,
          reason
        });

        res.json({
          success: true,
          message: 'تم تطبيق منع التوظيف بنجاح.',
          ban: banRecord
        });
      } catch (err) {
        res.status(400).json({ error: err.message });
      }
    }
  );

  // 4. Revoke a Ban (Mutation with Zod Validation, Strict Permissions & Anti-IDOR)
  router.post('/guilds/:guildId/bans/:id/revoke',
    validateParams(schemas.guildIdParam),
    verifyGuild,
    unbanLimiter,
    AntiIdorGuard.verifyBanOwnership,
    validateBody(schemas.revokeBan),
    async (req, res) => {
      const member = req.verifiedMember;
      const settings = req.guildSettings;

      if (!PermissionsGuard.canRevokeBan(member, settings)) {
        AuditLogRepository.createLog({
          guildId: req.params.guildId,
          action: 'PERMISSION_DENIED_UNBAN',
          moderatorId: req.session.user.id,
          moderatorTag: req.session.user.username,
          details: { attemptedAction: 'REVOKE_BAN' }
        });
        return res.status(403).json({ error: 'ليس لديك صلاحية لإلغاء منع التوظيف في هذا السيرفر.' });
      }

      const ban = req.verifiedBan;
      const { reason } = req.validatedBody;

      try {
        const result = await BanService.revokeBan({
          guild: req.verifiedGuild,
          targetUserId: ban.user_id,
          moderator: req.session.user,
          reason
        });

        res.json({
          success: true,
          message: 'تم إلغاء منع التوظيف وإزالة الرول بنجاح.',
          banId: result.banId
        });
      } catch (err) {
        res.status(400).json({ error: err.message });
      }
    }
  );

  // 5. Extend / Modify Ban Duration (Mutation with Zod Validation & Anti-IDOR)
  router.post('/guilds/:guildId/bans/:id/extend',
    validateParams(schemas.guildIdParam),
    verifyGuild,
    unbanLimiter,
    AntiIdorGuard.verifyBanOwnership,
    validateBody(schemas.extendBan),
    async (req, res) => {
      const member = req.verifiedMember;
      const settings = req.guildSettings;

      if (!PermissionsGuard.canExtendBan(member, settings)) {
        return res.status(403).json({ error: 'ليس لديك صلاحية لتعديل مدة المنع في هذا السيرفر.' });
      }

      const ban = req.verifiedBan;
      const { durationValue, durationUnit, reason } = req.validatedBody;

      const parsed = parseDuration(durationValue, durationUnit);
      if (parsed.error) {
        return res.status(400).json({ error: parsed.error });
      }

      try {
        const result = await BanService.updateBanDuration({
          guild: req.verifiedGuild,
          banId: ban.id,
          moderator: req.session.user,
          newDurationSeconds: parsed.seconds,
          reason
        });

        res.json({
          success: true,
          message: 'تم تعديل مدة المنع بنجاح.',
          ...result
        });
      } catch (err) {
        res.status(400).json({ error: err.message });
      }
    }
  );

  // 6. Audit Logs
  router.get('/guilds/:guildId/logs', validateParams(schemas.guildIdParam), verifyGuild, (req, res) => {
    const member = req.verifiedMember;
    const settings = req.guildSettings;

    if (!PermissionsGuard.canViewLogs(member, settings)) {
      return res.status(403).json({ error: 'ليس لديك صلاحية لعرض سجلات هذا السيرفر.' });
    }

    const { guildId } = req.params;
    const { action, search, fromDate, toDate, page = 1, limit = 25 } = req.query;

    const parsedLimit = Math.min(Math.max(parseInt(limit, 10) || 25, 1), 100);
    const parsedPage = Math.max(parseInt(page, 10) || 1, 1);
    const offset = (parsedPage - 1) * parsedLimit;

    const result = AuditLogRepository.listLogs({
      guildId,
      action: action || null,
      search: search || '',
      fromDate: fromDate || null,
      toDate: toDate || null,
      limit: parsedLimit,
      offset
    });

    res.json({
      success: true,
      ...result,
      page: parsedPage,
      totalPages: Math.ceil(result.total / parsedLimit) || 1
    });
  });

  // 7. Export Audit Logs CSV
  router.get('/guilds/:guildId/logs/export', validateParams(schemas.guildIdParam), verifyGuild, (req, res) => {
    const member = req.verifiedMember;
    const settings = req.guildSettings;

    if (!PermissionsGuard.canViewLogs(member, settings)) {
      return res.status(403).json({ error: 'ليس لديك صلاحية لتصدير السجلات.' });
    }

    const { guildId } = req.params;
    const csvData = AuditLogRepository.exportLogsCsv(guildId);

    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader('Content-Disposition', `attachment; filename="hire_ban_logs_${guildId}_${Date.now()}.csv"`);
    res.send('\uFEFF' + csvData);
  });

  // 8. Guild Settings (Read)
  router.get('/guilds/:guildId/settings', validateParams(schemas.guildIdParam), verifyGuild, (req, res) => {
    res.json({
      success: true,
      settings: req.guildSettings
    });
  });

  // 9. Update Guild Settings (Strict Validation of Roles & Channels in Discord)
  router.post('/guilds/:guildId/settings',
    validateParams(schemas.guildIdParam),
    verifyGuild,
    settingsLimiter,
    validateBody(schemas.settings),
    (req, res) => {
      const member = req.verifiedMember;
      const settings = req.guildSettings;
      const guild = req.verifiedGuild;

      if (!PermissionsGuard.canManageSettings(member, settings)) {
        return res.status(403).json({ error: 'ليس لديك صلاحية لتعديل إعدادات هذا السيرفر.' });
      }

      const {
        admin_channel_id,
        citizen_channel_id,
        log_channel_id,
        ban_role_id,
        allowed_roles,
        cancel_roles,
        dashboard_roles,
        allow_permanent_bans,
        notification_settings
      } = req.validatedBody;

      // 1. Pre-validate ban_role_id if configured
      if (ban_role_id) {
        const role = guild.roles.cache.get(ban_role_id);
        if (!role) {
          return res.status(400).json({ error: 'رتبة منع التوظيف المحددة غير موجودة في هذا السيرفر.' });
        }
        if (role.id === guild.id) {
          return res.status(400).json({ error: 'لا يمكن اختيار رتبة @everyone كرتبة منع توظيف.' });
        }
        if (role.managed) {
          return res.status(400).json({ error: 'رتبة منع التوظيف المحددة تتبع تطبيقاً أو بوت آخر (Managed Role) ولا يمكن إدارتها.' });
        }
        const botMember = guild.members?.me;
        if (botMember && botMember.roles.highest.position <= role.position) {
          return res.status(400).json({
            error: `رتبة منع التوظيف (${role.name}) أعلى من رتبة البوت (${botMember.roles.highest.name}) في ترتيب الرتب. يرجى رفع رتبة البوت في إعدادات السيرفر أولاً.`
          });
        }
      }

      // 2. Pre-validate channels if configured
      const channelsToCheck = [
        { id: admin_channel_id, name: 'روم الإدارة' },
        { id: citizen_channel_id, name: 'روم المواطنين' },
        { id: log_channel_id, name: 'روم السجلات' }
      ];

      for (const ch of channelsToCheck) {
        if (ch.id) {
          const channel = guild.channels.cache.get(ch.id);
          if (!channel) {
            return res.status(400).json({ error: `القناة المحددة لـ (${ch.name}) غير موجودة في السيرفر.` });
          }
          if (channel.isTextBased && !channel.isTextBased()) {
            return res.status(400).json({ error: `القناة المحددة لـ (${ch.name}) يجب أن تكون قناة كتابية (Text Channel).` });
          }
        }
      }

      const updated = SettingsRepository.saveSettings(req.params.guildId, {
        admin_channel_id,
        citizen_channel_id,
        log_channel_id,
        ban_role_id,
        allowed_roles,
        cancel_roles,
        dashboard_roles,
        allow_permanent_bans,
        notification_settings
      });

      // Write audit log
      AuditLogRepository.createLog({
        guildId: req.params.guildId,
        action: 'SETTINGS_UPDATED',
        moderatorId: req.session.user.id,
        moderatorTag: req.session.user.username,
        details: { updatedSettings: updated }
      });

      res.json({
        success: true,
        message: 'تم حفظ وتحديث الإعدادات بنجاح.',
        settings: updated
      });
    }
  );

  // 10. Fetch Real Discord Roles for Select Pickers
  router.get('/guilds/:guildId/discord-roles', validateParams(schemas.guildIdParam), verifyGuild, async (req, res) => {
    try {
      const guild = req.verifiedGuild;
      const rolesCollection = await guild.roles.fetch().catch(() => guild.roles.cache);
      const roles = Array.from(rolesCollection.values())
        .filter(r => r.id !== guild.id) // exclude @everyone
        .map(r => ({
          id: r.id,
          name: r.name,
          color: r.hexColor,
          position: r.position,
          managed: r.managed
        }))
        .sort((a, b) => b.position - a.position);

      res.json({ success: true, roles });
    } catch (err) {
      logger.error('فشل جلب رتب السيرفر:', err);
      res.status(500).json({ success: false, error: 'تعذر جلب رتب السيرفر من ديسكورد' });
    }
  });

  // 11. Fetch Real Discord Channels for Select Pickers
  router.get('/guilds/:guildId/discord-channels', validateParams(schemas.guildIdParam), verifyGuild, async (req, res) => {
    try {
      const guild = req.verifiedGuild;
      const channelsCollection = await guild.channels.fetch().catch(() => guild.channels.cache);
      const channels = Array.from(channelsCollection.values())
        .filter(c => c && c.isTextBased && c.isTextBased())
        .map(c => ({
          id: c.id,
          name: c.name,
          type: c.type,
          parentName: c.parent ? c.parent.name : null
        }))
        .sort((a, b) => a.name.localeCompare(b.name));

      res.json({ success: true, channels });
    } catch (err) {
      logger.error('فشل جلب قنوات السيرفر:', err);
      res.status(500).json({ success: false, error: 'تعذر جلب قنوات السيرفر من ديسكورد' });
    }
  });

  // 12. Staff Members List
  router.get('/guilds/:guildId/staff', validateParams(schemas.guildIdParam), verifyGuild, (req, res) => {
    const guild = req.verifiedGuild;
    const settings = req.guildSettings;

    const staffRoleIds = new Set([
      ...(settings.allowed_roles || []),
      ...(settings.cancel_roles || []),
      ...(settings.dashboard_roles || [])
    ]);

    const staffMembers = [];

    for (const [id, member] of guild.members.cache) {
      if (member.user.bot) continue;

      const isOwner = member.id === guild.ownerId;
      const isAdmin = member.permissions?.has ? member.permissions.has(8n) : false;
      const matchedRoles = member.roles.cache.filter(r => staffRoleIds.has(r.id));

      if (isOwner || isAdmin || matchedRoles.size > 0) {
        staffMembers.push({
          id: member.id,
          username: member.user.username,
          tag: member.user.tag || member.user.username,
          avatar: typeof member.user.displayAvatarURL === 'function' ? member.user.displayAvatarURL({ dynamic: true }) : null,
          isOwner,
          isAdmin,
          roles: member.roles.cache.filter(r => r.id !== guild.id).map(r => ({ id: r.id, name: r.name, color: r.hexColor })),
          canIssueBan: PermissionsGuard.canIssueBan(member, settings),
          canRevokeBan: PermissionsGuard.canRevokeBan(member, settings),
          canManageSettings: PermissionsGuard.canManageSettings(member, settings)
        });
      }
    }

    res.json({ success: true, staff: staffMembers });
  });

  // 13. Detailed Analytics for Charts
  router.get('/guilds/:guildId/analytics', validateParams(schemas.guildIdParam), verifyGuild, (req, res) => {
    const { guildId } = req.params;
    const analytics = BanRepository.getAnalytics(guildId);
    res.json({ success: true, analytics });
  });

  return router;
}

module.exports = createApiRoutes;
