const rateLimit = require('express-rate-limit');

// General API Rate Limiter: 120 requests per minute
const apiLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 120,
  standardHeaders: true,
  legacyHeaders: false,
  validate: { trustProxy: false },
  message: { error: 'تم تجاوز الحد المسموح من الطلبات، يرجى المحاولة بعد قليل.' }
});

// Sensitive action limiter (Ban creation, revoking, settings modification): 20 requests per minute
const sensitiveActionLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 25,
  standardHeaders: true,
  legacyHeaders: false,
  validate: { trustProxy: false },
  message: { error: 'لقد قمت بعدد كبير من العمليات في وقت قصير، يرجى الانتظار دقيقة.' }
});

// Auth / Login limiter: 15 attempts per 5 minutes
const authLimiter = rateLimit({
  windowMs: 5 * 60 * 1000,
  max: 30,
  standardHeaders: true,
  legacyHeaders: false,
  validate: { trustProxy: false },
  message: { error: 'تم تكرار محاولات تسجيل الدخول، يرجى الانتظار 5 دقائق.' }
});

module.exports = {
  apiLimiter,
  sensitiveActionLimiter,
  authLimiter
};
