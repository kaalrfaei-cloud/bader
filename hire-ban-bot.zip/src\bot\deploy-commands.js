require('dotenv').config();
const { REST, Routes } = require('discord.js');
const fs = require('fs');
const path = require('path');
const logger = require('../utils/logger');

async function deployCommands() {
  const token = process.env.DISCORD_TOKEN;
  const clientId = process.env.DISCORD_CLIENT_ID;
  const guildId = process.env.DISCORD_GUILD_ID;

  if (!token || !clientId) {
    logger.error('يرجى التأكد من ملء DISCORD_TOKEN و DISCORD_CLIENT_ID في ملف .env');
    return false;
  }

  const commands = [];
  const commandsPath = path.join(__dirname, 'commands');
  const commandFiles = fs.readdirSync(commandsPath).filter(file => file.endsWith('.js'));

  for (const file of commandFiles) {
    const filePath = path.join(commandsPath, file);
    const command = require(filePath);
    if (command.data) {
      commands.push(command.data.toJSON());
    }
  }

  const rest = new REST({ version: '10' }).setToken(token);

  try {
    logger.info(`جاري تسجيل ${commands.length} أمر (Slash Commands)...`);

    if (guildId) {
      // Fast guild registration (instant update for testing/private server)
      await rest.put(
        Routes.applicationGuildCommands(clientId, guildId),
        { body: commands }
      );
      logger.success(`تم تسجيل الأوامر بنجاح لسيرفر الاختبار المحدد (Guild: ${guildId}).`);
    } else {
      // Global registration
      await rest.put(
        Routes.applicationCommands(clientId),
        { body: commands }
      );
      logger.success('تم تسجيل الأوامر بنجاح بشكل عام (Global) على جميع السيرفرات.');
    }
    return true;
  } catch (error) {
    logger.error('حدث خطأ أثناء تسجيل الأوامر:', error.message);
    return false;
  }
}

if (require.main === module) {
  deployCommands();
}

module.exports = { deployCommands };
