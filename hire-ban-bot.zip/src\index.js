require('dotenv').config();
const { initDatabase, closeDatabase } = require('./database/db');
const { createDiscordClient } = require('./bot/client');
const { createDashboardServer } = require('../dashboard/backend/server');
const logger = require('./utils/logger');

// Global error handlers to prevent silent crashes
process.on('unhandledRejection', (reason, promise) => {
  logger.error('Unhandled Promise Rejection:', reason);
});

process.on('uncaughtException', (error) => {
  logger.error('Uncaught Exception:', error.stack || error.message);
});

async function bootstrap() {
  logger.info('=== جاري تشغيل بوت منع التوظيف (Hire Ban Bot) ===');

  // 1. Initialize SQLite Database
  initDatabase();

  // 2. Initialize Discord Client
  const client = createDiscordClient();

  // 3. Initialize Dashboard Server
  const app = createDashboardServer(client);
  const PORT = process.env.PORT || 3000;

  const server = app.listen(PORT, () => {
    logger.success(`لوحة التحكم (Dashboard) تعمل على الرابط: http://localhost:${PORT}`);
  });

  // 4. Log in Discord Bot (if token provided)
  const token = process.env.DISCORD_TOKEN;
  if (token && token !== 'your_discord_bot_token_here') {
    try {
      await client.login(token);
    } catch (err) {
      logger.error('فشل تسجيل دخول البوت إلى Discord:', err.message);
      logger.warn('تأكد من صحة التوكن في ملف .env وتفعيل خيارات Intents في بوابة مطوري ديسكورد.');
    }
  } else {
    logger.warn('لم يتم العثور على DISCORD_TOKEN في ملف .env. يعمل خادم الداشبورد بوضع الاستعداد.');
  }

  // Graceful shutdown
  const shutdown = async () => {
    logger.info('جاري إيقاف الخادم والخدمات بأمان...');
    if (client.scheduler) {
      client.scheduler.stop();
    }
    server.close();
    closeDatabase();
    await client.destroy();
    process.exit(0);
  };

  process.on('SIGINT', shutdown);
  process.on('SIGTERM', shutdown);
}

bootstrap().catch(err => {
  logger.error('فشل بدء تشغيل التطبيق:', err);
  process.exit(1);
});
