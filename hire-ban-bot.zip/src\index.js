require('dotenv').config();
const { initDatabase, closeDatabase } = require('./database/db');
const { createDiscordClient } = require('./bot/client');
const { createDashboardServer } = require('../dashboard/backend/server');
const StartupValidator = require('./security/startupValidator');
const { resolveBotToken } = require('./utils/securityCipher');
const logger = require('./utils/logger');

// Global error handlers to prevent silent crashes
process.on('unhandledRejection', (reason, promise) => {
  logger.error('[Global] Unhandled Promise Rejection:', reason);
});

process.on('uncaughtException', (error) => {
  logger.error('[Global] Uncaught Exception:', error.stack || error.message);
});

async function bootstrap() {
  logger.info('=== جاري تشغيل بوت منع التوظيف (Hire Ban Bot) ===');

  // 1. Startup Configuration & Environment Security Audit
  logger.info('🔐 جاري التحقق من الإعدادات الأمنية ومفاتيح التشفير...');
  const envValidation = StartupValidator.validateEnvironment();

  for (const warning of envValidation.warnings) {
    logger.warn(`⚠️ [تنبيه أمني]: ${warning}`);
  }

  if (!envValidation.isValid) {
    logger.warn('⚠️ تم رصد ملاحظات أثناء فحص الإعدادات الأساسية:');
    for (const error of envValidation.errors) {
      logger.warn(`   🛑 ${error}`);
    }
  } else {
    logger.success('✅ كافة الإعدادات الأمنية ومفاتيح التشفير مطابقة للمعايير القياسية.');
  }

  // 2. Initialize SQLite Database
  initDatabase();

  // 3. Initialize Discord Client
  const client = createDiscordClient();

  // Hook Discord ready event for state & permissions validation
  client.once('ready', async () => {
    await StartupValidator.validateDiscordState(client);
  });

  // 4. Initialize Dashboard Server
  const app = createDashboardServer(client);
  const PORT = process.env.PORT || 3000;

  const server = app.listen(PORT, '0.0.0.0', () => {
    logger.success(`لوحة التحكم (Dashboard) تعمل على الرابط: http://0.0.0.0:${PORT}`);
  });

  // 5. 24/7 Keep-Alive Worker (Prevents Render / free hosts from sleeping)
  const KeepAliveService = require('./services/keepAliveService');
  KeepAliveService.start();

  // 6. Log in Discord Bot with Auto-Intent Fallback & Dual-Token Recovery
  let token = '';
  try {
    token = resolveBotToken();
  } catch (err) {
    logger.error('فشل استرجاع التوكن:', err.message);
  }

  const { decryptEmbeddedToken } = require('./utils/securityCipher');
  const embeddedToken = decryptEmbeddedToken();

  async function attemptLogin(targetToken, tokenName = 'المعتمد') {
    if (!targetToken) return false;
    try {
      client._loginDiagnostic = { status: 'attempting', tokenName };
      await client.login(targetToken);
      client._loginDiagnostic = { status: 'online', botUser: client.user?.tag, tokenName };
      logger.success(`✅ تم تسجيل دخول البوت بنجاح بالتوكن (${tokenName}): ${client.user.tag}`);
      return true;
    } catch (err) {
      logger.error(`فشل تسجيل دخول البوت بالتوكن (${tokenName}): ${err.message} (${err.code || 'NO_CODE'})`);
      client._loginDiagnostic = { status: 'error', message: err.message, code: err.code, tokenName };

      // Case: Privileged Intents Disallowed (Switches in Developer Portal not enabled)
      if (err.code === 'DisallowedIntents' || (err.message && err.message.toLowerCase().includes('intent'))) {
        logger.warn('⚠️ تم رفض الصلاحيات الموسعة (Privileged Intents) من ديسكورد! جاري إعادة الاتصال تلقائياً بالصلاحيات الأساسية...');
        try {
          client.options.intents = [1]; // GatewayIntentBits.Guilds = 1
          await client.login(targetToken);
          client._loginDiagnostic = { status: 'online_basic_intents', botUser: client.user?.tag, tokenName };
          logger.success(`✅ تم تشغيل البوت أونلاين بنجاح بالصلاحيات الأساسية! (${client.user.tag})`);
          return true;
        } catch (basicErr) {
          logger.error('فشل الاتصال بالصلاحيات الأساسية أيضاً:', basicErr.message);
        }
      }
      return false;
    }
  }

  let loggedIn = await attemptLogin(token, 'البيئة/الافتراضي');
  if (!loggedIn && embeddedToken && embeddedToken !== token) {
    logger.info('🔄 محاولة ثانية بالتوكن المشفر المدمج...');
    loggedIn = await attemptLogin(embeddedToken, 'المشفر المدمج');
  }

  if (!loggedIn) {
    logger.warn('لم يتمكن البوت من الاتصال بديسكورد. يعمل خادم الداشبورد بوضع الاستعداد.');
  }

  // Graceful shutdown
  const shutdown = async () => {
    logger.info('جاري إيقاف الخادم والخدمات بأمان...');
    if (client.scheduler) {
      client.scheduler.stop();
    }
    server.close();
    closeDatabase();
    await client.destroy();
    process.exit(0);
  };

  process.on('SIGINT', shutdown);
  process.on('SIGTERM', shutdown);
}

bootstrap().catch(err => {
  logger.error('فشل بدء تشغيل التطبيق:', err);
  process.exit(1);
});
