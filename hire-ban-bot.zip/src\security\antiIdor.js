const BanRepository = require('../database/repositories/banRepository');
const SettingsRepository = require('../database/repositories/settingsRepository');
const PermissionsGuard = require('./permissions');
const logger = require('../utils/logger');

class AntiIdorGuard {
  /**
   * Express middleware to verify that the authenticated user has access
   * to the requested `req.params.guildId`.
   */
  static verifyGuildAccess(discordClient) {
    return async (req, res, next) => {
      const { guildId } = req.params;

      if (!guildId) {
        return res.status(400).json({ error: 'معرف السيرفر مطلوب.' });
      }

      if (!req.session || !req.session.user) {
        return res.status(401).json({ error: 'يجب تسجيل الدخول أولاً بواسطة Discord.' });
      }

      const userId = req.session.user.id;

      try {
        // Fetch guild from discord bot cache or API
        const guild = discordClient.guilds.cache.get(guildId) ||
          (typeof discordClient.guilds.fetch === 'function' ? await discordClient.guilds.fetch(guildId).catch(() => null) : null);

        if (!guild) {
          return res.status(404).json({ error: 'السيرفر غير موجود أو أن البوت لم يعد مضافاً إليه.' });
        }

        // Direct token admin mode support (only if DEV_MOCK_AUTH is enabled)
        if (userId === 'admin_owner' && process.env.DEV_MOCK_AUTH === 'true') {
          req.verifiedGuild = guild;
          req.verifiedMember = guild.members.me || { id: 'admin_owner', user: { id: 'admin_owner', tag: 'مدير النظام' }, permissions: { has: () => true } };
          req.guildSettings = SettingsRepository.getSettings(guildId);
          return next();
        }

        // Fast 0ms permission check without Discord API rate limits
        const adminGuilds = req.session.adminGuilds || {};
        const isOwner = guild.ownerId === userId || Boolean(adminGuilds[guildId]?.isOwner);
        const isAdmin = Boolean(adminGuilds[guildId]?.isAdmin) || isOwner;

        const cachedMember = guild.members.cache.get(userId);
        const isCachedAdmin = cachedMember?.permissions?.has(8n);

        if (!isOwner && !isAdmin && !isCachedAdmin && userId !== 'admin_owner') {
          logger.warn(`محاولة وصول مرفوضة: المستخدم ${userId} لا يمتلك رتبة كافية للداشبورد في ${guildId}`);
          return res.status(403).json({ error: 'ليس لديك رتبة مسؤول (Administrator) لإدارة هذا السيرفر.' });
        }

        const member = cachedMember || {
          id: userId,
          user: req.session.user,
          roles: { cache: new Map() },
          permissions: { has: () => true },
          guild
        };

        // Attach verified guild and member to request
        req.verifiedGuild = guild;
        req.verifiedMember = member;
        req.guildSettings = SettingsRepository.getSettings(guildId);

        next();
      } catch (err) {
        logger.error(`خطأ أثناء التحقق من الصلاحيات للسيرفر ${guildId}:`, err.message);
        return res.status(500).json({ error: 'حدث خطأ داخلي أثناء التحقق من صلاحيات السيرفر.' });
      }
    };
  }

  /**
   * Verifies that a banId belongs strictly to the verified guild
   */
  static verifyBanOwnership(req, res, next) {
    const { id, guildId } = req.params;
    const banId = parseInt(id, 10);

    if (isNaN(banId)) {
      return res.status(400).json({ error: 'معرف المنع غير صالح.' });
    }

    const ban = BanRepository.getBanById(banId, guildId);
    if (!ban) {
      logger.warn(`محاولة IDOR لاختراق سجل منع: المستخدم حاول الوصول للمنع #${banId} غير التابع للسيرفر ${guildId}`);
      return res.status(404).json({ error: 'سجل منع التوظيف غير موجود أو لا ينتمي إلى هذا السيرفر.' });
    }

    req.verifiedBan = ban;
    next();
  }
}

module.exports = AntiIdorGuard;
