const BanRepository = require('../database/repositories/banRepository');
const SettingsRepository = require('../database/repositories/settingsRepository');
const AuditLogRepository = require('../database/repositories/auditLogRepository');
const HierarchyGuard = require('../security/hierarchy');
const PermissionsGuard = require('../security/permissions');
const LockManager = require('../security/lockManager');
const NotificationService = require('./notificationService');
const { retryWithBackoff } = require('../utils/retryHelper');
const { calculateExpiresAt, formatDuration } = require('../utils/timeParser');
const logger = require('../utils/logger');

class BanService {
  /**
   * Issue a hire ban with transactional State Machine (PENDING -> Add Role -> ACTIVE)
   */
  static async issueBan({ guild, targetUserId, moderator, durationSeconds, reason }) {
    const lockKey = `${guild.id}:${targetUserId}`;

    return await LockManager.withLock(lockKey, 10000, async () => {
      // 1. Fetch settings
      const settings = SettingsRepository.getSettings(guild.id);

      // Check if permanent bans are allowed
      if (durationSeconds === null && !settings.allow_permanent_bans) {
        throw new Error('المنع الدائم معطل حالياً في إعدادات هذا السيرفر.');
      }

      // 2. Fetch target member if in guild
      let targetMember = null;
      let targetUser = null;
      try {
        targetMember = guild.members.cache.get(targetUserId) || await guild.members.fetch(targetUserId).catch(() => null);
        if (targetMember) {
          targetUser = targetMember.user;
        } else {
          // If member is not in guild, fetch user object from client
          targetUser = await guild.client.users.fetch(targetUserId).catch(() => null);
        }
      } catch (err) {
        logger.warn(`تعذر جلب بيانات العضو ${targetUserId}: ${err.message}`);
      }

      const userTag = targetUser ? (targetUser.tag || targetUser.username) : `مستخدم [${targetUserId}]`;
      const modTag = moderator ? (moderator.tag || moderator.user?.tag || moderator.user?.username || moderator.username || 'إداري') : 'النظام';
      const modId = moderator ? (moderator.id || moderator.user?.id) : 'SYSTEM';

      // 3. Hierarchy & Permission Validation
      const hierarchyCheck = HierarchyGuard.validate(guild, settings.ban_role_id, targetMember);
      if (!hierarchyCheck.valid) {
        const err = new Error(hierarchyCheck.error);
        err.code = 'HIERARCHY_VIOLATION';
        throw err;
      }

      // 4. Check if active or pending ban already exists in DB
      const existing = BanRepository.getActiveBan(guild.id, targetUserId);
      if (existing) {
        const err = new Error('العضو لديه منع نشط مسبقاً في السيرفر.');
        err.code = 'ACTIVE_BAN_EXISTS';
        throw err;
      }

      // 5. Calculate expiration timestamp
      const now = new Date().toISOString();
      const expiresAt = calculateExpiresAt(durationSeconds);

      // 6. Step 1: Create Ban Record with status 'PENDING'
      const banRecord = BanRepository.createBan({
        guild_id: guild.id,
        user_id: targetUserId,
        user_tag: userTag,
        reason: reason || 'لا يوجد سبب محدد',
        moderator_id: modId,
        moderator_tag: modTag,
        duration_seconds: durationSeconds,
        created_at: now,
        expires_at: expiresAt,
        status: 'PENDING'
      });

      // 7. Step 2: Assign Ban Role in Discord with Retry
      let roleAssigned = false;
      if (targetMember && hierarchyCheck.role) {
        try {
          await retryWithBackoff(async () => {
            await targetMember.roles.add(
              hierarchyCheck.role,
              `منع توظيف بواسطة ${modTag} - السبب: ${reason || 'غير محدد'}`
            );
          }, {
            maxRetries: 3,
            initialDelayMs: 300,
            operationName: `Add Ban Role to ${userTag}`
          });
          roleAssigned = true;
          logger.info(`تم إعطاء رول منع التوظيف للعضو ${userTag} في السيرفر ${guild.name}`);
        } catch (roleErr) {
          logger.error(`[Security Logs] فشل إعطاء رول منع التوظيف للعضو ${targetUserId}: ${roleErr.message}`);

          // Role failed after retries -> fail and clean pending record so no ghost active ban remains
          BanRepository.failBan(banRecord.id, `Discord Role Failure: ${roleErr.message}`);

          AuditLogRepository.createLog({
            guildId: guild.id,
            action: 'BAN_FAILED',
            targetUserId,
            targetUserTag: userTag,
            moderatorId: modId,
            moderatorTag: modTag,
            details: {
              banId: banRecord.id,
              error: roleErr.message,
              result: 'FAILED'
            }
          });

          await NotificationService.notifySystemError(guild, {
            action: 'إعطاء رول منع التوظيف',
            error: roleErr.message,
            targetUserId
          });

          const customErr = new Error('حدث خطأ أثناء تطبيق رتبة منع التوظيف في الديسكورد، يرجى التحقق من صلاحيات البوت والمحاولة مجدداً.');
          customErr.code = 'DISCORD_ROLE_FAILED';
          throw customErr;
        }
      }

      // 8. Step 3: Discord Success -> Transition to ACTIVE
      BanRepository.activateBan(banRecord.id);
      banRecord.status = 'ACTIVE';

      // 9. Create Audit Log entry (SUCCESS)
      AuditLogRepository.createLog({
        guildId: guild.id,
        action: 'BAN_ISSUED',
        targetUserId,
        targetUserTag: userTag,
        moderatorId: modId,
        moderatorTag: modTag,
        details: {
          banId: banRecord.id,
          reason,
          durationSeconds,
          expiresAt,
          roleAssigned,
          result: 'SUCCESS'
        }
      });

      // 10. Send Discord Notifications
      await NotificationService.notifyBanIssued(guild, {
        user: targetUser || { id: targetUserId, tag: userTag, displayAvatarURL: () => null },
        moderator: { id: modId, tag: modTag },
        reason,
        durationSeconds,
        expiresAt,
        banId: banRecord.id
      });

      return banRecord;
    });
  }

  /**
   * Revoke an active hire ban with transactional State Machine (ACTIVE -> REVOKING -> Remove Role -> REVOKED)
   */
  static async revokeBan({ guild, targetUserId, moderator, reason }) {
    const lockKey = `${guild.id}:${targetUserId}`;

    return await LockManager.withLock(lockKey, 10000, async () => {
      // 1. Get active ban
      const activeBan = BanRepository.getActiveBan(guild.id, targetUserId);
      if (!activeBan) {
        const err = new Error('لا يوجد منع توظيف نشط لهذا العضو لإلغائه.');
        err.code = 'NO_ACTIVE_BAN';
        throw err;
      }

      const settings = SettingsRepository.getSettings(guild.id);
      const modTag = moderator ? (moderator.tag || moderator.user?.tag || moderator.user?.username || moderator.username || 'إداري') : 'النظام';
      const modId = moderator ? (moderator.id || moderator.user?.id) : 'SYSTEM';

      // 2. Fetch member if present
      let targetMember = null;
      let targetUser = null;
      try {
        targetMember = guild.members.cache.get(targetUserId) || await guild.members.fetch(targetUserId).catch(() => null);
        if (targetMember) {
          targetUser = targetMember.user;
        } else {
          targetUser = await guild.client.users.fetch(targetUserId).catch(() => null);
        }
      } catch (err) {
        logger.warn(`تعذر جلب بيانات العضو ${targetUserId}: ${err.message}`);
      }

      const userTag = targetUser ? (targetUser.tag || targetUser.username) : activeBan.user_tag;

      // 3. Step 1: Transition ban to REVOKING status
      BanRepository.startRevoke(activeBan.id);

      // 4. Step 2: Remove Ban Role from member with Retry
      let roleRemoved = false;
      if (settings.ban_role_id) {
        const role = guild.roles.cache.get(settings.ban_role_id);
        if (role && targetMember && targetMember.roles.cache.has(role.id)) {
          try {
            await retryWithBackoff(async () => {
              await targetMember.roles.remove(role, `إلغاء منع التوظيف بواسطة ${modTag} - السبب: ${reason || 'غير محدد'}`);
            }, {
              maxRetries: 3,
              initialDelayMs: 300,
              operationName: `Remove Ban Role from ${userTag}`
            });
            roleRemoved = true;
            logger.info(`تمت إزالة رول منع التوظيف عن ${userTag}`);
          } catch (roleErr) {
            logger.error(`[Security Logs] فشل إزالة الرول عن العضو ${targetUserId} بعد المحاولات: ${roleErr.message}`);

            // Rollback status to ACTIVE so it remains tracked
            BanRepository.cancelRevoke(activeBan.id);

            AuditLogRepository.createLog({
              guildId: guild.id,
              action: 'UNBAN_FAILED',
              targetUserId,
              targetUserTag: userTag,
              moderatorId: modId,
              moderatorTag: modTag,
              details: {
                banId: activeBan.id,
                error: roleErr.message,
                result: 'FAILED'
              }
            });

            await NotificationService.notifySystemError(guild, {
              action: 'إزالة رول منع التوظيف (إلغاء يدوي)',
              error: roleErr.message,
              targetUserId
            });

            const unbanErr = new Error('حدث خطأ أثناء إزالة رتبة منع التوظيف في الديسكورد، يرجى مراجعة الصلاحيات والمحاولة مجدداً.');
            unbanErr.code = 'DISCORD_ROLE_REMOVE_FAILED';
            throw unbanErr;
          }
        }
      }

      // 5. Step 3: Discord Success -> Transition to REVOKED
      BanRepository.revokeBan(activeBan.id, guild.id, modId, modTag, reason);

      // 6. Create Audit Log
      AuditLogRepository.createLog({
        guildId: guild.id,
        action: 'BAN_REVOKED',
        targetUserId,
        targetUserTag: userTag,
        moderatorId: modId,
        moderatorTag: modTag,
        details: {
          banId: activeBan.id,
          reason,
          roleRemoved,
          result: 'SUCCESS'
        }
      });

      // 7. Notify log channel
      await NotificationService.notifyBanRevoked(guild, {
        user: targetUser || { id: targetUserId, tag: userTag },
        moderator: { id: modId, tag: modTag },
        reason,
        banId: activeBan.id
      });

      return { success: true, banId: activeBan.id };
    });
  }

  /**
   * Update ban duration (extend or shorten)
   */
  static async updateBanDuration({ guild, banId, moderator, newDurationSeconds, reason }) {
    const ban = BanRepository.getBanById(banId, guild.id);
    if (!ban || ban.status !== 'ACTIVE') {
      throw new Error('سجل المنع غير موجود أو غير نشط.');
    }

    const newExpiresAt = calculateExpiresAt(newDurationSeconds);
    const modTag = moderator ? (moderator.tag || moderator.user?.tag || moderator.user?.username || 'إداري') : 'النظام';
    const modId = moderator ? (moderator.id || moderator.user?.id) : 'SYSTEM';

    BanRepository.updateBanDuration(banId, guild.id, newDurationSeconds, newExpiresAt);

    AuditLogRepository.createLog({
      guildId: guild.id,
      action: newDurationSeconds > (ban.duration_seconds || 0) ? 'BAN_EXTENDED' : 'BAN_SHORTENED',
      targetUserId: ban.user_id,
      targetUserTag: ban.user_tag,
      moderatorId: modId,
      moderatorTag: modTag,
      details: {
        banId,
        previousExpiresAt: ban.expires_at,
        newExpiresAt,
        newDurationSeconds,
        reason,
        result: 'SUCCESS'
      }
    });

    return { success: true, newExpiresAt, newDurationSeconds };
  }

  /**
   * Handle member rejoin event:
   * If member has an active ban whose expires_at is in the future (or permanent),
   * re-assign the Ban Role and log it.
   */
  static async handleRejoiningMember(member) {
    const guild = member.guild;
    const userId = member.id;

    try {
      const activeBan = BanRepository.getActiveBan(guild.id, userId);
      if (!activeBan) return;

      // Check if ban expired while member was outside
      if (activeBan.expires_at) {
        const expiresTime = new Date(activeBan.expires_at).getTime();
        const now = Date.now();
        if (expiresTime <= now) {
          // Expired while outside, mark expired in DB and DO NOT give role
          BanRepository.markExpired(activeBan.id);
          AuditLogRepository.createLog({
            guildId: guild.id,
            action: 'BAN_EXPIRED',
            targetUserId: userId,
            targetUserTag: member.user.tag || member.user.username,
            moderatorId: 'SYSTEM',
            moderatorTag: 'المجدول التلقائي',
            details: {
              banId: activeBan.id,
              note: 'انتهت مدة المنع أثناء وجود العضو خارج السيرفر',
              result: 'SUCCESS'
            }
          });
          return;
        }
      }

      // The ban is still active! Re-assign the role
      const settings = SettingsRepository.getSettings(guild.id);
      if (!settings.ban_role_id) return;

      const role = guild.roles.cache.get(settings.ban_role_id);
      if (!role) return;

      const hierarchyCheck = HierarchyGuard.validate(guild, settings.ban_role_id, member);
      if (hierarchyCheck.valid) {
        await retryWithBackoff(async () => {
          await member.roles.add(role, 'إعادة تطبيق منع التوظيف النشط تلقائياً عند عودة العضو للسيرفر');
        }, {
          maxRetries: 3,
          initialDelayMs: 300,
          operationName: `Re-assign Ban Role to ${member.user.tag}`
        });

        logger.info(`تمت إعادة رول منع التوظيف للعضو ${member.user.tag} عند عودته للسيرفر.`);

        // Audit Log
        AuditLogRepository.createLog({
          guildId: guild.id,
          action: 'MEMBER_REJOIN',
          targetUserId: userId,
          targetUserTag: member.user.tag || member.user.username,
          moderatorId: 'SYSTEM',
          moderatorTag: 'نظام الحماية',
          details: {
            banId: activeBan.id,
            expiresAt: activeBan.expires_at,
            result: 'SUCCESS'
          }
        });

        // Discord Notification
        await NotificationService.notifyMemberRejoin(guild, {
          user: member.user,
          banId: activeBan.id,
          expiresAt: activeBan.expires_at
        });
      } else {
        logger.warn(`تعذر إعادة الرول للعضو العائد ${member.user.tag}: ${hierarchyCheck.error}`);
      }
    } catch (err) {
      logger.error(`خطأ أثناء معالجة عودة العضو ${member.id}: ${err.message}`);
    }
  }
}

module.exports = BanService;
