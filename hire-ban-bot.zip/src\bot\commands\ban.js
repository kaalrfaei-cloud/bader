const {
  SlashCommandBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ComponentType
} = require('discord.js');
const PermissionsGuard = require('../../security/permissions');
const HierarchyGuard = require('../../security/hierarchy');
const SettingsRepository = require('../../database/repositories/settingsRepository');
const BanRepository = require('../../database/repositories/banRepository');
const BanService = require('../../services/banService');
const { parseDuration, calculateExpiresAt } = require('../../utils/timeParser');
const { Embeds, THEME } = require('../../utils/embedBuilder');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('منع')
    .setDescription('إصدار عقوبة منع توظيف لعضو محدد')
    .addUserOption(option =>
      option
        .setName('العضو')
        .setDescription('العضو المراد تطبيق منع التوظيف عليه')
        .setRequired(true)
    )
    .addStringOption(option =>
      option
        .setName('المدة')
        .setDescription('قيمة المدة (مثال: 7 أو 24 أو دائم)')
        .setRequired(true)
    )
    .addStringOption(option =>
      option
        .setName('الوحدة')
        .setDescription('الوحدة الزمنية للمدة')
        .setRequired(false)
        .addChoices(
          { name: 'ساعات (Hours)', value: 'h' },
          { name: 'أيام (Days)', value: 'd' },
          { name: 'أسابيع (Weeks)', value: 'w' },
          { name: 'دقائق (Minutes)', value: 'm' },
          { name: 'منع دائم (Permanent)', value: 'perm' }
        )
    )
    .addStringOption(option =>
      option
        .setName('السبب')
        .setDescription('سبب منع التوظيف')
        .setRequired(false)
    ),

  async execute(interaction) {
    const guild = interaction.guild;
    const member = interaction.member;

    // 1. Permission check
    const settings = SettingsRepository.getSettings(guild.id);
    if (!PermissionsGuard.canIssueBan(member, settings)) {
      return interaction.reply({
        content: '❌ ليس لديك الصلاحية لاستخدام أمر منع التوظيف في هذا السيرفر.',
        ephemeral: true
      });
    }

    const targetUser = interaction.options.getUser('العضو');
    const durationInput = interaction.options.getString('المدة');
    const unitInput = interaction.options.getString('الوحدة');
    const reason = interaction.options.getString('السبب') || 'لا يوجد سبب محدد';

    // 2. Parse duration
    const parsed = parseDuration(durationInput, unitInput);
    if (parsed.error) {
      return interaction.reply({
        content: `❌ ${parsed.error}`,
        ephemeral: true
      });
    }

    if (parsed.isPermanent && !settings.allow_permanent_bans) {
      return interaction.reply({
        content: '❌ خيار المنع الدائم معطل حالياً في إعدادات السيرفر.',
        ephemeral: true
      });
    }

    // 3. Prevent self-ban or bot-ban
    if (targetUser.id === interaction.client.user.id) {
      return interaction.reply({
        content: '❌ لا يمكن تطبيق منع التوظيف على البوت نفسه.',
        ephemeral: true
      });
    }

    if (targetUser.id === member.id) {
      return interaction.reply({
        content: '❌ لا يمكنك تطبيق منع التوظيف على نفسك.',
        ephemeral: true
      });
    }

    // 4. Check active ban in DB
    const existing = BanRepository.getActiveBan(guild.id, targetUser.id);
    if (existing) {
      return interaction.reply({
        content: `⚠️ هذا العضو لديه منع توظيف نشط مسبقاً (رقم المنع: #${existing.id}). يمكنك تمديد مدته أو إلغاؤه أولاً.`,
        ephemeral: true
      });
    }

    // 5. Hierarchy check
    const targetMember = guild.members.cache.get(targetUser.id) || await guild.members.fetch(targetUser.id).catch(() => null);
    const hierarchyCheck = HierarchyGuard.validate(guild, settings.ban_role_id, targetMember);
    if (!hierarchyCheck.valid) {
      return interaction.reply({
        content: `❌ ${hierarchyCheck.error}`,
        ephemeral: true
      });
    }

    // 6. Confirmation step
    const expiresAt = calculateExpiresAt(parsed.seconds);
    const confirmEmbed = Embeds.banConfirmEmbed({
      user: targetUser,
      durationSeconds: parsed.seconds,
      expiresAt,
      reason
    });

    const confirmButton = new ButtonBuilder()
      .setCustomId(`confirm_hire_ban_${targetUser.id}`)
      .setLabel('تأكيد المنع')
      .setStyle(ButtonStyle.Danger)
      .setEmoji('🚫');

    const cancelButton = new ButtonBuilder()
      .setCustomId(`cancel_hire_ban_${targetUser.id}`)
      .setLabel('إلغاء')
      .setStyle(ButtonStyle.Secondary)
      .setEmoji('✖️');

    const row = new ActionRowBuilder().addComponents(confirmButton, cancelButton);

    const response = await interaction.reply({
      embeds: [confirmEmbed],
      components: [row],
      ephemeral: true,
      fetchReply: true
    });

    // Await button confirmation
    try {
      const confirmation = await response.awaitMessageComponent({
        filter: i => i.user.id === interaction.user.id,
        componentType: ComponentType.Button,
        time: 45000 // 45 seconds timeout
      });

      if (confirmation.customId.startsWith('cancel_hire_ban_')) {
        await confirmation.update({
          content: '⚪ تم إلغاء العملية ولم يتم إصدار أي منع.',
          embeds: [],
          components: []
        });
        return;
      }

      if (confirmation.customId.startsWith('confirm_hire_ban_')) {
        await confirmation.deferUpdate();

        try {
          const banRecord = await BanService.issueBan({
            guild,
            targetUserId: targetUser.id,
            moderator: interaction.user,
            durationSeconds: parsed.seconds,
            reason
          });

          await confirmation.editReply({
            content: `✅ **تم تطبيق منع التوظيف بنجاح!** (رقم المنع: #${banRecord.id})`,
            embeds: [],
            components: []
          });
        } catch (execErr) {
          const logger = require('../../utils/logger');
          logger.error(`[Security Logs] فشل تنفيذ منع التوظيف للعضو ${targetUser.id}:`, execErr.stack || execErr);
          const safeMessage = (execErr.code === 'HIERARCHY_VIOLATION' || execErr.code === 'ACTIVE_BAN_EXISTS')
            ? `❌ ${execErr.message}`
            : '❌ حدث خطأ أثناء تنفيذ العملية، يرجى التواصل مع الإدارة.';
          await confirmation.editReply({
            content: safeMessage,
            embeds: [],
            components: []
          });
        }
      }
    } catch (e) {
      // Timeout
      await interaction.editReply({
        content: '⏰ انتهت مهلة تأكيد الأمر وتم إلغاؤه تلقائياً.',
        embeds: [],
        components: []
      }).catch(() => {});
    }
  }
};
