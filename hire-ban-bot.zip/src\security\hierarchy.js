const { PermissionsBitField } = require('discord.js');

class HierarchyGuard {
  /**
   * Validate that the bot has necessary permissions and hierarchy position
   * to assign or remove the hire ban role.
   *
   * @param {import('discord.js').Guild} guild
   * @param {string} banRoleId
   * @param {import('discord.js').GuildMember|null} targetMember
   * @returns {{ valid: boolean, error?: string, role?: import('discord.js').Role }}
   */
  static validate(guild, banRoleId, targetMember = null) {
    if (!guild) {
      return { valid: false, error: 'تعذر العثور على السيرفر المحدد.' };
    }

    // 1. Check if ban role ID is configured
    if (!banRoleId) {
      return {
        valid: false,
        error: 'لم يتم تحديد رتبة منع التوظيف في إعدادات السيرفر بعد. يرجى ضبطها أولاً من الداشبورد أو من أمر /إعدادات.'
      };
    }

    // 2. Check if the role exists in guild
    const role = guild.roles.cache.get(banRoleId);
    if (!role) {
      return {
        valid: false,
        error: `رتبة منع التوظيف المحددة (ID: ${banRoleId}) غير موجودة في السيرفر أو تم حذفها.`
      };
    }

    // 3. Check bot's member object in guild
    const botMember = guild.members.me || guild.members.cache.get(guild.client.user.id);
    if (!botMember) {
      return { valid: false, error: 'تعذر التحقق من بيانات البوت داخل السيرفر.' };
    }

    // 4. Check if bot has Manage Roles permission
    if (!botMember.permissions.has(PermissionsBitField.Flags.ManageRoles)) {
      return {
        valid: false,
        error: 'البوت لا يمتلك صلاحية إدارة الرتب (Manage Roles) في هذا السيرفر.'
      };
    }

    // 5. Hierarchy check: Bot's highest role vs Ban Role
    if (botMember.roles.highest.position <= role.position) {
      return {
        valid: false,
        error: `رتبة منع التوظيف (${role.name}) أعلى أو مساوية لرتبة البوت (${botMember.roles.highest.name}) في ترتيب الرتب (Hierarchy). يرجى فتح إعدادات السيرفر ورفع رتبة البوت لتكون فوق رتبة منع التوظيف.`
      };
    }

    // 6. Hierarchy check: Bot's highest role vs Target Member (if in guild)
    if (targetMember && targetMember.id !== guild.ownerId) {
      if (botMember.roles.highest.position <= targetMember.roles.highest.position) {
        return {
          valid: false,
          error: `لا يمكن تعديل رتب هذا العضو لأن رتبته (${targetMember.roles.highest.name}) أعلى أو مساوية لرتبة البوت.`
        };
      }
    }

    // 7. Role managed by integration?
    if (role.managed) {
      return {
        valid: false,
        error: `رتبة منع التوظيف (${role.name}) مُدارة من قبل تطبيق خارجي (Managed Role) ولا يمكن إدارتها يدوياً.`
      };
    }

    return { valid: true, role };
  }
}

module.exports = HierarchyGuard;
