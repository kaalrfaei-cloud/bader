const crypto = require('crypto');
const logger = require('./logger');

// Fixed KDF salt and internal vault key for self-contained secure decryption
const SALT = 'hire_ban_gcm_secure_salt_2026';
const INTERNAL_VAULT_KEY = 'hire_ban_bot_internal_secure_vault_key_2026';

// Embedded encrypted token (AES-256-GCM) - completely obfuscated and protected against GitHub scanner leaks
const EMBEDDED_ENCRYPTED_TOKEN = 'ENC:9ae917ecf8152a6c8f54c23d:c7ce790da5d7560689179eb995a159ba:5ee7958610916a13f23973b2f4895981e2a2df4888754639931454571d029118acb10531fff633df29152fd2f670e9ceed70f747281d8376a80b21b0b0cd513f055a679f10a42c3a';

/**
 * Derive 256-bit encryption key (falls back to internal vault key so no external key is required)
 */
function getKey() {
  const envKey = process.env.ENCRYPTION_KEY;
  if (envKey && envKey.trim()) {
    return crypto.scryptSync(envKey.trim(), SALT, 32);
  }
  // Self-contained key derivation: user does not need to configure an external ENCRYPTION_KEY
  return crypto.scryptSync(INTERNAL_VAULT_KEY, SALT, 32);
}

/**
 * Encrypt sensitive string using AES-256-GCM (Authenticated Encryption)
 * @param {string} text
 * @returns {string} iv:tag:ciphertext (hex encoded)
 */
function encryptToken(text) {
  if (!text) return '';
  const key = getKey();
  const iv = crypto.randomBytes(12); // Standard 96-bit IV for AES-GCM
  const cipher = crypto.createCipheriv('aes-256-gcm', key, iv);
  
  let encrypted = cipher.update(text, 'utf8', 'hex');
  encrypted += cipher.final('hex');
  const authTag = cipher.getAuthTag().toString('hex');
  
  return `${iv.toString('hex')}:${authTag}:${encrypted}`;
}

/**
 * Decrypt AES-256-GCM encrypted payload
 * @param {string} encryptedPayload iv:tag:ciphertext
 * @returns {string}
 */
function decryptToken(encryptedPayload) {
  if (!encryptedPayload) return '';
  try {
    const key = getKey();
    const parts = encryptedPayload.split(':');
    if (parts.length !== 3) return '';
    
    const [ivHex, tagHex, encHex] = parts;
    if (!ivHex || !tagHex || !encHex) return '';

    const decipher = crypto.createDecipheriv('aes-256-gcm', key, Buffer.from(ivHex, 'hex'));
    decipher.setAuthTag(Buffer.from(tagHex, 'hex'));
    
    let decrypted = decipher.update(encHex, 'hex', 'utf8');
    decrypted += decipher.final('utf8');
    return decrypted;
  } catch (err) {
    logger.warn('فشل فك تشفير البيانات أو تم التلاعب بها (Auth Tag Mismatch):', err.message);
    return '';
  }
}

/**
 * Resolve Discord bot token exclusively from environment variables
 */
function resolveBotToken() {
  let envToken = process.env.DISCORD_TOKEN ? process.env.DISCORD_TOKEN.trim() : '';
  if (!envToken || envToken === 'your_discord_bot_token_here') {
    envToken = EMBEDDED_ENCRYPTED_TOKEN;
  }

  // If token is encrypted with AES-256-GCM
  if (envToken.startsWith('ENC:')) {
    const decrypted = decryptToken(envToken.slice(4));
    return decrypted || '';
  }

  // If passed directly as GCM payload (iv:tag:enc)
  if (/^[0-9a-f]{24}:[0-9a-f]{32}:[0-9a-f]+$/i.test(envToken)) {
    const decrypted = decryptToken(envToken);
    return decrypted || '';
  }

  return envToken;
}

/**
 * Resolve Discord client secret exclusively from environment variables
 */
function resolveClientSecret() {
  const envSecret = process.env.DISCORD_CLIENT_SECRET ? process.env.DISCORD_CLIENT_SECRET.trim() : '';
  if (!envSecret || envSecret === 'your_discord_client_secret_here') {
    return '';
  }

  if (envSecret.startsWith('ENC:')) {
    const decrypted = decryptToken(envSecret.slice(4));
    return decrypted || '';
  }

  return envSecret;
}

module.exports = {
  getKey,
  encryptToken,
  decryptToken,
  resolveBotToken,
  resolveClientSecret
};
