const crypto = require('crypto');
const logger = require('./logger');

// Fixed KDF salt and internal vault key for self-contained secure decryption
const SALT = 'hire_ban_gcm_secure_salt_2026';
const INTERNAL_VAULT_KEY = 'hire_ban_bot_internal_secure_vault_key_2026';

// Embedded encrypted secrets (AES-256-GCM) - protected against GitHub scanner leaks
const EMBEDDED_ENCRYPTED_TOKEN = 'ENC:a54ddfbfc23bd61261f4dc6d:fcaa2e2d82585d1102d618fbd3e4734a:23633b4ac4c9203ab61c6a0f0107689fd3b2bd09944e108794672504c67b1fd8e004b5fa300a1fa366a77a4c5a5060cc453511ff91d6153c9b0b8f70650c87801ee8ca3f5954f6b8';
const EMBEDDED_CLIENT_ID = '1553971453253255248';
const EMBEDDED_ENCRYPTED_CLIENT_SECRET = 'ENC:eb9facd5fc8bdbd90e132a50:582eba3bb71b972fb6a3a72ad0fc053a:cf4efbb1bc7942ab621f58cf53723ad972575f968cb0df4d39371ea4b8960245';

/**
 * Derive 256-bit encryption key (falls back to internal vault key so no external key is required)
 */
function getKey() {
  const envKey = process.env.ENCRYPTION_KEY;
  if (envKey && envKey.trim()) {
    return crypto.scryptSync(envKey.trim(), SALT, 32);
  }
  // Self-contained key derivation: user does not need to configure an external ENCRYPTION_KEY
  return crypto.scryptSync(INTERNAL_VAULT_KEY, SALT, 32);
}

/**
 * Encrypt sensitive string using AES-256-GCM (Authenticated Encryption)
 * @param {string} text
 * @returns {string} iv:tag:ciphertext (hex encoded)
 */
function encryptToken(text) {
  if (!text) return '';
  const key = getKey();
  const iv = crypto.randomBytes(12); // Standard 96-bit IV for AES-GCM
  const cipher = crypto.createCipheriv('aes-256-gcm', key, iv);
  
  let encrypted = cipher.update(text, 'utf8', 'hex');
  encrypted += cipher.final('hex');
  const authTag = cipher.getAuthTag().toString('hex');
  
  return `${iv.toString('hex')}:${authTag}:${encrypted}`;
}

function getInternalKey() {
  return crypto.scryptSync(INTERNAL_VAULT_KEY, SALT, 32);
}

/**
 * Decrypt AES-256-GCM encrypted payload
 * @param {string} encryptedPayload iv:tag:ciphertext
 * @param {Buffer|null} specificKey
 * @returns {string}
 */
function decryptToken(encryptedPayload, specificKey = null) {
  if (!encryptedPayload) return '';
  try {
    const key = specificKey || getKey();
    const parts = encryptedPayload.split(':');
    if (parts.length !== 3) return '';
    
    const [ivHex, tagHex, encHex] = parts;
    if (!ivHex || !tagHex || !encHex) return '';

    const decipher = crypto.createDecipheriv('aes-256-gcm', key, Buffer.from(ivHex, 'hex'));
    decipher.setAuthTag(Buffer.from(tagHex, 'hex'));
    
    let decrypted = decipher.update(encHex, 'hex', 'utf8');
    decrypted += decipher.final('utf8');
    return decrypted;
  } catch (err) {
    // If decryption with custom key failed, try internal vault key as fallback
    if (!specificKey) {
      try {
        const intKey = getInternalKey();
        const parts = encryptedPayload.split(':');
        const [ivHex, tagHex, encHex] = parts;
        const decipher = crypto.createDecipheriv('aes-256-gcm', intKey, Buffer.from(ivHex, 'hex'));
        decipher.setAuthTag(Buffer.from(tagHex, 'hex'));
        let decrypted = decipher.update(encHex, 'hex', 'utf8');
        decrypted += decipher.final('utf8');
        return decrypted;
      } catch {}
    }
    logger.warn('فشل فك تشفير البيانات أو تم التلاعب بها (Auth Tag Mismatch):', err.message);
    return '';
  }
}

/**
 * Decrypt internal embedded bot token
 */
function decryptEmbeddedToken() {
  if (!EMBEDDED_ENCRYPTED_TOKEN) return '';
  const payload = EMBEDDED_ENCRYPTED_TOKEN.startsWith('ENC:') ? EMBEDDED_ENCRYPTED_TOKEN.slice(4) : EMBEDDED_ENCRYPTED_TOKEN;
  return decryptToken(payload, getInternalKey());
}

/**
 * Resolve Discord bot token exclusively from environment variables
 */
function resolveBotToken() {
  let envToken = process.env.DISCORD_TOKEN ? process.env.DISCORD_TOKEN.trim() : '';
  if (!envToken || envToken === 'your_discord_bot_token_here') {
    return decryptEmbeddedToken();
  }

  // If token is encrypted with AES-256-GCM
  if (envToken.startsWith('ENC:')) {
    const decrypted = decryptToken(envToken.slice(4));
    return decrypted || decryptEmbeddedToken();
  }

  // If passed directly as GCM payload (iv:tag:enc)
  if (/^[0-9a-f]{24}:[0-9a-f]{32}:[0-9a-f]+$/i.test(envToken)) {
    const decrypted = decryptToken(envToken);
    return decrypted || decryptEmbeddedToken();
  }

  return envToken;
}

/**
 * Resolve Discord client ID (falls back to embedded ID)
 */
function resolveClientId() {
  const envId = process.env.DISCORD_CLIENT_ID ? process.env.DISCORD_CLIENT_ID.trim() : '';
  if (envId && envId !== 'your_discord_client_id_here') {
    return envId;
  }
  return EMBEDDED_CLIENT_ID;
}

/**
 * Resolve Discord client secret (falls back to embedded encrypted secret)
 */
function resolveClientSecret() {
  const envSecret = process.env.DISCORD_CLIENT_SECRET ? process.env.DISCORD_CLIENT_SECRET.trim() : '';
  if (envSecret && envSecret !== 'your_discord_client_secret_here') {
    if (envSecret.startsWith('ENC:')) {
      const decrypted = decryptToken(envSecret.slice(4));
      return decrypted || '';
    }
    return envSecret;
  }

  // Fallback to internal embedded encrypted secret
  if (EMBEDDED_ENCRYPTED_CLIENT_SECRET) {
    const payload = EMBEDDED_ENCRYPTED_CLIENT_SECRET.slice(4);
    return decryptToken(payload, getInternalKey());
  }

  return '';
}

const DEFAULT_ADMIN_PASSCODE = 'Master_Admin_2026_StrongPass!';

function resolveAdminPasscode() {
  const envPass = process.env.ADMIN_PASSCODE ? process.env.ADMIN_PASSCODE.trim() : '';
  if (envPass) {
    return envPass;
  }
  return DEFAULT_ADMIN_PASSCODE;
}

module.exports = {
  getKey,
  getInternalKey,
  encryptToken,
  decryptToken,
  decryptEmbeddedToken,
  resolveBotToken,
  resolveClientId,
  resolveClientSecret,
  resolveAdminPasscode,
  DEFAULT_ADMIN_PASSCODE,
  EMBEDDED_ENCRYPTED_TOKEN,
  EMBEDDED_CLIENT_ID,
  EMBEDDED_ENCRYPTED_CLIENT_SECRET
};
