const { SlashCommandBuilder } = require('discord.js');
const PermissionsGuard = require('../../security/permissions');
const SettingsRepository = require('../../database/repositories/settingsRepository');
const BanService = require('../../services/banService');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('الغاء-منع')
    .setDescription('إلغاء عقوبة منع التوظيف عن عضو')
    .addUserOption(option =>
      option
        .setName('العضو')
        .setDescription('العضو المراد رفع منع التوظيف عنه')
        .setRequired(true)
    )
    .addStringOption(option =>
      option
        .setName('السبب')
        .setDescription('سبب إلغاء المنع')
        .setRequired(false)
    ),

  async execute(interaction) {
    const guild = interaction.guild;
    const member = interaction.member;

    const settings = SettingsRepository.getSettings(guild.id);
    if (!PermissionsGuard.canRevokeBan(member, settings)) {
      return interaction.reply({
        content: '❌ ليس لديك الصلاحية لإلغاء منع التوظيف في هذا السيرفر (تحتاج إلى رتبة إلغاء المنع أو صلاحيات إدارة).',
        ephemeral: true
      });
    }

    const targetUser = interaction.options.getUser('العضو');
    const reason = interaction.options.getString('السبب') || 'إلغاء يدوي من قبل الإدارة';

    await interaction.deferReply({ ephemeral: true });

    try {
      const result = await BanService.revokeBan({
        guild,
        targetUserId: targetUser.id,
        moderator: interaction.user,
        reason
      });

      return interaction.editReply({
        content: `✅ **تم إلغاء منع التوظيف بنجاح عن <@${targetUser.id}>** (رقم المنع الملغى: #${result.banId}) وتمت إزالة الرول.`
      });
    } catch (err) {
      const logger = require('../../utils/logger');
      logger.error(`[Security Logs] فشل إلغاء منع التوظيف للعضو ${targetUser.id}:`, err.stack || err);
      const safeMessage = (err.code === 'NO_ACTIVE_BAN')
        ? `❌ ${err.message}`
        : '❌ حدث خطأ أثناء تنفيذ العملية، يرجى التواصل مع الإدارة.';
      return interaction.editReply({
        content: safeMessage
      });
    }
  }
};
