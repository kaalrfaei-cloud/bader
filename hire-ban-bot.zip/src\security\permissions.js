const { PermissionsBitField } = require('discord.js');
const SettingsRepository = require('../database/repositories/settingsRepository');

const ACTIONS = {
  BAN: 'BAN',
  UNBAN: 'UNBAN',
  EXTEND_BAN: 'EXTEND_BAN',
  REDUCE_BAN: 'REDUCE_BAN',
  VIEW_LOGS: 'VIEW_LOGS',
  MANAGE_SETTINGS: 'MANAGE_SETTINGS',
  MANAGE_2FA: 'MANAGE_2FA'
};

class PermissionsGuard {
  static get ACTIONS() {
    return ACTIONS;
  }

  /**
   * Helper to check if member is Guild Owner or Administrator
   */
  static isOwnerOrAdmin(guildMember) {
    if (!guildMember) return false;
    if (guildMember.id === 'admin_owner' || guildMember.isMasterAdmin) return true;
    if (!guildMember.guild) return false;

    if (guildMember.id === guildMember.guild.ownerId) return true;
    if (guildMember.permissions?.has && guildMember.permissions.has(PermissionsBitField.Flags.Administrator)) return true;

    return false;
  }

  /**
   * Check if a member has permission to issue a hire ban (Action: BAN).
   * Strict Policy:
   * - Owner / Administrator: Allowed
   * - Allowed Roles / Cancel Roles: Allowed
   * - If no roles configured: Strictly requires Owner or Administrator (no loose fallback).
   */
  static canIssueBan(guildMember, settings = null) {
    if (!guildMember) return false;
    if (this.isOwnerOrAdmin(guildMember)) return true;
    if (!guildMember.guild) return false;

    const guildSettings = settings || SettingsRepository.getSettings(guildMember.guild.id);
    const memberRoleIds = guildMember.roles?.cache ? Array.from(guildMember.roles.cache.keys()) : [];

    // Strictly allowed_roles only (cancel_roles must NOT grant ban issuance)
    const allowedRoles = guildSettings.allowed_roles || [];
    if (allowedRoles.length === 0) {
      // Strict security: require Administrator if no roles are explicitly configured
      return false;
    }

    return memberRoleIds.some(roleId => allowedRoles.includes(roleId));
  }

  /**
   * Check if a member has permission to revoke a hire ban (Action: UNBAN).
   * Strict Policy:
   * - Owner / Administrator: Allowed
   * - Cancel Roles: Allowed
   * - If no cancel roles configured: Strictly requires Owner or Administrator.
   */
  static canRevokeBan(guildMember, settings = null) {
    if (!guildMember) return false;
    if (this.isOwnerOrAdmin(guildMember)) return true;
    if (!guildMember.guild) return false;

    const guildSettings = settings || SettingsRepository.getSettings(guildMember.guild.id);
    const memberRoleIds = guildMember.roles?.cache ? Array.from(guildMember.roles.cache.keys()) : [];

    // Strictly cancel_roles only (allowed_roles must NOT grant ban revocation)
    const cancelRoles = guildSettings.cancel_roles || [];
    if (cancelRoles.length === 0) {
      return false;
    }

    return memberRoleIds.some(roleId => cancelRoles.includes(roleId));
  }

  /**
   * Check if a member has permission to view the bans list (/الممنوعين).
   */
  static canViewBansList(guildMember, settings = null) {
    if (!guildMember) return false;
    if (this.isOwnerOrAdmin(guildMember)) return true;
    if (!guildMember.guild) return false;

    const guildSettings = settings || SettingsRepository.getSettings(guildMember.guild.id);
    const memberRoleIds = guildMember.roles?.cache ? Array.from(guildMember.roles.cache.keys()) : [];

    const adminRoles = [
      ...(guildSettings.allowed_roles || []),
      ...(guildSettings.cancel_roles || []),
      ...(guildSettings.dashboard_roles || [])
    ];
    if (adminRoles.length === 0) return false;

    return memberRoleIds.some(roleId => adminRoles.includes(roleId));
  }

  /**
   * Check if a member can view full administrative details in /معلومات-منع
   */
  static canViewAdminBanDetails(guildMember, settings = null) {
    return this.canViewBansList(guildMember, settings);
  }

  /**
   * Check if a member has permission to modify ban duration (Action: EXTEND_BAN / REDUCE_BAN).
   */
  static canExtendBan(guildMember, settings = null) {
    return this.canRevokeBan(guildMember, settings);
  }

  /**
   * Check if a member can view audit logs (Action: VIEW_LOGS).
   */
  static canViewLogs(guildMember, settings = null) {
    if (!guildMember) return false;
    if (this.isOwnerOrAdmin(guildMember)) return true;
    if (!guildMember.guild) return false;

    const guildSettings = settings || SettingsRepository.getSettings(guildMember.guild.id);
    const memberRoleIds = guildMember.roles?.cache ? Array.from(guildMember.roles.cache.keys()) : [];

    const logRoles = [
      ...(guildSettings.dashboard_roles || []),
      ...(guildSettings.cancel_roles || []),
      ...(guildSettings.allowed_roles || [])
    ];

    return memberRoleIds.some(roleId => logRoles.includes(roleId));
  }

  /**
   * Check if a user/member has permission to access the Dashboard for this guild.
   */
  static canAccessDashboard(guildMember, settings = null) {
    if (!guildMember) return false;
    if (this.isOwnerOrAdmin(guildMember)) return true;
    if (!guildMember.guild) return false;

    const guildSettings = settings || SettingsRepository.getSettings(guildMember.guild.id);
    const memberRoleIds = guildMember.roles?.cache ? Array.from(guildMember.roles.cache.keys()) : [];

    const dashboardRoles = guildSettings.dashboard_roles || [];
    if (dashboardRoles.length > 0 && memberRoleIds.some(roleId => dashboardRoles.includes(roleId))) {
      return true;
    }

    return false;
  }

  /**
   * Check if a user can update guild settings (Action: MANAGE_SETTINGS).
   * Strictly Owner, Administrator, or Master Admin.
   */
  static canManageSettings(guildMember, settings = null) {
    return this.isOwnerOrAdmin(guildMember);
  }

  /**
   * Check if a user can manage 2FA (Action: MANAGE_2FA).
   */
  static canManage2FA(user, isMasterAdmin = false) {
    return Boolean(isMasterAdmin || user?.id === 'admin_owner');
  }
}

module.exports = PermissionsGuard;
