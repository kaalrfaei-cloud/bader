const { PermissionsBitField } = require('discord.js');
const SettingsRepository = require('../database/repositories/settingsRepository');

class PermissionsGuard {
  /**
   * Check if a member has permission to issue a hire ban.
   * Allowed if:
   * - Guild Owner
   * - Member has Administrator permission
   * - Member has any role listed in `allowed_roles`
   * - Member has any role listed in `cancel_roles` (cancel roles are higher tier)
   */
  static canIssueBan(guildMember, settings = null) {
    if (!guildMember || !guildMember.guild) return false;

    // Guild owner always has permission
    if (guildMember.id === guildMember.guild.ownerId) return true;

    // Server administrators always have permission
    if (guildMember.permissions?.has(PermissionsBitField.Flags.Administrator)) return true;

    const guildSettings = settings || SettingsRepository.getSettings(guildMember.guild.id);
    const memberRoleIds = guildMember.roles?.cache ? Array.from(guildMember.roles.cache.keys()) : [];

    const allowedRoles = [...(guildSettings.allowed_roles || []), ...(guildSettings.cancel_roles || [])];
    if (allowedRoles.length === 0) {
      // If no roles configured, fallback to ManageGuild or ManageRoles
      return guildMember.permissions?.has(PermissionsBitField.Flags.ManageRoles) ||
             guildMember.permissions?.has(PermissionsBitField.Flags.ManageGuild);
    }

    return memberRoleIds.some(roleId => allowedRoles.includes(roleId));
  }

  /**
   * Check if a member has permission to revoke a hire ban, modify duration, or view logs.
   * Allowed if:
   * - Guild Owner
   * - Member has Administrator permission
   * - Member has any role listed in `cancel_roles`
   */
  static canRevokeBan(guildMember, settings = null) {
    if (!guildMember || !guildMember.guild) return false;

    if (guildMember.id === guildMember.guild.ownerId) return true;
    if (guildMember.permissions?.has(PermissionsBitField.Flags.Administrator)) return true;

    const guildSettings = settings || SettingsRepository.getSettings(guildMember.guild.id);
    const memberRoleIds = guildMember.roles?.cache ? Array.from(guildMember.roles.cache.keys()) : [];

    const cancelRoles = guildSettings.cancel_roles || [];
    if (cancelRoles.length === 0) {
      return guildMember.permissions?.has(PermissionsBitField.Flags.ManageGuild) ||
             guildMember.permissions?.has(PermissionsBitField.Flags.Administrator);
    }

    return memberRoleIds.some(roleId => cancelRoles.includes(roleId));
  }

  /**
   * Check if a user/member has permission to access the Dashboard for this guild.
   * Strictly requires:
   * - Guild Owner
   * - Administrator permission (أدمنستريتور)
   */
  static canAccessDashboard(guildMember, settings = null) {
    if (!guildMember || !guildMember.guild) return false;

    if (guildMember.id === guildMember.guild.ownerId) return true;
    if (guildMember.permissions?.has(PermissionsBitField.Flags.Administrator)) return true;

    return false;
  }

  /**
   * Check if a user can update guild settings.
   */
  static canManageSettings(guildMember, settings = null) {
    if (!guildMember || !guildMember.guild) return false;

    if (guildMember.id === guildMember.guild.ownerId) return true;
    if (guildMember.permissions?.has(PermissionsBitField.Flags.Administrator)) return true;

    return false;
  }
}

module.exports = PermissionsGuard;
