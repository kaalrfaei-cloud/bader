const crypto = require('crypto');

const BASE32_ALPHABET = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';

class TotpService {
  /**
   * Generate a secure random Base32 secret key (16 characters)
   */
  static generateSecret(length = 16) {
    const randomBytes = crypto.randomBytes(length);
    let secret = '';
    for (let i = 0; i < length; i++) {
      secret += BASE32_ALPHABET[randomBytes[i] % 32];
    }
    return secret;
  }

  /**
   * Decode Base32 string to Buffer
   */
  static base32Decode(str) {
    if (!str) return Buffer.alloc(0);
    const clean = str.replace(/=+$/, '').toUpperCase();
    let bits = 0;
    let value = 0;
    const output = [];

    for (let i = 0; i < clean.length; i++) {
      const val = BASE32_ALPHABET.indexOf(clean[i]);
      if (val === -1) continue;
      value = (value << 5) | val;
      bits += 5;
      if (bits >= 8) {
        output.push((value >>> (bits - 8)) & 255);
        bits -= 8;
      }
    }
    return Buffer.from(output);
  }

  /**
   * Generate standard otpauth URL for QR codes
   */
  static getOtpAuthUrl({ issuer = 'HireBanBot', accountName = 'Admin', secret }) {
    const encodedIssuer = encodeURIComponent(issuer);
    const encodedAccount = encodeURIComponent(accountName);
    return `otpauth://totp/${encodedIssuer}:${encodedAccount}?secret=${secret}&issuer=${encodedIssuer}&algorithm=SHA1&digits=6&period=30`;
  }

  /**
   * Generate QR Code image URL via secure QR generator
   */
  static getQrCodeUrl(otpAuthUrl) {
    return `https://api.qrserver.com/v1/create-qr-code/?size=220x220&data=${encodeURIComponent(otpAuthUrl)}`;
  }

  /**
   * Verify standard RFC 6238 TOTP 6-digit token
   */
  static verifyToken(token, secret, window = 1) {
    if (!token || !secret) return false;
    const cleanToken = String(token).trim();
    if (!/^\d{6}$/.test(cleanToken)) return false;

    const key = this.base32Decode(secret);
    if (key.length === 0) return false;

    const epochSeconds = Math.floor(Date.now() / 1000);
    const currentCounter = Math.floor(epochSeconds / 30);

    for (let i = -window; i <= window; i++) {
      const counter = currentCounter + i;
      const buf = Buffer.alloc(8);
      buf.writeBigInt64BE(BigInt(counter));

      const hmac = crypto.createHmac('sha1', key).update(buf).digest();
      const offset = hmac[hmac.length - 1] & 0x0f;
      const binary =
        ((hmac[offset] & 0x7f) << 24) |
        ((hmac[offset + 1] & 0xff) << 16) |
        ((hmac[offset + 2] & 0xff) << 8) |
        (hmac[offset + 3] & 0xff);

      const expectedOtp = (binary % 1000000).toString().padStart(6, '0');
      if (crypto.timingSafeEqual(Buffer.from(cleanToken), Buffer.from(expectedOtp))) {
        return true;
      }
    }

    return false;
  }
}

module.exports = TotpService;
