const SettingsRepository = require('../database/repositories/settingsRepository');
const logger = require('./logger');

const BAN_ROLE_REGEX = /(منع[\s\-_]*التوظيف|منع[\s\-_]*توظيف|^منع$|ممنوع[\s\-_]*من[\s\-_]*التوظيف|hire[\s\-_]*ban)/i;

/**
 * Resolve the ban role for a guild.
 * If not configured in settings, searches guild roles by name and auto-saves it.
 */
function resolveBanRole(guild, settings = null) {
  if (!guild || !guild.roles) return null;
  const currentSettings = settings || SettingsRepository.getSettings(guild.id) || {};

  // 1. Configured role
  if (currentSettings.ban_role_id && guild.roles.cache) {
    const role = guild.roles.cache.get ? guild.roles.cache.get(currentSettings.ban_role_id) : null;
    if (role) return role;
  }

  // 2. Auto-discover role by name
  if (guild.roles.cache) {
    const rolesArray = Array.from(guild.roles.cache.values ? guild.roles.cache.values() : guild.roles.cache);
    const discovered = rolesArray.find(r => r && r.name && BAN_ROLE_REGEX.test(r.name));
    if (discovered) {
      try {
        SettingsRepository.saveSettings(guild.id, { ban_role_id: discovered.id });
        logger.info(`[Auto-Config] تم اكتشاف وتعيين رتبة منع التوظيف تلقائياً للسيرفر ${guild.name}: @${discovered.name} (${discovered.id})`);
      } catch {}
      return discovered;
    }
  }

  return null;
}

/**
 * Check if a Discord GuildMember has the hire ban role.
 * Cross-checks both the configured role ID and any matching role by name on the member.
 */
function memberHasBanRole(member, banRoleId = null) {
  if (!member || !member.roles || !member.roles.cache) return false;

  // 1. Direct role ID check
  if (banRoleId && member.roles.cache.has && member.roles.cache.has(banRoleId)) {
    return true;
  }

  // 2. Name-based match on member's current roles (supports Collection, Array, Set, Map)
  const rolesArray = Array.from(member.roles.cache.values ? member.roles.cache.values() : member.roles.cache);
  return rolesArray.some(r => {
    if (!r) return false;
    if (typeof r === 'string') return BAN_ROLE_REGEX.test(r) || (banRoleId && r === banRoleId);
    return (r.name && BAN_ROLE_REGEX.test(r.name)) || (banRoleId && r.id === banRoleId);
  });
}

/**
 * Get the specific ban role object from member if they have one
 */
function getMemberBanRole(member, banRoleId = null) {
  if (!member || !member.roles || !member.roles.cache) return null;

  if (banRoleId && member.roles.cache.get) {
    const role = member.roles.cache.get(banRoleId);
    if (role) return role;
  }

  const rolesArray = Array.from(member.roles.cache.values ? member.roles.cache.values() : member.roles.cache);
  return rolesArray.find(r => r && r.name && BAN_ROLE_REGEX.test(r.name)) || null;
}

module.exports = {
  BAN_ROLE_REGEX,
  resolveBanRole,
  memberHasBanRole,
  getMemberBanRole
};
