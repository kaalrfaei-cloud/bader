const { SlashCommandBuilder, EmbedBuilder, ChannelType } = require('discord.js');
const SettingsRepository = require('../../database/repositories/settingsRepository');
const PermissionsGuard = require('../../security/permissions');
const { THEME } = require('../../utils/embedBuilder');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('إعدادات')
    .setDescription('إدارة وضبط إعدادات نظام منع التوظيف ورومات البوت')
    .addSubcommand(sub =>
      sub
        .setName('عرض')
        .setDescription('عرض الإعدادات الحالية لنظام منع التوظيف والرومات')
    )
    .addSubcommand(sub =>
      sub
        .setName('ضبط')
        .setDescription('تعيين وتحديث رومات ورتبة منع التوظيف مباشرة')
        .addRoleOption(opt =>
          opt
            .setName('رتبة_المنع')
            .setDescription('رتبة منع التوظيف التي يعطيها البوت للعضو الممنوع')
            .setRequired(false)
        )
        .addChannelOption(opt =>
          opt
            .setName('روم_المواطنين')
            .setDescription('روم فحص واستعلام المواطنين عن منع التوظيف')
            .addChannelTypes(ChannelType.GuildText)
            .setRequired(false)
        )
        .addChannelOption(opt =>
          opt
            .setName('روم_السجلات')
            .setDescription('روم سجلات عمليات المنع وفك المنع التلقائي')
            .addChannelTypes(ChannelType.GuildText)
            .setRequired(false)
        )
        .addChannelOption(opt =>
          opt
            .setName('روم_الإدارة')
            .setDescription('روم أوامر الإدارة المحمي')
            .addChannelTypes(ChannelType.GuildText)
            .setRequired(false)
        )
    ),

  async execute(interaction) {
    const guild = interaction.guild;
    const member = interaction.member;

    const settings = SettingsRepository.getSettings(guild.id);
    if (!PermissionsGuard.canManageSettings(member, settings)) {
      return interaction.reply({
        content: '❌ هذا الأمر مخصص لإدارة السيرفر وأصحاب الصلاحيات فقط.',
        ephemeral: true
      });
    }

    const subcommand = interaction.options.getSubcommand(false) || 'عرض';

    if (subcommand === 'ضبط') {
      const banRole = interaction.options.getRole('رتبة_المنع');
      const citizenChannel = interaction.options.getChannel('روم_المواطنين');
      const logChannel = interaction.options.getChannel('روم_السجلات');
      const adminChannel = interaction.options.getChannel('روم_الإدارة');

      const updates = {};
      const changes = [];

      if (banRole) {
        updates.ban_role_id = banRole.id;
        changes.push(`🎭 **رتبة منع التوظيف:** <@&${banRole.id}>`);
      }
      if (citizenChannel) {
        updates.citizen_channel_id = citizenChannel.id;
        changes.push(`📢 **روم المواطنين (الاستعلام):** <#${citizenChannel.id}>`);
      }
      if (logChannel) {
        updates.log_channel_id = logChannel.id;
        changes.push(`📜 **روم السجلات:** <#${logChannel.id}>`);
      }
      if (adminChannel) {
        updates.admin_channel_id = adminChannel.id;
        changes.push(`🛡️ **روم الإدارة:** <#${adminChannel.id}>`);
      }

      if (Object.keys(updates).length === 0) {
        return interaction.reply({
          content: '⚠️ لم تقم بتحديد أي خيار لتعديله! يمكنك اختيار (روم_المواطنين، روم_السجلات، روم_الإدارة، أو رتبة_المنع).',
          ephemeral: true
        });
      }

      SettingsRepository.saveSettings(guild.id, updates);

      const embed = new EmbedBuilder()
        .setColor(THEME.SUCCESS)
        .setTitle('✅ تم تحديث إعدادات النظام بنجاح')
        .setDescription(`تم حفظ التعديلات التالية في إعدادات السيرفر:\n\n${changes.join('\n')}`)
        .setFooter({ text: 'بـوت مـنـع الـتـوظـيـف • إعدادات النظام' })
        .setTimestamp();

      return interaction.reply({ embeds: [embed], ephemeral: true });
    }

    // Default: عرض
    const currentSettings = SettingsRepository.getSettings(guild.id);
    const banRoleText = currentSettings.ban_role_id ? `<@&${currentSettings.ban_role_id}>` : '❌ غير محددة';
    const adminChannelText = currentSettings.admin_channel_id ? `<#${currentSettings.admin_channel_id}>` : '❌ غير محدد';
    const citizenChannelText = currentSettings.citizen_channel_id ? `<#${currentSettings.citizen_channel_id}>` : '❌ غير محدد';
    const logChannelText = currentSettings.log_channel_id ? `<#${currentSettings.log_channel_id}>` : '❌ غير محدد';

    const allowedRolesText = (currentSettings.allowed_roles || []).length > 0
      ? currentSettings.allowed_roles.map(r => `<@&${r}>`).join(', ')
      : 'صلاحيات الإدارة الافتراضية';

    const cancelRolesText = (currentSettings.cancel_roles || []).length > 0
      ? currentSettings.cancel_roles.map(r => `<@&${r}>`).join(', ')
      : 'الإدارة العليا فقط';

    const dashboardUrl = process.env.DASHBOARD_URL || `http://localhost:${process.env.PORT || 3000}`;

    const embed = new EmbedBuilder()
      .setColor(THEME.DARK)
      .setTitle(`⚙️ إعدادات نظام منع التوظيف - ${guild.name}`)
      .setDescription(`يمكنك ضبط الرومات بأمر \`/إعدادات ضبط\` أو عبر [لوحة التحكم (${dashboardUrl})](${dashboardUrl}).`)
      .addFields(
        { name: '🎭 رتبة منع التوظيف', value: banRoleText, inline: true },
        { name: '🔒 المنع الدائم', value: currentSettings.allow_permanent_bans ? '✅ مفعّل' : '❌ معطّل', inline: true },
        { name: '\u200B', value: '\u200B', inline: true },
        { name: '📢 روم المواطنين (الاستعلام)', value: citizenChannelText, inline: true },
        { name: '📜 روم السجلات', value: logChannelText, inline: true },
        { name: '🛡️ روم الإدارة', value: adminChannelText, inline: true },
        { name: '👮 رتب إعطاء المنع', value: allowedRolesText, inline: false },
        { name: '👑 رتب إلغاء وإدارة المنع', value: cancelRolesText, inline: false }
      )
      .setFooter({ text: 'Hire Ban Bot Settings' })
      .setTimestamp();

    return interaction.reply({ embeds: [embed], ephemeral: true });
  }
};
