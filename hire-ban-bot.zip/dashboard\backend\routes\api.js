const express = require('express');
const { requireAuth } = require('../../../src/middleware/authMiddleware');
const AntiIdorGuard = require('../../../src/security/antiIdor');
const PermissionsGuard = require('../../../src/security/permissions');
const { sensitiveActionLimiter } = require('../../../src/middleware/rateLimitMiddleware');
const BanRepository = require('../../../src/database/repositories/banRepository');
const SettingsRepository = require('../../../src/database/repositories/settingsRepository');
const AuditLogRepository = require('../../../src/database/repositories/auditLogRepository');
const BanService = require('../../../src/services/banService');
const { parseDuration } = require('../../../src/utils/timeParser');
const logger = require('../../../src/utils/logger');

function createApiRoutes(discordClient) {
  const router = express.Router();

  // All API routes require session authentication
  router.use(requireAuth);

  // Guild scope verification middleware (Anti-IDOR)
  const verifyGuild = AntiIdorGuard.verifyGuildAccess(discordClient);

  // 1. Guild Overview Stats
  router.get('/guilds/:guildId/stats', verifyGuild, (req, res) => {
    const { guildId } = req.params;
    const stats = BanRepository.getStats(guildId);

    // Bot health and system details
    const botStatus = {
      online: discordClient.isReady(),
      uptimeSeconds: Math.floor(discordClient.uptime / 1000) || 0,
      ping: discordClient.ws.ping || 0,
      guildCount: discordClient.guilds.cache.size,
      botTag: discordClient.user?.tag || 'Hire Ban Bot'
    };

    res.json({
      success: true,
      stats,
      botStatus,
      database: 'Connected (SQLite WAL)'
    });
  });

  // 2. Bans List (Paginated & Filtered)
  router.get('/guilds/:guildId/bans', verifyGuild, (req, res) => {
    const { guildId } = req.params;
    const { status, search, limit = 15, page = 1, sortBy = 'id', sortOrder = 'DESC' } = req.query;

    const parsedLimit = Math.min(Math.max(parseInt(limit, 10) || 15, 1), 100);
    const parsedPage = Math.max(parseInt(page, 10) || 1, 1);
    const offset = (parsedPage - 1) * parsedLimit;

    const result = BanRepository.listBans({
      guildId,
      status: status || null,
      search: search || '',
      limit: parsedLimit,
      offset,
      sortBy,
      sortOrder
    });

    res.json({
      success: true,
      ...result,
      page: parsedPage,
      totalPages: Math.ceil(result.total / parsedLimit) || 1
    });
  });

  // 3. Issue a Ban (Mutation)
  router.post('/guilds/:guildId/bans', verifyGuild, sensitiveActionLimiter, async (req, res) => {
    const { guildId } = req.params;
    const { userId, durationValue, durationUnit, reason } = req.body;

    if (!userId || !userId.trim()) {
      return res.status(400).json({ error: 'معرف العضو (Discord User ID) مطلوب.' });
    }

    const trimmedUserId = userId.trim();
    if (!/^\d{17,20}$/.test(trimmedUserId)) {
      return res.status(400).json({ error: 'معرف العضو غير صالح. يجب أن يتكون من 17-20 رقماً.' });
    }

    const sanitizedReason = (reason ? String(reason).trim() : 'لا يوجد سبب محدد').slice(0, 500);

    const member = req.verifiedMember;
    const settings = req.guildSettings;

    if (!PermissionsGuard.canIssueBan(member, settings)) {
      return res.status(403).json({ error: 'ليس لديك صلاحية لإصدار منع توظيف في هذا السيرفر.' });
    }

    const parsed = parseDuration(durationValue, durationUnit);
    if (parsed.error) {
      return res.status(400).json({ error: parsed.error });
    }

    if (parsed.isPermanent && !settings.allow_permanent_bans) {
      return res.status(400).json({ error: 'المنع الدائم معطل حالياً في إعدادات السيرفر.' });
    }

    try {
      const banRecord = await BanService.issueBan({
        guild: req.verifiedGuild,
        targetUserId: trimmedUserId,
        moderator: req.session.user,
        durationSeconds: parsed.seconds,
        reason: sanitizedReason
      });

      res.json({
        success: true,
        message: 'تم تطبيق منع التوظيف بنجاح.',
        ban: banRecord
      });
    } catch (err) {
      res.status(400).json({ error: err.message });
    }
  });

  // 4. Revoke a Ban (Mutation with Anti-IDOR)
  router.post('/guilds/:guildId/bans/:id/revoke', verifyGuild, sensitiveActionLimiter, AntiIdorGuard.verifyBanOwnership, async (req, res) => {
    const member = req.verifiedMember;
    const settings = req.guildSettings;

    if (!PermissionsGuard.canRevokeBan(member, settings)) {
      return res.status(403).json({ error: 'ليس لديك صلاحية لإلغاء منع التوظيف (تحتاج لرتبة إلغاء المنع أو صلاحيات إدارة).' });
    }

    const ban = req.verifiedBan;
    const reason = req.body.reason || 'إلغاء عبر لوحة التحكم (Dashboard)';

    try {
      const result = await BanService.revokeBan({
        guild: req.verifiedGuild,
        targetUserId: ban.user_id,
        moderator: req.session.user,
        reason
      });

      res.json({
        success: true,
        message: 'تم إلغاء منع التوظيف وإزالة الرول بنجاح.',
        banId: result.banId
      });
    } catch (err) {
      res.status(400).json({ error: err.message });
    }
  });

  // 5. Extend / Shorten Ban Duration (Mutation with Anti-IDOR)
  router.post('/guilds/:guildId/bans/:id/extend', verifyGuild, sensitiveActionLimiter, AntiIdorGuard.verifyBanOwnership, async (req, res) => {
    const member = req.verifiedMember;
    const settings = req.guildSettings;

    if (!PermissionsGuard.canRevokeBan(member, settings)) {
      return res.status(403).json({ error: 'ليس لديك صلاحية لتعديل مدة المنع.' });
    }

    const ban = req.verifiedBan;
    const { durationValue, durationUnit, reason } = req.body;

    const parsed = parseDuration(durationValue, durationUnit);
    if (parsed.error) {
      return res.status(400).json({ error: parsed.error });
    }

    try {
      const result = await BanService.updateBanDuration({
        guild: req.verifiedGuild,
        banId: ban.id,
        moderator: req.session.user,
        newDurationSeconds: parsed.seconds,
        reason: reason || 'تعديل المدة من لوحة التحكم'
      });

      res.json({
        success: true,
        message: 'تم تعديل مدة المنع بنجاح.',
        ...result
      });
    } catch (err) {
      res.status(400).json({ error: err.message });
    }
  });

  // 6. Audit Logs
  router.get('/guilds/:guildId/logs', verifyGuild, (req, res) => {
    const { guildId } = req.params;
    const { action, search, fromDate, toDate, page = 1, limit = 25 } = req.query;

    const parsedLimit = Math.min(Math.max(parseInt(limit, 10) || 25, 1), 100);
    const parsedPage = Math.max(parseInt(page, 10) || 1, 1);
    const offset = (parsedPage - 1) * parsedLimit;

    const result = AuditLogRepository.listLogs({
      guildId,
      action: action || null,
      search: search || '',
      fromDate: fromDate || null,
      toDate: toDate || null,
      limit: parsedLimit,
      offset
    });

    res.json({
      success: true,
      ...result,
      page: parsedPage,
      totalPages: Math.ceil(result.total / parsedLimit) || 1
    });
  });

  // 7. Export Audit Logs CSV
  router.get('/guilds/:guildId/logs/export', verifyGuild, (req, res) => {
    const { guildId } = req.params;
    const csvData = AuditLogRepository.exportLogsCsv(guildId);

    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader('Content-Disposition', `attachment; filename="hire_ban_logs_${guildId}_${Date.now()}.csv"`);
    res.send('\uFEFF' + csvData); // UTF-8 BOM for Excel Arabic support
  });

  // 8. Guild Settings
  router.get('/guilds/:guildId/settings', verifyGuild, (req, res) => {
    res.json({
      success: true,
      settings: req.guildSettings
    });
  });

  // 9. Update Guild Settings
  router.post('/guilds/:guildId/settings', verifyGuild, sensitiveActionLimiter, (req, res) => {
    const member = req.verifiedMember;
    const settings = req.guildSettings;

    if (!PermissionsGuard.canManageSettings(member, settings)) {
      return res.status(403).json({ error: 'ليس لديك صلاحية لتعديل إعدادات هذا السيرفر.' });
    }

    const {
      admin_channel_id,
      citizen_channel_id,
      log_channel_id,
      ban_role_id,
      allowed_roles,
      cancel_roles,
      dashboard_roles,
      allow_permanent_bans,
      notification_settings
    } = req.body;

    const updated = SettingsRepository.saveSettings(req.params.guildId, {
      admin_channel_id,
      citizen_channel_id,
      log_channel_id,
      ban_role_id,
      allowed_roles,
      cancel_roles,
      dashboard_roles,
      allow_permanent_bans,
      notification_settings
    });

    // Write audit log
    AuditLogRepository.createLog({
      guildId: req.params.guildId,
      action: 'SETTINGS_UPDATED',
      moderatorId: req.session.user.id,
      moderatorTag: req.session.user.username,
      details: { updatedSettings: updated }
    });

    res.json({
      success: true,
      message: 'تم حفظ وتحديث الإعدادات بنجاح.',
      settings: updated
    });
  });

  // 10. Fetch Real Discord Roles for Select Pickers
  router.get('/guilds/:guildId/discord-roles', verifyGuild, (req, res) => {
    const guild = req.verifiedGuild;
    const roles = Array.from(guild.roles.cache.values())
      .filter(r => r.id !== guild.id) // exclude @everyone
      .map(r => ({
        id: r.id,
        name: r.name,
        color: r.hexColor,
        position: r.position,
        managed: r.managed
      }))
      .sort((a, b) => b.position - a.position);

    res.json({ success: true, roles });
  });

  // 11. Fetch Real Discord Channels for Select Pickers
  router.get('/guilds/:guildId/discord-channels', verifyGuild, (req, res) => {
    const guild = req.verifiedGuild;
    const channels = Array.from(guild.channels.cache.values())
      .filter(c => c.isTextBased())
      .map(c => ({
        id: c.id,
        name: c.name,
        type: c.type,
        parentName: c.parent ? c.parent.name : null
      }))
      .sort((a, b) => a.name.localeCompare(b.name));

    res.json({ success: true, channels });
  });

  // 12. Staff Members List
  router.get('/guilds/:guildId/staff', verifyGuild, (req, res) => {
    const guild = req.verifiedGuild;
    const settings = req.guildSettings;

    const staffRoleIds = new Set([
      ...(settings.allowed_roles || []),
      ...(settings.cancel_roles || []),
      ...(settings.dashboard_roles || [])
    ]);

    const staffMembers = [];

    for (const [id, member] of guild.members.cache) {
      if (member.user.bot) continue;

      const isOwner = member.id === guild.ownerId;
      const isAdmin = member.permissions.has('Administrator');
      const matchedRoles = member.roles.cache.filter(r => staffRoleIds.has(r.id));

      if (isOwner || isAdmin || matchedRoles.size > 0) {
        staffMembers.push({
          id: member.id,
          username: member.user.username,
          tag: member.user.tag || member.user.username,
          avatar: member.user.displayAvatarURL({ dynamic: true }),
          isOwner,
          isAdmin,
          roles: member.roles.cache.filter(r => r.id !== guild.id).map(r => ({ id: r.id, name: r.name, color: r.hexColor })),
          canIssueBan: PermissionsGuard.canIssueBan(member, settings),
          canRevokeBan: PermissionsGuard.canRevokeBan(member, settings),
          canManageSettings: PermissionsGuard.canManageSettings(member, settings)
        });
      }
    }

    res.json({ success: true, staff: staffMembers });
  });

  // 13. Detailed Analytics for Charts
  router.get('/guilds/:guildId/analytics', verifyGuild, (req, res) => {
    const { guildId } = req.params;
    const analytics = BanRepository.getAnalytics(guildId);
    res.json({ success: true, analytics });
  });

  return router;
}

module.exports = createApiRoutes;
