const BanRepository = require('../../database/repositories/banRepository');
const SettingsRepository = require('../../database/repositories/settingsRepository');
const AuditLogRepository = require('../../database/repositories/auditLogRepository');
const logger = require('../../utils/logger');
const { EmbedBuilder, AuditLogEvent, PermissionFlagsBits } = require('discord.js');

// In-flight mutex set to prevent concurrent duplicate calls while preserving immediate re-adds
const inFlightRestores = new Set();

/**
 * Send security alert to designated log and admin channels
 */
async function sendSecurityAlert(guild, settings, message, targetUserId = null) {
  try {
    const channelId = settings.log_channel_id || settings.admin_channel_id;
    if (!channelId) return;

    const channel = guild.channels.cache.get(channelId) || await guild.channels.fetch(channelId).catch(() => null);
    if (!channel || !channel.isTextBased()) return;

    const embed = new EmbedBuilder()
      .setColor('#ef4444')
      .setTitle('⚠️ تنبيه أمني عاجل: فشل حماية رتبة منع التوظيف')
      .setDescription(message)
      .addFields(
        { name: '👤 العضو المستهدف', value: targetUserId ? `<@${targetUserId}> (\`${targetUserId}\`)` : 'غير محدد', inline: true },
        { name: '🛠️ الإجراء المطلوب', value: '1. توجه إلى إعدادات السيرفر ← الرتب (Roles)\n2. اسحب رتبة البوت لتكون أعلى من رتبة منع التوظيف\n3. تأكد من امتلاك البوت لصلاحية `Manage Roles`', inline: false }
      )
      .setFooter({ text: 'Hire Ban Bot • Anti-Tamper Security' })
      .setTimestamp();

    await channel.send({ embeds: [embed] }).catch(() => {});
  } catch (e) {
    logger.warn('تعذر إرسال تنبيه الأمان للروم:', e.message);
  }
}

module.exports = {
  name: 'guildMemberUpdate',
  once: false,
  async execute(oldMember, newMember) {
    if (!newMember || !newMember.guild) return;

    try {
      const guild = newMember.guild;
      const settings = SettingsRepository.getSettings(guild.id);
      const banRoleId = settings.ban_role_id;
      if (!banRoleId) return;

      const memberId = newMember.id;

      // 1. Check if member currently has the ban role
      let member = newMember;
      if ((!member.roles?.add || !member.roles?.cache) && guild.members?.fetch) {
        try {
          const fetched = await guild.members.fetch(memberId).catch(() => null);
          if (fetched) member = fetched;
        } catch {}
      }

      const hasRole = member.roles?.cache ? member.roles.cache.has(banRoleId) : false;

      // If the member still has the role, no action needed
      if (hasRole) {
        return;
      }

      // 2. Member does NOT have the role: Check if they have an ACTIVE ban in the database
      const activeBan = BanRepository.getActiveBan(guild.id, memberId);
      if (!activeBan) {
        // Not banned or legitimately revoked/expired -> do nothing
        return;
      }

      // 3. Concurrency Guard: prevent duplicate roles.add calls in flight
      if (inFlightRestores.has(memberId)) return;
      inFlightRestores.add(memberId);

      logger.warn(`[Anti-Tamper] رصد فقدان رتبة منع التوظيف للعضو ${newMember.user?.tag || memberId} بينما المنع ما زال نشطاً في النظام (#${activeBan.id})! جاري فحص الرتب وإعادتها فورياً...`);

      // 4. Validate Bot Permissions and Role Hierarchy
      const me = guild.members?.me || (guild.members?.fetchMe ? await guild.members.fetchMe().catch(() => null) : null);
      const role = guild.roles?.cache?.get(banRoleId) || (guild.roles?.fetch ? await guild.roles.fetch(banRoleId).catch(() => null) : null);

      if (role && me) {
        if (me.permissions?.has && !me.permissions.has(PermissionFlagsBits.ManageRoles)) {
          const alertMsg = 'البوت يفتقر إلى صلاحية إدارة الرتب (Manage Roles) في السيرفر! لا يمكن للبوت حماية أو إعادة رتبة منع التوظيف.';
          logger.error(`[Anti-Tamper] ${alertMsg}`);
          await sendSecurityAlert(guild, settings, alertMsg, memberId);
          inFlightRestores.delete(memberId);
          return;
        }

        if (me.roles?.highest && me.roles.highest.position <= role.position) {
          const alertMsg = `❌ **خطأ في ترتيب الرتب (Role Hierarchy):**\nرتبة البوت (\`${me.roles.highest.name}\`) أدنى من أو مساوية لرتبة منع التوظيف (\`${role.name}\`)!\n\n**الحل الفوري:**\nتوجه إلى: **إعدادات السيرفر ← الرتب (Roles)** واسحب رتبة البوت لتكون أعلى من رتبة منع التوظيف مباشرةً.`;
          logger.error(`[Anti-Tamper] ${alertMsg}`);
          await sendSecurityAlert(guild, settings, alertMsg, memberId);
          inFlightRestores.delete(memberId);
          return;
        }
      }

      // 5. Immediately re-add the ban role
      let restoreSuccess = false;
      try {
        await member.roles.add(banRoleId, 'إعادة تلقائية فورية: منع التوظيف نشط في النظام ومحمي من السحب اليدوي');
        restoreSuccess = true;
        logger.info(`[Anti-Tamper] تمت إعادة رتبة منع التوظيف بنجاح للعضو ${newMember.user?.tag || memberId}`);
      } catch (roleErr) {
        logger.error(`[Anti-Tamper] تعذر إعادة الرتبة للعضو ${memberId}: ${roleErr.message}`);
        await sendSecurityAlert(guild, settings, `فشل إعادة الرتبة برمجياً: ${roleErr.message}`, memberId);
      } finally {
        // Release the mutex lock IMMEDIATELY so any subsequent removal is intercepted without delay
        inFlightRestores.delete(memberId);
      }

      if (!restoreSuccess) return;

      // 6. Look up who attempted to remove the role from Discord Audit Logs (Asynchronously)
      let executor = null;
      try {
        const hasAuditPerm = me && me.permissions && me.permissions.has(PermissionFlagsBits.ViewAuditLog);
        if (hasAuditPerm && typeof guild.fetchAuditLogs === 'function') {
          // 400ms delay for Discord gateway to commit audit log entry
          await new Promise(resolve => setTimeout(resolve, 400));
          const auditLogs = await guild.fetchAuditLogs({
            limit: 5,
            type: AuditLogEvent.MemberRoleUpdate
          }).catch(() => null);

          if (auditLogs && auditLogs.entries) {
            const entry = auditLogs.entries.find(e =>
              e.target?.id === memberId &&
              e.executor?.id !== guild.client?.user?.id &&
              (Date.now() - e.createdTimestamp) < 20000
            );
            if (entry && entry.executor) {
              executor = entry.executor;
            }
          }
        }
      } catch (auditErr) {
        logger.warn(`تعذر فحص سجل تدقيق ديسكورد لمعرفة منفذ السحب: ${auditErr.message}`);
      }

      const userTag = newMember.user?.tag || newMember.user?.username || `User_${memberId}`;
      const executorTag = executor ? (executor.tag || executor.username) : 'إداري من الديسكورد';
      const executorMention = executor ? `<@${executor.id}> (\`${executorTag}\`)` : 'أحد الإداريين';
      const executorField = executor ? `<@${executor.id}> (\`${executorTag}\`)` : 'لم يتم التعرف عليه (تأكد من صلاحية View Audit Log للبوت)';

      // 7. Record in Audit Logs
      AuditLogRepository.createLog({
        guildId: guild.id,
        action: 'ROLE_TAMPER_PREVENTED',
        targetUserId: memberId,
        targetUserTag: userTag,
        moderatorId: executor ? executor.id : 'MANUAL_DISCORD_ADMIN',
        moderatorTag: executorTag,
        details: {
          banId: activeBan.id,
          executorId: executor ? executor.id : null,
          executorTag: executor ? executorTag : null,
          reason: 'تم إحباط محاولة سحب الرتبة يدوياً وإعادتها فورياً ومحايدة المحاولة'
        }
      });

      // 8. Send alert embed to log channel
      if (settings.log_channel_id) {
        const logChannel = guild.channels.cache.get(settings.log_channel_id) || await guild.channels.fetch(settings.log_channel_id).catch(() => null);
        if (logChannel && logChannel.isTextBased()) {
          const embed = new EmbedBuilder()
            .setColor('#ef4444')
            .setTitle('🛡️ نظام الحماية: إحباط محاولة سحب رتبة يدوياً')
            .setDescription(`قام ${executorMention} بمحاولة سحب رتبة منع التوظيف يدوياً عن العضو <@${memberId}> (\`${userTag}\`) من خارج النظام.`)
            .addFields(
              { name: '👤 العضو المعني', value: `<@${memberId}> (\`${userTag}\`)`, inline: true },
              { name: '👮 الإداري الذي حاول السحب', value: executorField, inline: true },
              { name: '📋 حالة المنع في النظام', value: '🔴 **نشط ومسجل في قاعدة البيانات**', inline: false },
              { name: '⚡ إجراء النظام التلقائي', value: '✅ **تمت إعادة الرتبة للعضو فورياً وبشكل تلقائي ومحكم**', inline: false }
            )
            .setFooter({ text: 'بـوت مـنـع الـتـوظـيـف • الحماية من التلاعب اليدوي' })
            .setTimestamp();

          await logChannel.send({ embeds: [embed] }).catch(() => {});
        }
      }
    } catch (err) {
      logger.error('خطأ في معالج guildMemberUpdate:', err.message);
    }
  }
};
