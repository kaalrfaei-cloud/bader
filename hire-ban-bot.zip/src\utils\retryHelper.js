const logger = require('./logger');

/**
 * Executes an async operation with exponential backoff retry.
 * Handles transient Discord API and network errors.
 *
 * @param {Function} operation Async function to execute
 * @param {Object} options Configuration options
 * @returns {Promise<any>}
 */
async function retryWithBackoff(operation, {
  maxRetries = 3,
  initialDelayMs = 400,
  backoffFactor = 2,
  operationName = 'Discord API Operation'
} = {}) {
  let attempt = 0;
  let delay = initialDelayMs;

  while (attempt < maxRetries) {
    attempt++;
    try {
      return await operation();
    } catch (error) {
      // Check if error is non-retryable (e.g. 403 Missing Permissions, 404 Unknown Member/Role)
      const isForbidden = error.status === 403 || error.code === 50013 || error.message?.includes('Missing Permissions');
      const isNotFound = error.status === 404 || error.code === 10007 || error.code === 10011;

      if (isForbidden || isNotFound || attempt >= maxRetries) {
        logger.error(`[Retry] فشلت عملية (${operationName}) نهائياً بعد ${attempt} محاولة:`, error.message);
        throw error;
      }

      logger.warn(`[Retry] خطأ مؤقت في (${operationName}) - محاولة ${attempt}/${maxRetries} بعد ${delay}ms: ${error.message}`);
      await new Promise(resolve => setTimeout(resolve, delay));
      delay *= backoffFactor;
    }
  }
}

module.exports = {
  retryWithBackoff
};
